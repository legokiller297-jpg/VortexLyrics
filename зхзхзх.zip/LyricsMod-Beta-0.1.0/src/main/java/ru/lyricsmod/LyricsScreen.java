
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

public class LyricsScreen extends Screen {

    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFC9B5DC;

    private int selectedTab = 0;
    private final float[] hoverProgress = new float[3];

    private float refreshHover = 0.0f;
    private float previousHover = 0.0f;
    private float playHover = 0.0f;
    private float nextHover = 0.0f;
    private float handleHover = 0.0f;

    private float playerProgress = 0.0f;
    private boolean playerOpen = false;

    private String currentTrackTitle = "No track selected";
    private String currentTrackSubtitle = "Choose a song in Playlist";

    private float scrollTime = 0.0f;

    private List<MusicLibrary.Track> tracks = List.of();
    private int selectedTrackIndex = -1;
    private int playlistScroll = 0;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
        refreshLibrary();
    }

    private void refreshLibrary() {
        String previousTitle = currentTrackTitle;

        tracks = MusicLibrary.scan();
        selectedTrackIndex = -1;

        for (int i = 0; i < tracks.size(); i++) {
            if (tracks.get(i).title().equalsIgnoreCase(previousTitle)) {
                selectedTrackIndex = i;
                break;
            }
        }

        if (selectedTrackIndex >= 0) {
            updateSelectedTrack();
        } else {
            currentTrackTitle = "No track selected";
            currentTrackSubtitle = "Choose a song in Playlist";
        }

        playlistScroll = Math.max(
                0,
                Math.min(playlistScroll,
                        Math.max(0, tracks.size() - getPlaylistVisibleCount()))
        );
    }

    private void updateSelectedTrack() {
        if (selectedTrackIndex < 0 || selectedTrackIndex >= tracks.size()) {
            return;
        }

        MusicLibrary.Track track = tracks.get(selectedTrackIndex);

        currentTrackTitle = track.title();
        currentTrackSubtitle = track.hasLyrics()
                ? "LRC lyrics found"
                : "No lyrics file";
    }

    private int getPlaylistVisibleCount() {
        return Math.max(1, (getMainHeight() - 195) / 35);
    }

    private int getMainX() {
        return width / 2;
    }

    private int getMainWidth() {
        return width - getMainX() - 12;
    }

    private int getMainHeight() {
        return Math.max(1, Math.min(340, height - 24));
    }

    private int getMainY() {
        return (height - getMainHeight()) / 2;
    }

    private int getPlayerSize() {
        return Math.max(130,
                Math.min(220, Math.min(height - 48, width / 2 - 32)));
    }

    private int getPlayerY() {
        return (height - getPlayerSize()) / 2;
    }

    private int getPlayerX() {
        int size = getPlayerSize();

        return getMainX() - size - 12
                + (int) ((size + 12) * (1.0f - playerProgress));
    }

    private int getSidebarX() {
        return getMainX() + 15;
    }

    private int getSidebarY() {
        return getMainY() + 70;
    }

    private int getSidebarWidth() {
        return Math.min(145, Math.max(120, getMainWidth() - 205));
    }

    private int getContentX() {
        return getSidebarX() + getSidebarWidth() + 13;
    }

    private int getContentY() {
        return getSidebarY();
    }

    private int getContentWidth() {
        return getMainWidth() - getSidebarWidth() - 43;
    }

    private int getContentHeight() {
        return getMainHeight() - 130;
    }

    private int getRefreshX() {
        return getContentX() + getContentWidth() - 62;
    }

    private int getRefreshY() {
        return getContentY() + 12;
    }

    private boolean inside(
            double mouseX,
            double mouseY,
            int x,
            int y,
            int w,
            int h
    ) {
        return mouseX >= x && mouseX <= x + w
                && mouseY >= y && mouseY <= y + h;
    }

    private float animate(float current, boolean hovered, float delta) {
        float target = hovered ? 1.0f : 0.0f;
        return current + (target - current)
                * Math.min(1.0f, delta * 10.0f);
    }

    private void drawButton(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            float progress,
            int normalColor,
            int hoverColor
    ) {
        float scale = 1.0f + progress * 0.07f;
        int color = lerpColor(normalColor, hoverColor, progress);

        float centerX = x + w / 2.0f;
        float centerY = y + h / 2.0f;

        context.getMatrices().push();
        context.getMatrices().translate(centerX, centerY, 0);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-centerX, -centerY, 0);

        roundedRect(context, x, y, w, h, radius, color);

        context.getMatrices().pop();
    }

    private void drawClippedText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int color
    ) {
        if (maxWidth <= 0 || text == null || text.isEmpty()) {
            return;
        }

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);
        context.drawTextWithShadow(textRenderer, text, x, y, color);
        context.disableScissor();
    }

    private void drawWrappedText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int maxHeight,
            int color
    ) {
        if (maxWidth <= 0 || maxHeight <= 0 || text == null) {
            return;
        }

        List<OrderedText> lines =
                textRenderer.wrapLines(Text.literal(text), maxWidth);

        context.enableScissor(x, y - 2, x + maxWidth, y + maxHeight);

        int lineY = y;

        for (OrderedText line : lines) {
            if (lineY + 9 > y + maxHeight) {
                break;
            }

            context.drawTextWithShadow(textRenderer, line, x, lineY, color);
            lineY += 10;
        }

        context.disableScissor();
    }

    private void drawScrollingText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int color
    ) {
        if (maxWidth <= 0 || text == null || text.isEmpty()) {
            return;
        }

        int textWidth = textRenderer.getWidth(text);

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);

        if (textWidth <= maxWidth) {
            context.drawTextWithShadow(textRenderer, text, x, y, color);
        } else {
            float delay = 1.2f;
            float speed = 3.0f;
            float gap = 28.0f;

            float elapsed = Math.max(0.0f, scrollTime - delay);
            float offset = (elapsed * speed) % (textWidth + gap);

            int drawX = x - (int) offset;

            context.drawTextWithShadow(textRenderer, text, drawX, y, color);
            context.drawTextWithShadow(
                    textRenderer,
                    text,
                    drawX + textWidth + (int) gap,
                    y,
                    color
            );
        }

        context.disableScissor();
    }

    private void roundedRect(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int color
    ) {
        if (w <= 0 || h <= 0) {
            return;
        }

        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        if (radius == 0) {
            context.fill(x, y, x + w, y + h, color);
            return;
        }

        int band = Math.max(1, radius / 3);
        band = Math.min(band, h / 2);

        int inset1 = calculateInset(radius, band);
        int inset2 = calculateInset(radius, band * 2);

        context.fill(x + inset1, y, x + w - inset1, y + band, color);
        context.fill(x + inset2, y + band, x + w - inset2, y + band * 2, color);

        int middleTop = y + band * 2;
        int middleBottom = y + h - band * 2;

        if (middleBottom > middleTop) {
            context.fill(x, middleTop, x + w, middleBottom, color);
        }

        context.fill(
                x + inset2, y + h - band * 2,
                x + w - inset2, y + h - band, color
        );

        context.fill(
                x + inset1, y + h - band,
                x + w - inset1, y + h, color
        );
    }

    private int calculateInset(int radius, int distance) {
        double remaining = radius - distance;

        return Math.max(0, radius - (int) Math.sqrt(
                radius * radius - remaining * remaining
        ));
    }

    private void glassPanel(
            DrawContext context,
            int x,
            int y,
            int w,
            int h
    ) {
        roundedRect(context, x - 4, y - 4, w + 8, h + 8, 20, 0x249D55E8);
        roundedRect(context, x - 2, y - 2, w + 4, h + 4, 19, 0x559B5AE0);
        roundedRect(context, x, y, w, h, 17, 0xF0181423);
        roundedRect(context, x + 1, y + 1, w - 2, h - 2, 16, 0xE91C1729);
    }

    private void drawPlayIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(x + i, y + i, x + i + 1, y + 17 - i, color);
        }
    }

    private void drawSlidersIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        context.fill(x, y + 3, x + 19, y + 5, color);
        context.fill(x, y + 9, x + 19, y + 11, color);
        context.fill(x, y + 15, x + 19, y + 17, color);

        context.fill(x + 5, y + 1, x + 9, y + 7, color);
        context.fill(x + 13, y + 7, x + 17, y + 13, color);
        context.fill(x + 7, y + 13, x + 11, y + 19, color);
    }

    private void drawSettingsIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        context.fill(x + 7, y, x + 12, y + 19, color);
        context.fill(x, y + 7, x + 19, y + 12, color);

        context.fill(x + 3, y + 2, x + 7, y + 6, color);
        context.fill(x + 12, y + 13, x + 16, y + 17, color);
        context.fill(x + 3, y + 13, x + 7, y + 17, color);
        context.fill(x + 12, y + 2, x + 16, y + 6, color);

        roundedRect(context, x + 6, y + 6, 7, 7, 3, 0xFF59416F);
    }

    private void drawTab(
            DrawContext context,
            int x,
            int y,
            int tabWidth,
            String label,
            int tab,
            boolean hovered,
            float delta
    ) {
        boolean active = selectedTab == tab;

        hoverProgress[tab] = animate(
                hoverProgress[tab], hovered, delta
        );

        float progress = hoverProgress[tab];

        int normalColor = active ? 0xFF9664C5 : 0xFF59416F;
        int hoverColor = active ? 0xFFAD7BE0 : 0xFF8055A8;

        drawButton(
                context, x, y, tabWidth, 34, 9,
                progress, normalColor, hoverColor
        );

        if (tab == 0) {
            drawPlayIcon(context, x + 8, y + 9, LIGHT);
        } else if (tab == 1) {
            drawSlidersIcon(context, x + 8, y + 7, LIGHT);
        } else {
            drawSettingsIcon(context, x + 8, y + 7, LIGHT);
        }

        drawClippedText(
                context, label, x + 36, y + 12, tabWidth - 42, LIGHT
        );
    }

    private int lerpColor(int from, int to, float amount) {
        int a = lerpChannel((from >> 24) & 255, (to >> 24) & 255, amount);
        int r = lerpChannel((from >> 16) & 255, (to >> 16) & 255, amount);
        int g = lerpChannel((from >> 8) & 255, (to >> 8) & 255, amount);
        int b = lerpChannel(from & 255, to & 255, amount);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int lerpChannel(int from, int to, float amount) {
        return (int) (from + (to - from) * amount);
    }

    private void drawPlayerPanelContent(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        int size = getPlayerSize();
        int x = getPlayerX();
        int y = getPlayerY();

        roundedRect(context, x + 12, y + 12, size - 24, 30, 9, 0xFF241B34);

        drawClippedText(
                context, "VORTEX PLAYER",
                x + 20, y + 22, size - 40, LIGHT
        );

        int coverSize = Math.max(38, Math.min(48, size - 76));
        int coverX = x + 14;
        int coverY = y + 50;

        roundedRect(context, coverX, coverY, coverSize, coverSize, 9, 0xFF39254D);
        roundedRect(context, coverX + 4, coverY + 4,
                coverSize - 8, coverSize - 8, 7, 0xFF62417F);

        String question = "?";
        int questionWidth = textRenderer.getWidth(question);

        context.drawTextWithShadow(
                textRenderer, question,
                coverX + (coverSize - questionWidth) / 2,
                coverY + (coverSize - 9) / 2,
                LIGHT
        );

        int textX = coverX + coverSize + 9;
        int textWidth = size - coverSize - 37;
        int titleY = coverY + 3;

        drawScrollingText(context, currentTrackTitle,
                textX, titleY, textWidth, LIGHT);

        drawWrappedText(context, currentTrackSubtitle,
                textX, titleY + 15, textWidth, 25, MUTED);

        int timelineX = x + 15;
        int timelineY = y + size - 43;
        int timelineWidth = size - 30;

        roundedRect(context, timelineX, timelineY,
                timelineWidth, 3, 2, 0xFF59416F);

        roundedRect(context, timelineX, timelineY,
                4, 3, 2, 0xFFAD7BE0);

        int buttonY = y + size - 32;
        int centerX = x + size / 2;

        int prevX = centerX - 45;
        int playX = centerX - 14;
        int nextX = centerX + 19;

        previousHover = animate(previousHover,
                inside(mouseX, mouseY, prevX, buttonY + 2, 26, 23), delta);

        playHover = animate(playHover,
                inside(mouseX, mouseY, playX, buttonY - 1, 28, 28), delta);

        nextHover = animate(nextHover,
                inside(mouseX, mouseY, nextX, buttonY + 2, 26, 23), delta);

        drawButton(context, prevX, buttonY + 2, 26, 23, 7,
                previousHover, 0xFF59416F, 0xFFAD7BE0);

        drawButton(context, playX, buttonY - 1, 28, 28, 9,
                playHover, 0xFF9664C5, 0xFFC18BEE);

        drawButton(context, nextX, buttonY + 2, 26, 23, 7,
                nextHover, 0xFF59416F, 0xFFAD7BE0);

        context.fill(centerX - 37, buttonY + 8, centerX - 35, buttonY + 19, LIGHT);
        context.fill(centerX - 34, buttonY + 8, centerX - 26, buttonY + 19, LIGHT);

        drawPlayIcon(context, centerX - 5, buttonY + 5, LIGHT);

        context.fill(centerX + 26, buttonY + 8, centerX + 34, buttonY + 19, LIGHT);
        context.fill(centerX + 35, buttonY + 8, centerX + 37, buttonY + 19, LIGHT);
    }

    private void drawPlayerHandle(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        int x = getMainX() - 7;
        int y = height / 2 - 35;

        boolean hovered = inside(mouseX, mouseY, x - 3, y, 20, 70);

        handleHover = animate(handleHover, hovered, delta);

        drawButton(
                context, x, y, 14, 70, 7,
                handleHover, 0xFF8052A9, 0xFFAD7BE0
        );

        roundedRect(context, x + 6, y + 23, 2, 24, 1, LIGHT);
    }

    private void drawOtherTab(
            DrawContext context,
            int x,
            int y,
            int panelWidth,
            int panelHeight
    ) {
        drawClippedText(context, "Other", x, y, panelWidth, LIGHT);

        drawWrappedText(
                context, "More settings are coming soon.",
                x, y + 22, panelWidth, panelHeight - 30, MUTED
        );
    }

    private void drawPlaylist(
            DrawContext context,
            int contentX,
            int contentY,
            int contentW,
            int contentH
    ) {
        drawClippedText(
                context, "Playlist (" + tracks.size() + ")",
                contentX + 12, contentY + 17, contentW - 85, LIGHT
        );

        int refreshX = getRefreshX();
        int refreshY = getRefreshY();

        drawButton(
                context, refreshX, refreshY, 50, 23, 7,
                refreshHover, 0xFF59416F, 0xFFAD7BE0
        );

        drawClippedText(
                context, "Refresh",
                refreshX + 5, refreshY + 6, 42, LIGHT
        );

        int listX = contentX + 7;
        int listY = contentY + 48;
        int rowWidth = contentW - 14;
        int rowHeight = 30;
        int rowStep = 35;
        int visibleCount = getPlaylistVisibleCount();

        if (tracks.isEmpty()) {
            drawWrappedText(
                    context,
                    "No songs found. Add MP3 or OGG files to the vortexlyrics/music folder.",
                    contentX + 12, contentY + 65,
                    contentW - 24, contentH - 75, MUTED
            );
            return;
        }

        context.enableScissor(
                listX, listY,
                listX + rowWidth,
                listY + visibleCount * rowStep
        );

        int end = Math.min(tracks.size(), playlistScroll + visibleCount);

        for (int i = playlistScroll; i < end; i++) {
            int visibleIndex = i - playlistScroll;
            int rowY = listY + visibleIndex * rowStep;

            boolean selected = i == selectedTrackIndex;

            roundedRect(
                    context, listX, rowY, rowWidth, rowHeight, 7,
                    selected ? 0xFF68458C : 0xFF30243F
            );

            MusicLibrary.Track track = tracks.get(i);

            drawClippedText(
                    context, track.title(),
                    listX + 9, rowY + 10, rowWidth - 65, LIGHT
            );

            String status = track.hasLyrics() ? "LRC" : "NO LRC";

            drawClippedText(
                    context, status,
                    listX + rowWidth - 49, rowY + 10, 43,
                    track.hasLyrics() ? 0xFFB9F6CA : MUTED
            );
        }

        context.disableScissor();

        if (tracks.size() > visibleCount) {
            String counter = (playlistScroll + 1)
                    + "-" + end + " / " + tracks.size();

            drawClippedText(
                    context, counter,
                    contentX + 12, contentY + contentH - 15,
                    contentW - 24, MUTED
            );
        }
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        scrollTime += Math.max(0.0f, Math.min(delta, 1.0f));

        float target = playerOpen ? 1.0f : 0.0f;
        playerProgress += (target - playerProgress) * 0.18f;

        if (Math.abs(target - playerProgress) < 0.001f) {
            playerProgress = target;
        }

        refreshHover = animate(
                refreshHover,
                selectedTab == 0 && inside(
                        mouseX, mouseY,
                        getRefreshX(), getRefreshY(), 50, 23
                ),
                delta
        );

        if (playerProgress > 0.001f) {
            context.enableScissor(0, 0, getMainX(), height);

            glassPanel(
                    context,
                    getPlayerX(),
                    getPlayerY(),
                    getPlayerSize(),
                    getPlayerSize()
                                        getPlayerSize()
            );

            drawPlayerPanelContent(context, mouseX, mouseY, delta);

            context.disableScissor();
        }

        int mainX = getMainX();
        int mainY = getMainY();
        int mainW = getMainWidth();
        int mainH = getMainHeight();

        glassPanel(context, mainX, mainY, mainW, mainH);

        drawClippedText(
                context, "VortexLyrics",
                mainX + 18, mainY + 18, mainW - 36, LIGHT
        );

        int sidebarX = getSidebarX();
        int sidebarY = getSidebarY();
        int sidebarW = getSidebarWidth();

        int tabWidth = sidebarW;
        int tabHeight = 34;
        int tabGap = 9;

        drawTab(
                context, sidebarX, sidebarY,
                tabWidth, "Music", 0,
                inside(mouseX, mouseY, sidebarX, sidebarY, tabWidth, tabHeight),
                delta
        );

        drawTab(
                context, sidebarX, sidebarY + tabHeight + tabGap,
                tabWidth, "Other", 1,
                inside(mouseX, mouseY,
                        sidebarX, sidebarY + tabHeight + tabGap,
                        tabWidth, tabHeight),
                delta
        );

        drawTab(
                context, sidebarX, sidebarY + (tabHeight + tabGap) * 2,
                tabWidth, "Settings", 2,
                inside(mouseX, mouseY,
                        sidebarX, sidebarY + (tabHeight + tabGap) * 2,
                        tabWidth, tabHeight),
                delta
        );

        int contentX = getContentX();
        int contentY = getContentY();
        int contentW = getContentWidth();
        int contentH = getContentHeight();

        if (selectedTab == 0) {
            drawPlaylist(
                    context,
                    contentX,
                    contentY,
                    contentW,
                    contentH
            );
        } else {
            drawOtherTab(
                    context,
                    contentX + 12,
                    contentY + 17,
                    contentW - 24,
                    contentH - 20
            );
        }

        drawPlayerHandle(context, mouseX, mouseY, delta);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        int handleX = getMainX() - 7;
        int handleY = height / 2 - 35;

        if (inside(mouseX, mouseY, handleX - 3, handleY, 20, 70)) {
            playerOpen = !playerOpen;
            return true;
        }

        if (selectedTab == 0 && inside(
                mouseX, mouseY,
                getRefreshX(), getRefreshY(), 50, 23
        )) {
            refreshLibrary();
            return true;
        }

        int sidebarX = getSidebarX();
        int sidebarY = getSidebarY();
        int sidebarW = getSidebarWidth();

        int tabHeight = 34;
        int tabGap = 9;

        for (int i = 0; i < 3; i++) {
            int tabY = sidebarY + i * (tabHeight + tabGap);

            if (inside(
                    mouseX, mouseY,
                    sidebarX, tabY, sidebarW, tabHeight
            )) {
                selectedTab = i;
                return true;
            }
        }

        if (selectedTab == 0) {
            int listX = getContentX() + 7;
            int listY = getContentY() + 48;
            int rowWidth = getContentWidth() - 14;
            int rowHeight = 30;
            int rowStep = 35;
            int visibleCount = getPlaylistVisibleCount();

            if (inside(
                    mouseX, mouseY,
                    listX, listY,
                    rowWidth, visibleCount * rowStep
            )) {
                int visibleIndex = (int) ((mouseY - listY) / rowStep);
                int index = playlistScroll + visibleIndex;

                if (visibleIndex >= 0
                        && visibleIndex < visibleCount
                        && index >= 0
                        && index < tracks.size()) {
                    selectedTrackIndex = index;
                    updateSelectedTrack();
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double horizontalAmount,
            double verticalAmount
    ) {
        if (selectedTab == 0) {
            int listX = getContentX() + 7;
            int listY = getContentY() + 48;
            int rowWidth = getContentWidth() - 14;
            int visibleCount = getPlaylistVisibleCount();

            if (inside(
                    mouseX, mouseY,
                    listX, listY,
                    rowWidth, visibleCount * 35
            )) {
                int maxScroll = Math.max(
                        0, tracks.size() - visibleCount
                );

                playlistScroll -= (int) Math.signum(verticalAmount);
                playlistScroll = Math.max(
                        0, Math.min(maxScroll, playlistScroll)
                );

                return true;
            }
        }

        return super.mouseScrolled(
                mouseX, mouseY,
                horizontalAmount, verticalAmount
        );
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}