
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;
import java.util.Locale;

public class LyricsScreen extends Screen {

    // Palette
    private static final int WHITE = 0xFFFFF8FF;
    private static final int LIGHT = 0xFFE8DDF2;
    private static final int MUTED = 0xFFAA9BB9;

    private static final int PURPLE = 0xFFB77AFF;
    private static final int PURPLE_LIGHT = 0xFFD3A2FF;
    private static final int PURPLE_DARK = 0xFF7545A3;

    private static final int PINK = 0xFFE58BDF;
    private static final int BLUE = 0xFF8C9CFF;

    private static final int GREEN = 0xFF72E5A7;
    private static final int GRAY = 0xFF96909E;

    private static final int PANEL_COLOR = 0xFF171020;
    private static final int SIDEBAR_COLOR = 0xFF1D1429;
    private static final int CARD_COLOR = 0xFF2A1E39;
    private static final int CARD_HOVER = 0xFF39264D;
    private static final int CARD_SELECTED = 0xFF49305F;

    private static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private static final String[] TABS = {
            "Playlist",
            "Visual",
            "Text",
            "Other"
    };

    private static final String[] ICONS = {
            "♫",
            "◈",
            "T",
            "i"
    };

    private List<MusicLibrary.Track> tracks = List.of();

    private int selectedTab = 0;
    private int selectedTrack = -1;

    private int playlistScroll = 0;
    private int draggingSlider = -1;

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    private int sidebarW;

    private int listX;
    private int listY;
    private int listW;
    private int listBottom;

    private static final int ROW_HEIGHT = 34;
    private static final int ROW_GAP = 4;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
        refreshLibrary();
    }

    // --------------------------------------------------
    // Layout
    // --------------------------------------------------

    private void calculateLayout() {
        panelW = Math.min(760, Math.max(240, width - 24));
        panelH = Math.min(500, Math.max(220, height - 24));

        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        sidebarW = Math.min(
                160,
                Math.max(92, panelW / 4)
        );

        listX = contentX();
        listY = contentY() + 66;
        listW = contentWidth();

        listBottom = playerY() - 12;
    }

    private int contentX() {
        return panelX + sidebarW + 22;
    }

    private int contentY() {
        return panelY + 72;
    }

    private int contentWidth() {
        return Math.max(
                40,
                panelW - sidebarW - 44
        );
    }

    private int playerY() {
        return panelY + panelH - 64;
    }

    private int playerHeight() {
        return 48;
    }

    // --------------------------------------------------
    // Drawing helpers
    // --------------------------------------------------

    private void fill(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int color
    ) {
        if (w <= 0 || h <= 0) {
            return;
        }

        context.fill(x, y, x + w, y + h, color);
    }

    private void rounded(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int color
    ) {
        if (w <= 0 || h <= 0) {
            return;
        }

        int r = Math.max(
                0,
                Math.min(radius, Math.min(w, h) / 2)
        );

        if (r == 0) {
            fill(context, x, y, w, h, color);
            return;
        }

        fill(
                context,
                x + r,
                y,
                w - 2 * r,
                h,
                color
        );

        fill(
                context,
                x,
                y + r,
                w,
                h - 2 * r,
                color
        );

        for (int i = 0; i < r; i++) {
            double distance = r - i - 0.5;

            int inset = (int) Math.ceil(
                    r - Math.sqrt(
                            Math.max(
                                    0,
                                    r * r - distance * distance
                            )
                    )
            );

            int lineWidth = w - inset * 2;

            fill(
                    context,
                    x + inset,
                    y + i,
                    lineWidth,
                    1,
                    color
            );

            fill(
                    context,
                    x + inset,
                    y + h - 1 - i,
                    lineWidth,
                    1,
                    color
            );
        }
    }

    private void roundedBorder(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int borderColor,
            int backgroundColor
    ) {
        rounded(
                context,
                x,
                y,
                w,
                h,
                radius,
                borderColor
        );

        rounded(
                context,
                x + 1,
                y + 1,
                w - 2,
                h - 2,
                Math.max(0, radius - 1),
                backgroundColor
        );
    }

    private int opacity(int color, int percent) {
        int originalAlpha = (color >>> 24) & 0xFF;

        int alpha = originalAlpha
                * Math.max(0, Math.min(100, percent))
                / 100;

        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private void drawText(
            DrawContext context,
            String value,
            int x,
            int y,
            int color
    ) {
        context.drawTextWithShadow(
                textRenderer,
                value,
                x,
                y,
                color
        );
    }

    private String trimText(String value, int maxWidth) {
        if (maxWidth <= 0) {
            return "";
        }

        if (textRenderer.getWidth(value) <= maxWidth) {
            return value;
        }

        String suffix = "...";

        if (textRenderer.getWidth(suffix) > maxWidth) {
            return "";
        }

        while (!value.isEmpty()
                && textRenderer.getWidth(value + suffix) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }

        return value + suffix;
    }

    private void drawCard(
            DrawContext context,
            int x,
            int y,
            int w,
            int h
    ) {
        rounded(
                context,
                x,
                y,
                w,
                h,
                10,
                CARD_COLOR
        );
    }

    private boolean inside(
            double mouseX,
            double mouseY,
            int x,
            int y,
            int w,
            int h
    ) {
        return mouseX >= x
                && mouseX < x + w
                && mouseY >= y
                && mouseY < y + h;
    }

    // --------------------------------------------------
    // Library
    // --------------------------------------------------

    private void refreshLibrary() {
        tracks = MusicLibrary.scan();

        if (tracks.isEmpty()) {
            selectedTrack = -1;
            playlistScroll = 0;
            return;
        }

        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            selectedTrack = 0;
        }

        int visible = Math.max(
                1,
                (listBottom - listY + ROW_GAP)
                        / (ROW_HEIGHT + ROW_GAP)
        );

        playlistScroll = Math.max(
                0,
                Math.min(
                        playlistScroll,
                        Math.max(0, tracks.size() - visible)
                )
        );
    }

    private void playSelectedTrack() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return;
        }

        File file = tracks.get(selectedTrack)
                .audioFile()
                .toFile();

        if (file.equals(MUSIC_PLAYER.getCurrentFile())
                && MUSIC_PLAYER.isPlaying()) {
            MUSIC_PLAYER.stop();
        } else {
            MUSIC_PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {
        if (tracks.isEmpty()) {
            return;
        }

        selectedTrack = selectedTrack < 0
                ? 0
                : Math.floorMod(
                        selectedTrack + direction,
                        tracks.size()
                );

        playSelectedTrack();
    }

    // --------------------------------------------------
    // Main panel
    // --------------------------------------------------

    private void drawMainPanel(DrawContext context) {
        int opacity = LyricsConfig.panelOpacity;

        rounded(
                context,
                panelX - 2,
                panelY - 2,
                panelW + 4,
                panelH + 4,
                19,
                0xFFB17BDA
        );

        rounded(
                context,
                panelX,
                panelY,
                panelW,
                panelH,
                18,
                opacity(PANEL_COLOR, opacity)
        );

        // Subtle upper accent
        rounded(
                context,
                panelX + 18,
                panelY + 2,
                panelW - 36,
                2,
                1,
                0xFF8B5BB2
        );
    }

    private void drawHeader(DrawContext context) {
        int x = panelX + sidebarW + 22;

        drawText(
                context,
                "VortexLyrics",
                x,
                panelY + 19,
                WHITE
        );

        drawText(
                context,
                "MUSIC EXPERIENCE",
                x,
                panelY + 36,
                MUTED
        );

        fill(
                context,
                x,
                panelY + 58,
                contentWidth(),
                1,
                0x554D3B60
        );
    }

    // --------------------------------------------------
    // Sidebar
    // --------------------------------------------------

    private void drawSidebar(
            DrawContext context,
            int mouseX,
            int mouseY
    ) {
        rounded(
                context,
                panelX,
                panelY,
                sidebarW + 12,
                panelH,
                18,
                SIDEBAR_COLOR
        );

        fill(
                context,
                panelX + sidebarW,
                panelY + 16,
                1,
                panelH - 32,
                0xFF382A46
        );

        int startY = panelY + 82;

        for (int i = 0; i < TABS.length; i++) {
            int y = startY + i * 47;

            boolean selected = selectedTab == i;

            boolean hovered = inside(
                    mouseX,
                    mouseY,
                    panelX + 10,
                    y,
                    sidebarW - 22,
                    38
            );

            int buttonColor = selected
                    ? CARD_SELECTED
                    : hovered
                    ? CARD_HOVER
                    : SIDEBAR_COLOR;

            rounded(
                    context,
                    panelX + 10,
                    y,
                    sidebarW - 22,
                    38,
                    9,
                    buttonColor
            );

            if (selected) {
                rounded(
                        context,
                        panelX + 10,
                        y + 7,
                        3,
                        24,
                        2,
                        PURPLE_LIGHT
                );
            } else if (hovered) {
                roundedBorder(
                        context,
                        panelX + 10,
                        y,
                        sidebarW - 22,
                        38,
                        9,
                        0x88FFFFFF,
                        buttonColor
                );
            }

            drawText(
                    context,
                    ICONS[i],
                    panelX + 22,
                    y + 13,
                    selected ? PURPLE_LIGHT : MUTED
            );

            drawText(
                    context,
                    TABS[i],
                    panelX + 44,
                    y + 13,
                    selected ? WHITE : LIGHT
            );
        }

        drawText(
                context,
                "VORTEX",
                panelX + 17,
                panelY + panelH - 25,
                MUTED
        );
    }

    // --------------------------------------------------
    // Titles and buttons
    // --------------------------------------------------

    private void drawTitle(
            DrawContext context,
            String title,
            String subtitle
    ) {
        int x = contentX();
        int y = contentY();

        drawText(context, title, x, y, WHITE);
        drawText(context, subtitle, x, y + 18, MUTED);
    }

    private void drawButton(
            DrawContext context,
            String label,
            int x,
            int y,
            int w,
            int h,
            int mouseX,
            int mouseY
    ) {
        boolean hovered = inside(
                mouseX,
                mouseY,
                x,
                y,
                w,
                h
        );

        int background = hovered
                ? CARD_HOVER
                : CARD_COLOR;

        if (hovered) {
            roundedBorder(
                    context,
                    x - 1,
                    y - 1,
                    w + 2,
                    h + 2,
                    9,
                    0xBFFFFFFF,
                    background
            );
        } else {
            rounded(
                    context,
                    x,
                    y,
                    w,
                    h,
                    8,
                    background
            );
        }

        int textX = x + (w - textRenderer.getWidth(label)) / 2;
        int textY = y + (h - 9) / 2;

        drawText(
                context,
                label,
                textX,
                textY,
                hovered ? WHITE : PURPLE_LIGHT
        );
    }

    // --------------------------------------------------
    // LRC
    // --------------------------------------------------

    private void drawLrcBadge(
            DrawContext context,
            int x,
            int y,
            boolean hasLyrics
    ) {
        int background = hasLyrics
                ? 0xFF214735
                : 0xFF38333F;

        int foreground = hasLyrics
                ? GREEN
                : GRAY;

        rounded(
                context,
                x,
                y,
                34,
                19,
                6,
                background
        );

        drawText(
                context,
                "LRC",
                x + 6,
                y + 5,
                foreground
        );
    }

    // --------------------------------------------------
    // Playlist
    // --------------------------------------------------

    private void drawPlaylist(
            DrawContext context,
            int mouseX,
            int mouseY
    ) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Your Playlist",
                "Your personal music collection"
        );

        drawText(
                context,
                tracks.size() + " TRACKS",
                x,
                y + 43,
                MUTED
        );

        int refreshW = 66;
        int refreshX = x + w - refreshW;

        drawButton(
                context,
                "REFRESH",
                refreshX,
                y + 36,
                refreshW,
                24,
                mouseX,
                mouseY
        );

        if (listBottom <= listY) {
            return;
        }

        if (tracks.isEmpty()) {
            drawCard(
                    context,
                    x,
                    listY,
                    w,
                    Math.min(90, listBottom - listY)
            );

            drawText(
                    context,
                    "Your playlist is empty",
                    x + 13,
                    listY + 18,
                    LIGHT
            );

            drawText(
                    context,
                    "Add MP3 or OGG files to:",
                    x + 13,
                    listY + 38,
                    MUTED
            );

            drawText(
                    context,
                    "vortexlyrics/music",
                    x + 13,
                    listY + 55,
                    PURPLE_LIGHT
            );

            return;
        }

        int visible = Math.max(
                0,
                (listBottom - listY + ROW_GAP)
                        / (ROW_HEIGHT + ROW_GAP)
        );

        context.enableScissor(
                x,
                listY,
                x + w,
                listBottom
        );

        for (int i = playlistScroll;
             i < Math.min(tracks.size(), playlistScroll + visible);
             i++) {

            int rowY = listY
                    + (i - playlistScroll)
                    * (ROW_HEIGHT + ROW_GAP);

            boolean selected = selectedTrack == i;

            boolean hovered = inside(
                    mouseX,
                    mouseY,
                    x,
                    rowY,
                    w,
                    ROW_HEIGHT
            );

            int background = selected
                    ? CARD_SELECTED
                    : hovered
                    ? CARD_HOVER
                    : CARD_COLOR;

            rounded(
                    context,
                    x,
                    rowY,
                    w,
                    ROW_HEIGHT,
                    8,
                    background
            );

            if (selected) {
                rounded(
                        context,
                        x,
                        rowY + 7,
                        3,
                        20,
                        2,
                        PURPLE_LIGHT
                );
            }

            int badgeX = x + w - 45;

            String title = trimText(
                    tracks.get(i).title(),
                    badgeX - x - 20
            );

            drawText(
                    context,
                    title,
                    x + 12,
                    rowY + 12,
                    selected ? WHITE : LIGHT
            );

            drawLrcBadge(
                    context,
                    badgeX,
                    rowY + 7,
                    tracks.get(i).hasLyrics()
            );
        }

        context.disableScissor();
    }

    // --------------------------------------------------
    // Sliders
    // --------------------------------------------------

    private void drawSlider(
            DrawContext context,
            int x,
            int y,
            int w,
            String title,
            String valueText,
            double value,
            double min,
            double max,
            int accent
    ) {
        drawCard(context, x, y, w, 66);

        drawText(
                context,
                title,
                x + 13,
                y + 11,
                LIGHT
        );

        drawText(
                context,
                valueText,
                x + w - textRenderer.getWidth(valueText) - 13,
                y + 11,
                accent
        );

        int barX = x + 13;
        int barY = y + 45;
        int barW = Math.max(1, w - 26);

        rounded(
                context,
                barX,
                barY,
                barW,
                5,
                3,
                0xFF493958
        );

        double progress = Math.max(
                0,
                Math.min(
                        1,
                        (value - min) / (max - min)
                )
        );

        int filled = (int) (barW * progress);

        if (filled > 0) {
            rounded(
                    context,
                    barX,
                    barY,
                    filled,
                    5,
                    3,
                    accent
            );
        }

        int knobX = Math.max(
                barX,
                Math.min(barX + barW - 8, barX + filled - 4)
        );

        rounded(
                context,
                knobX,
                barY - 4,
                9,
                13,
                5,
                WHITE
        );
    }

    private void drawTextSettings(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Text Settings",
                "Customize lyrics displayed in your world"
        );

        drawSlider(
                context,
                x,
                y + 49,
                w,
                "Spawn distance",
                String.format(
                        Locale.ROOT,
                        "%.1f blocks",
                        LyricsConfig.distance
                ),
                LyricsConfig.distance,
                3,
                30,
                PURPLE
        );

        drawSlider(
                context,
                x,
                y + 123,
                w,
                "Text size",
                String.format(
                        Locale.ROOT,
                        "%.3f",
                        LyricsConfig.textScale
                ),
                LyricsConfig.textScale,
                0.02,
                0.09,
                PINK
        );

        drawSlider(
                context,
                x,
                y + 197,
                w,
                "Text width",
                LyricsConfig.textWidth + " px",
                LyricsConfig.textWidth,
                60,
                300,
                BLUE
        );
    }

    // --------------------------------------------------
    // Visual settings
    // --------------------------------------------------

    private void drawVisual(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Visual Appearance",
                "Customize the interface appearance"
        );

        drawSlider(
                context,
                x,
                y + 49,
                w,
                "Panel opacity",
                LyricsConfig.panelOpacity + "%",
                LyricsConfig.panelOpacity,
                10,
                90,
                PURPLE_LIGHT
        );

        int previewY = y + 129;

        drawCard(
                context,
                x,
                previewY,
                w,
                115
        );

        drawText(
                context,
                "COLOR PALETTE",
                x + 13,
                previewY + 12,
                LIGHT
        );

        int swatchY = previewY + 42;
        int swatchW = Math.max(12, (w - 46) / 4);

        int[] colors = {
                0xFF392052,
                0xFF583078,
                0xFF9863C9,
                0xFFD69CF2
        };

        String[] names = {
                "Deep",
                "Dark",
                "Light",
                "Soft"
        };

        for (int i = 0; i < colors.length; i++) {
            int sx = x + 13 + i * (swatchW + 6);

            rounded(
                    context,
                    sx,
                    swatchY,
                    swatchW,
                    22,
                    6,
                    colors[i]
            );

            drawText(
                    context,
                    names[i],
                    sx,
                    swatchY + 30,
                    MUTED
            );
        }

        drawText(
                context,
                "Lightweight rendering without blur shaders.",
                x + 13,
                previewY + 88,
                MUTED
        );
    }

    // --------------------------------------------------
    // Other
    // --------------------------------------------------

    private void drawOther(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "About VortexLyrics",
                "Information about the modification"
        );

        int cardY = y + 49;

        drawCard(
                context,
                x,
                cardY,
                w,
                115
        );

        drawText(
                context,
                "VortexLyrics",
                x + 14,
                cardY + 14,
                WHITE
        );

        drawText(
                context,
                "Minecraft music and world lyrics player.",
                x + 14,
                cardY + 37,
                LIGHT
        );

        drawText(
                context,
                "Supported audio: MP3 / OGG",
                x + 14,
                cardY + 61,
                MUTED
        );

        drawText(
                context,
                "Lyrics format: LRC",
                x + 14,
                cardY + 80,
                MUTED
        );

        drawCard(
                context,
                x,
                cardY + 127,
                w,
                60
        );

        drawText(
                context,
                "Music library",
                x + 14,
                cardY + 140,
                LIGHT
        );

        drawText(
                context,
                "Songs found: " + tracks.size(),
                x + 14,
                cardY + 160,
                MUTED
        );
    }

    // --------------------------------------------------
    // Mini player
    // --------------------------------------------------

    private void drawMiniPlayer(
            DrawContext context,
            int mouseX,
            int mouseY
    ) {
        int x = panelX + 13;
        int y = playerY();
        int w = panelW - 26;
        int h = playerHeight();

        roundedBorder(
                context,
                x,
                y,
                w,
                h,
                11,
                0xFF654780,
                0xFF251A32
        );

        String trackName = selectedTrack >= 0
                && selectedTrack < tracks.size()
                ? tracks.get(selectedTrack).title()
                : "No track selected";

        int controlsX = x + w - 112;

        drawText(
                context,
                trimText(trackName, Math.max(30, controlsX - x - 25)),
                x + 13,
                y + 9,
                WHITE
        );

        boolean playing = MUSIC_PLAYER.isPlaying();

        drawText(
                context,
                playing ? "NOW PLAYING" : "VORTEX PLAYER",
                x + 13,
                y + 26,
                playing ? GREEN : MUTED
        );

        drawPlayerButton(
                context,
                "<",
                controlsX,
                y,
                mouseX,
                mouseY
        );

        drawPlayerButton(
                context,
                playing ? "||" : ">",
                controlsX + 36,
                y,
                mouseX,
                mouseY
        );

        drawPlayerButton(
                context,
                ">",
                controlsX + 72,
                y,
                mouseX,
                mouseY
        );
    }

    private void drawPlayerButton(
            DrawContext context,
            String label,
            int x,
            int y,
            int mouseX,
            int mouseY
    ) {
        boolean hovered = inside(
                mouseX,
                mouseY,
                x - 3,
                y + 5,
                29,
                36
        );

        rounded(
                context,
                x - 3,
                y + 5,
                29,
                36,
                8,
                hovered ? CARD_HOVER : 0xFF30233F
        );

        drawText(
                context,
                label,
                x + 7,
                y + 18,
                hovered ? WHITE : PURPLE_LIGHT
        );
    }

    // --------------------------------------------------
    // Slider interaction
    // --------------------------------------------------

    private void updateSlider(double mouseX, int id) {
        int x = contentX() + 13;
        int w = Math.max(1, contentWidth() - 26);

        double progress = Math.max(
                0,
                Math.min(
                        1,
                        (mouseX - x) / (double) w
                )
        );

        if (id == 0) {
            LyricsConfig.distance = 3 + progress * 27;
        } else if (id == 1) {
            LyricsConfig.textScale =
                    (float) (0.02 + progress * 0.07);
        } else if (id == 2) {
            LyricsConfig.textWidth =
                    (int) Math.round(60 + progress * 240);
        } else if (id == 3) {
            LyricsConfig.panelOpacity =
                    (int) Math.round(10 + progress * 80);
        }
    }

    // --------------------------------------------------
    // Render
    // --------------------------------------------------

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        calculateLayout();

        drawMainPanel(context);
        drawSidebar(context, mouseX, mouseY);
        drawHeader(context);

        switch (selectedTab) {
            case 0 -> drawPlaylist(context, mouseX, mouseY);
            case 1 -> drawVisual(context);
            case 2 -> drawTextSettings(context);
            case 3 -> drawOther(context);
            default -> selectedTab = 0;
        }

        drawMiniPlayer(context, mouseX, mouseY);

        super.render(context, mouseX, mouseY, delta);
    }

    // --------------------------------------------------
    // Mouse clicks
    // --------------------------------------------------

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        calculateLayout();

        // Sidebar
        int startY = panelY + 82;

        for (int i = 0; i < TABS.length; i++) {
            int y = startY + i * 47;

            if (inside(
                    mouseX,
                    mouseY,
                    panelX + 10,
                    y,
                    sidebarW - 22,
                    38
            )) {
                selectedTab = i;
                draggingSlider = -1;
                return true;
            }
        }

        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        // Playlist
        if (selectedTab == 0) {
            int refreshX = x + w - 66;

            if (inside(
                    mouseX,
                    mouseY,
                    refreshX,
                    y + 36,
                    66,
                    24
            )) {
                refreshLibrary();
                return true;
            }

            if (inside(
                    mouseX,
                    mouseY,
                    listX,
                    listY,
                    listW,
                    Math.max(0, listBottom - listY)
            )) {
                int index = playlistScroll
                        + (int) ((mouseY - listY)
                        / (ROW_HEIGHT + ROW_GAP));

                if (index >= 0 && index < tracks.size()) {
                    int rowY = listY
                            + (index - playlistScroll)
                            * (ROW_HEIGHT + ROW_GAP);

                    if (inside(
                            mouseX,
                            mouseY,
                            listX,
                            rowY,
                            listW,
                            ROW_HEIGHT
                    )) {
                        selectedTrack = index;
                        return true;
                    }
                }

                return true;
            }
        }

        // Text sliders
        if (selectedTab == 2) {
            int[] sliderY = {
                    y + 49,
                    y + 123,
                    y + 197
            };

            for (int i = 0; i < sliderY.length; i++) {
                if (inside(
                        mouseX,
                        mouseY,
                        x,
                        sliderY[i],
                        w,
                        66
                )) {
                    draggingSlider = i;
                    updateSlider(mouseX, i);
                    return true;
                }
            }
        }

        // Visual opacity slider
        if (selectedTab == 1) {
            if (inside(
                    mouseX,
                    mouseY,
                    x,
                    y + 49,
                    w,
                    66
            )) {
                draggingSlider = 3;
                updateSlider(mouseX, 3);
                return true;
            }
        }

        // Player controls
        int controlsX = panelX + 13 + panelW - 26 - 112;
        int playerY = playerY();

        if (inside(
                mouseX,
                mouseY,
                controlsX - 3,
                playerY + 5,
                29,
                36
        )) {
            changeTrack(-1);
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + 33,
                playerY + 5,
                29,
                36
        )) {
            playSelectedTrack();
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + 69,
                playerY + 5,
                29,
                36
        )) {
            changeTrack(1);
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    // --------------------------------------------------
    // Dragging
    // --------------------------------------------------

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double deltaX,
            double deltaY
    ) {
        if (draggingSlider >= 0 && button == 0) {
            updateSlider(mouseX, draggingSlider);
            return true;
        }

        return super.mouseDragged(
                mouseX,
                mouseY,
                button,
                deltaX,
                deltaY
        );
    }

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (draggingSlider >= 0 && button == 0) {
            draggingSlider = -1;
            LyricsConfig.save();
            return true;
        }

        return super.mouseReleased(
                mouseX,
                mouseY,
                button
        );
    }

    // --------------------------------------------------
    // Scrolling
    // --------------------------------------------------

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {
        calculateLayout();

        if (selectedTab == 0
                && inside(
                        mouseX,
                        mouseY,
                        listX,
                        listY,
                        listW,
                        Math.max(0, listBottom - listY)
                )) {

            int visible = Math.max(
                    1,
                    (listBottom - listY + ROW_GAP)
                            / (ROW_HEIGHT + ROW_GAP)
            );

            int maxScroll = Math.max(
                    0,
                    tracks.size() - visible
            );

            playlistScroll -= (int) Math.signum(amount);

            playlistScroll = Math.max(
                    0,
                    Math.min(maxScroll, playlistScroll)
            );

            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
