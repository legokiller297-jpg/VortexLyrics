
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.sound.v1.FabricSoundInstance;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.AudioStream;
import net.minecraft.client.sound.SoundLoader;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.io.File;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

public final class FileMusicSound extends AbstractSoundInstance
        implements FabricSoundInstance {

    private final File file;

    public FileMusicSound(File file) {
        super(
                new Identifier("lyricsmod", "music_stream"),
                SoundCategory.MUSIC,
                Random.create()
        );

        this.file = file;
        this.repeat = false;
        this.volume = 1.0f;
        this.relative = true;
    }

    @Override
    public CompletableFuture<AudioStream> getAudioStream(
            SoundLoader loader,
            Identifier id,
            boolean repeatInstantly
    ) {
        System.out.println(
                "[VortexLyrics] Запрошен аудиопоток: " + file
        );

        return CompletableFuture.supplyAsync(() -> {
            try {
                System.out.println(
                        "[VortexLyrics] Начинаю декодирование: " + file
                );

                AudioStream audioStream =
                        new FileAudioStream(file.toPath());

                System.out.println(
                        "[VortexLyrics] Аудиопоток создан успешно"
                );

                return audioStream;

            } catch (Exception exception) {
                System.err.println(
                        "[VortexLyrics] Ошибка создания аудиопотока"
                );

                exception.printStackTrace();

                throw new CompletionException(exception);
            }
        });
    }
}

