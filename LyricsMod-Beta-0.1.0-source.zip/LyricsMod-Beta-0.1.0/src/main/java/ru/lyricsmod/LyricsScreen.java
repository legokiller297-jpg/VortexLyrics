package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class LyricsScreen extends Screen {
    public LyricsScreen() { super(Text.literal("Lyrics Mod")); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        int w = Math.min(420, width - 32), h = Math.min(230, height - 32);
        int x = (width - w) / 2, y = (height - h) / 2;
        context.fill(x, y, x + w, y + h, 0xEE171321);
        context.fill(x, y, x + w, y + 3, 0xFFB77AFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("LYRICS MOD  •  BETA 0.1.0"), width / 2, y + 18, 0xFFE5D3FF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Your music. Your lyrics. Your world."), width / 2, y + 43, 0xFFB8A6CC);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Player and 3D lyrics are coming next."), width / 2, y + 92, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Press ESC to close"), width / 2, y + h - 24, 0xFFB8A6CC);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
