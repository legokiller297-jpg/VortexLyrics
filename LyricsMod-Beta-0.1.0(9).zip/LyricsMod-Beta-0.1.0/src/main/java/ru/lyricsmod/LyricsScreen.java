
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.text.Style;

public class LyricsScreen extends Screen {

    private static final int PURPLE = 0xFFB77AFF;
    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFAA98C2;

    private static final Identifier NUNITO =
            new Identifier("lyricsmod", "nunito");

    // 0 = Playlist, 1 = Visual, 2 = Other
    private int selectedTab = 0;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
    }

    // Text using Nunito
    private Text uiText(String value) {
        return Text.literal(value)
                .setStyle(Style.EMPTY.withFont(NUNITO));
    }

    // Rounded rectangle
    private void roundedRect(
            DrawContext context,
            int x, int y, int w, int h,
            int radius, int color
    ) {
        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        for (int row = 0; row < h; row++) {
            int edge = Math.min(row, h - 1 - row);
            int inset = 0;

            if (edge < radius) {
                double distance = radius - edge;
                inset = radius - (int) Math.sqrt(
                        radius * radius - distance * distance
                );
            }

            context.fill(
                    x + inset, y + row,
                    x + w - inset, y + row + 1,
                    color
            );
        }
    }

    // Glass panel
    private void glassPanel(
            DrawContext context,
            int x, int y, int w, int h
    ) {
        roundedRect(context, x - 4, y - 4,
                w + 8, h + 8, 20, 0x249D55E8);

        roundedRect(context, x - 2, y - 2,
                w + 4, h + 4, 19, 0x559B5AE0);

        roundedRect(context, x, y,
                w, h, 17, 0xF0181423);

        roundedRect(context, x + 1, y + 1,
                w - 2, h - 2, 16, 0xE91C1729);
    }

    // Play icon
    private void drawPlayIcon(
            DrawContext context, int x, int y, int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(
                    x + i, y + i,
                    x + i + 1, y + 17 - i,
                    color
            );
        }
    }

    // Navigation tab
    private void drawTab(
            DrawContext context,
            int x, int y, int w,
            String label, int tab,
            int iconType
    ) {
        boolean active = selectedTab == tab;

        if (active) {
            roundedRect(context, x, y,
                    w, 34, 8, 0xFF49305F);
        }

        int color = active ? LIGHT : MUTED;

        if (iconType == 0) {
            drawPlayIcon(context, x + 11, y + 9, PURPLE);
        } else if (iconType == 1) {
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("◈"),
                    x + 12, y + 11, PURPLE
            );
        } else {
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("⚙"),
                    x + 12, y + 11, PURPLE
            );
        }

        context.drawTextWithShadow(
                textRenderer,
                uiText(label),
                x + 36, y + 10, color
        );
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        int w = Math.min(560, width - 24);
        int h = Math.min(340, height - 24);

        int x = (width - w) / 2;
        int y = (height - h) / 2;

        // Main window
        glassPanel(context, x, y, w, h);

        // Header
        roundedRect(context, x + 15, y + 14,
                w - 30, 45, 11, 0xFF241B34);

        context.drawTextWithShadow(
                textRenderer,
                uiText("VortexLyrics"),
                x + 29, y + 21, LIGHT
        );

        context.drawTextWithShadow(
                textRenderer,
                uiText("BETA 0.1.0"),
                x + 29, y + 39, MUTED
        );

        // Sidebar
        int sidebarX = x + 15;
        int sidebarY = y + 70;
        int sidebarW = 145;
        int sidebarH = h - 130;

        roundedRect(context, sidebarX, sidebarY,
                sidebarW, sidebarH, 12, 0xCC211A30);

        // Tabs
        drawTab(context, sidebarX + 7, sidebarY + 10,
                sidebarW - 14, "Playlist", 0, 0);

        drawTab(context, sidebarX + 7, sidebarY + 52,
                sidebarW - 14, "Visual", 1, 1);

        drawTab(context, sidebarX + 7, sidebarY + 94,
                sidebarW - 14, "Other", 2, 2);

        // Content area
        int contentX = sidebarX + sidebarW + 13;
        int contentY = sidebarY;
        int contentW = w - sidebarW - 43;
        int contentH = sidebarH;

        roundedRect(context, contentX, contentY,
                contentW, contentH, 12, 0x99251D34);

        if (selectedTab == 0) {

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Music Library"),
                    contentX + 17, contentY + 17, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Your playlists will appear here."),
                    contentX + 17, contentY + 39, MUTED
            );

        } else if (selectedTab == 1) {

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Visual Settings"),
                    contentX + 17, contentY + 17, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Appearance options will appear here."),
                    contentX + 17, contentY + 39, MUTED
            );

        } else {

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Other Settings"),
                    contentX + 17, contentY + 17, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Additional options will appear here."),
                    contentX + 17, contentY + 39, MUTED
            );
        }

        // Bottom player
        int barY = y + h - 48;

        roundedRect(context, x + 15, barY,
                w - 30, 34, 10, 0xFF30243F);

        roundedRect(context, x + 22, barY + 6,
                22, 22, 7, 0xFF8052A9);

        drawPlayIcon(context, x + 29,
                barY + 9, 0xFFFFFFFF);

        context.drawTextWithShadow(
                textRenderer,
                uiText("VORTEXLYRICS PLAYER"),
                x + 55, barY + 11, LIGHT
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(
            double mouseX, double mouseY, int button
    ) {
        if (button == 0) {
            int w = Math.min(560, width - 24);
            int h = Math.min(340, height - 24);

            int x = (width - w) / 2;
            int y = (height - h) / 2;

            int sidebarX = x + 15;
            int sidebarY = y + 70;

            int tabX = sidebarX + 7;
            int tabW = 145 - 14;

            if (mouseX >= tabX && mouseX <= tabX + tabW) {

                if (mouseY >= sidebarY + 10 &&
                    mouseY <= sidebarY + 44) {
                    selectedTab = 0;
                    return true;
                }

                if (mouseY >= sidebarY + 52 &&
                    mouseY <= sidebarY + 86) {
                    selectedTab = 1;
                    return true;
                }

                if (mouseY >= sidebarY + 94 &&
                    mouseY <= sidebarY + 128) {
                    selectedTab = 2;
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

