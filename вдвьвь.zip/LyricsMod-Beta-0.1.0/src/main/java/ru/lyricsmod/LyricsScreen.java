package ru.lyricsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;
import java.util.Locale;

public class LyricsScreen extends Screen {

    // Main palette
    private static final int WHITE = 0xFFF7F0FF;
    private static final int TEXT = 0xFFE3D8F0;
    private static final int MUTED = 0xFF9D8EAE;

    private static final int ACCENT = 0xFFA855F7;
    private static final int ACCENT_LIGHT = 0xFFDDB7FF;
    private static final int ACCENT_DARK = 0xFF7540A8;

    private static final int BACKGROUND = 0xFF08060D;
    private static final int SIDEBAR = 0xFF171020;
    private static final int PANEL = 0xFF21152F;
    private static final int CARD = 0xFF352347;
    private static final int CARD_LIGHT = 0xFF49305F;
    private static final int CARD_HOVER = 0xFF69418D;
    private static final int SELECTED = 0xFF593477;
    private static final int TRACK = 0xFF382A46;

    private static final int GREEN = 0xFF82DDB0;
    private static final int GRAY = 0xFF9B91A5;

    private static final String[] TABS = {
            "Playlist", "Visual", "Text", "Other"
    };

    private static final String[] ICONS = {
            "♫", "◈", "T", "i"
    };

    private static final int ROW_HEIGHT = 36;
    private static final int ROW_GAP = 6;
    private static final int SCROLLBAR_WIDTH = 5;

    private static final MusicPlayer PLAYER = new MusicPlayer();

    private List<MusicLibrary.Track> tracks = List.of();

    private int selectedTab = 0;
    private int selectedTrack = -1;

    private int playlistScroll = 0;
    private double settingsScroll = 0;

    private int draggingSlider = -1;
    private boolean draggingScrollbar;
    private double scrollbarGrabOffset;

    // Main window
    private int panelX, panelY, panelW, panelH;

    // Navigation
    private int sidebarW;
    private boolean compactLayout;

    // Left player
    private int playerX, playerY, playerW, playerH;

    // Right settings
    private int contentX, contentY, contentW;
    private int viewportX, viewportY, viewportW, viewportH;

    private int scrollContentHeight;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));

        tracks = MusicLibrary.scan();

        if (!tracks.isEmpty()) {
            selectedTrack = 0;
        }
    }

    // ------------------------------------------------------------
    // LAYOUT
    // ------------------------------------------------------------

    private void calculateLayout() {
        panelW = Math.max(1, Math.min(920, width - 16));
        panelH = Math.max(1, Math.min(560, height - 16));

        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        compactLayout = panelW < 620 || panelH < 390;
        sidebarW = compactLayout ? 0 : Math.min(70, Math.max(58, panelW / 11));

        if (compactLayout) {
            int innerX = panelX + 12;
            int innerW = Math.max(1, panelW - 24);

            playerX = innerX;
            playerY = panelY + 49;
            playerW = innerW;
            playerH = 62;

            contentX = innerX;
            contentY = panelY + 119;
            contentW = innerW;

            viewportX = contentX + 2;
            viewportY = panelY + 190;
            viewportW = Math.max(1, contentW - SCROLLBAR_WIDTH - 10);
            viewportH = Math.max(1, panelY + panelH - 12 - viewportY);
        } else {
            int innerX = panelX + sidebarW + 14;
            int innerW = panelX + panelW - 16 - innerX;

            playerW = Math.max(205, Math.min(285, (int) (innerW * 0.39)));
            playerX = innerX;
            playerY = panelY + 18;
            playerH = panelH - 36;

            contentX = playerX + playerW + 14;
            contentY = panelY + 18;
            contentW = Math.max(1, panelX + panelW - 16 - contentX);

            viewportX = contentX;
            viewportY = panelY + 94;
            viewportW = Math.max(1, contentW - SCROLLBAR_WIDTH - 8);
            viewportH = Math.max(1, panelY + panelH - 18 - viewportY);
        }

        scrollContentHeight = getContentHeight();
        clampScroll();
    }

    private int getContentHeight() {
        return switch (selectedTab) {
            case 0 -> tracks.isEmpty()
                    ? 180
                    : 75 + tracks.size() * (ROW_HEIGHT + ROW_GAP);

            case 1 -> 190;
            case 2 -> 250;
            case 3 -> 250;
            default -> 1;
        };
    }

    private int maxScroll() {
        return Math.max(0, scrollContentHeight - viewportH);
    }

    private double currentScroll() {
        return selectedTab == 0 ? playlistScroll : settingsScroll;
    }

    private void setCurrentScroll(double value) {
        value = Math.max(0, Math.min(maxScroll(), value));

        if (selectedTab == 0) {
            playlistScroll = (int) Math.round(value);
        } else {
            settingsScroll = value;
        }
    }

    private void clampScroll() {
        setCurrentScroll(currentScroll());
    }

    private int scrollY(int y) {
        return (int) Math.round(y - currentScroll());
    }

    // ------------------------------------------------------------
    // DRAWING HELPERS
    // ------------------------------------------------------------

    private void fill(DrawContext ctx, int x, int y, int w, int h, int color) {
        if (w > 0 && h > 0) {
            ctx.fill(x, y, x + w, y + h, color);
        }
    }

    private void rounded(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int color
    ) {
        if (w <= 0 || h <= 0) return;

        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        if (radius == 0) {
            fill(ctx, x, y, w, h, color);
            return;
        }

        fill(ctx, x + radius, y, w - radius * 2, h, color);
        fill(ctx, x, y + radius, w, h - radius * 2, color);

        for (int i = 0; i < radius; i++) {
            double d = radius - i - 0.5;

            int inset = (int) Math.ceil(
                    radius - Math.sqrt(
                            Math.max(0, radius * radius - d * d)
                    )
            );

            fill(ctx, x + inset, y + i, w - inset * 2, 1, color);
            fill(ctx, x + inset, y + h - 1 - i, w - inset * 2, 1, color);
        }
    }

    private void border(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int borderColor,
            int background
    ) {
        rounded(ctx, x, y, w, h, radius, borderColor);
        rounded(
                ctx,
                x + 1,
                y + 1,
                w - 2,
                h - 2,
                Math.max(0, radius - 1),
                background
        );
    }

    private void drawText(
            DrawContext ctx,
            String value,
            int x,
            int y,
            int color
    ) {
        ctx.drawTextWithShadow(textRenderer, value, x, y, color);
    }

    private String trim(String value, int maxWidth) {
        if (maxWidth <= 0) return "";

        if (textRenderer.getWidth(value) <= maxWidth) {
            return value;
        }

        String suffix = "...";

        while (!value.isEmpty()
                && textRenderer.getWidth(value + suffix) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }

        return value.isEmpty() ? "" : value + suffix;
    }

    private boolean inside(
            double mx,
            double my,
            int x,
            int y,
            int w,
            int h
    ) {
        return mx >= x && mx < x + w
                && my >= y && my < y + h;
    }

    private void drawCard(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h
    ) {
        rounded(ctx, x, y, w, h, 12, CARD);
    }

    // ------------------------------------------------------------
    // WINDOW
    // ------------------------------------------------------------

    private void drawWindow(DrawContext ctx) {
        rounded(ctx, panelX - 3, panelY - 3, panelW + 6, panelH + 6, 23, 0xFF38204F);
        rounded(ctx, panelX - 1, panelY - 1, panelW + 2, panelH + 2, 21, 0xFF8A4BC2);
        rounded(ctx, panelX, panelY, panelW, panelH, 20, BACKGROUND);

        rounded(ctx, playerX, playerY, playerW, playerH, compactLayout ? 12 : 16,
                compactLayout ? CARD : SIDEBAR);

        if (!compactLayout) {
            rounded(ctx, contentX, contentY, contentW, panelH - 36, 16, PANEL);
        } else {
            rounded(ctx, contentX, contentY, contentW,
                    Math.max(1, panelY + panelH - contentY - 10), 14, PANEL);
        }
    }

    // ------------------------------------------------------------
    // NAVIGATION
    // ------------------------------------------------------------

    private void drawSidebar(DrawContext ctx, int mouseX, int mouseY) {
        if (compactLayout) {
            int gap = 5;
            int x = panelX + 12;
            int y = panelY + 10;
            int available = panelW - 24;
            int tabW = Math.max(1, (available - gap * 3) / 4);

            for (int i = 0; i < TABS.length; i++) {
                int tx = x + i * (tabW + gap);
                boolean selected = selectedTab == i;
                boolean hovered = inside(mouseX, mouseY, tx, y, tabW, 31);

                rounded(ctx, tx, y, tabW, 31, 9,
                        selected ? SELECTED : hovered ? CARD_HOVER : SIDEBAR);
                if (selected) {
                    rounded(ctx, tx + 5, y + 26, tabW - 10, 2, 1, ACCENT_LIGHT);
                }

                String label = TABS[i];
                drawText(ctx, trim(label, tabW - 8), tx + (tabW - textRenderer.getWidth(trim(label, tabW - 8))) / 2,
                        y + 11, selected ? WHITE : MUTED);
            }
            return;
        }

        rounded(ctx, panelX, panelY, sidebarW + 8, panelH, 19, SIDEBAR);
        fill(ctx, panelX + sidebarW - 5, panelY + 1, 14, panelH - 2, SIDEBAR);
        drawText(ctx, "V", panelX + 22, panelY + 20, ACCENT_LIGHT);
        fill(ctx, panelX + 18, panelY + 45, sidebarW - 30, 1, 0xFF5B496D);

        int startY = panelY + 70;
        for (int i = 0; i < TABS.length; i++) {
            int x = panelX + 9;
            int y = startY + i * 48;
            int w = sidebarW - 18;
            boolean selected = selectedTab == i;
            boolean hovered = inside(mouseX, mouseY, x, y, w, 39);

            if (selected || hovered) {
                if (hovered && !selected) {
                    rounded(ctx, x - 1, y - 1, w + 2, 41, 11, 0xFF8050A8);
                }
                rounded(ctx, x, y, w, 39, 10, selected ? SELECTED : CARD_HOVER);
            }
            if (selected) rounded(ctx, x, y + 8, 3, 23, 2, ACCENT_LIGHT);

            String icon = ICONS[i];
            drawText(ctx, icon, x + (w - textRenderer.getWidth(icon)) / 2, y + 14,
                    selected ? ACCENT_LIGHT : MUTED);
        }

        drawText(ctx, "1.0", panelX + 20, panelY + panelH - 27, MUTED);
    }

    // ------------------------------------------------------------
    // PLAYER
    // ------------------------------------------------------------

    private String getSelectedTitle() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return "No track selected";
        }

        return tracks.get(selectedTrack).title();
    }

    private String formatTime(long milliseconds) {
        long seconds = Math.max(0, milliseconds / 1000);

        return String.format(
                Locale.ROOT,
                "%02d:%02d",
                seconds / 60,
                seconds % 60
        );
    }

    private void drawAlbumArt(DrawContext ctx, int x, int y, int size) {
        rounded(ctx, x, y, size, size, 15, ACCENT_DARK);

        rounded(
                ctx,
                x + 5,
                y + 5,
                size - 10,
                size - 10,
                12,
                0xFF21152F
        );

        rounded(
                ctx,
                x + size / 5,
                y + size / 5,
                size * 3 / 5,
                size * 3 / 5,
                size / 5,
                0xFF38204F
        );

        String symbol = "♫";

        int tx = x + (size - textRenderer.getWidth(symbol)) / 2;
        int ty = y + (size - 9) / 2;

        drawText(ctx, symbol, tx, ty, ACCENT_LIGHT);

        rounded(
                ctx,
                x + size / 5,
                y + size - 13,
                size * 3 / 5,
                3,
                2,
                ACCENT
        );
    }

    private void drawVisualizer(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            boolean playing
    ) {
        int count = Math.max(8, Math.min(30, w / 7));
        int gap = 3;
        int barW = Math.max(2, (w - gap * (count - 1)) / count);

        for (int i = 0; i < count; i++) {
            int pattern = (i * 17 + i * i * 3) % 23;
            int barH = 5 + pattern * h / 35;

            if (!playing) {
                barH = 5 + pattern / 5;
            }

            int bx = x + i * (barW + gap);
            int by = y + h - barH;

            rounded(
                    ctx,
                    bx,
                    by,
                    barW,
                    barH,
                    2,
                    playing ? ACCENT : 0xFF665278
            );
        }
    }

    private void drawControl(
            DrawContext ctx,
            String symbol,
            int x,
            int y,
            int size,
            boolean primary,
            int mouseX,
            int mouseY
    ) {
        boolean hovered = inside(
                mouseX,
                mouseY,
                x,
                y,
                size,
                size
        );

        int bg;

        if (primary) {
            bg = hovered ? ACCENT_LIGHT : ACCENT;
        } else {
            bg = hovered ? CARD_HOVER : CARD_LIGHT;
        }

        if (hovered) {
            rounded(ctx, x - 2, y - 2, size + 4, size + 4, (size + 4) / 2,
                    primary ? 0xFFB979F5 : 0xFF8050A8);
        }
        rounded(ctx, x, y, size, size, size / 2, bg);

        int color = primary ? BACKGROUND : WHITE;

        int tx = x + (size - textRenderer.getWidth(symbol)) / 2;
        int ty = y + (size - 9) / 2;

        drawText(ctx, symbol, tx, ty, color);
    }

    private void drawPlayer(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {
        if (compactLayout) {
            int padding = 12;
            boolean playing = PLAYER.isPlaying();
            int controlSize = 28;
            int gap = 5;
            int controlsW = controlSize * 3 + gap * 2;
            int controlsX = playerX + playerW - controlsW - 9;
            int controlsY = playerY + (playerH - controlSize) / 2;
            int textW = Math.max(30, controlsX - playerX - padding - 8);

            drawText(ctx, "NOW PLAYING", playerX + padding, playerY + 10, ACCENT_LIGHT);
            drawText(ctx, trim(getSelectedTitle(), textW), playerX + padding, playerY + 29, WHITE);
            drawText(ctx, playing ? "PLAYING" : "STOPPED", playerX + padding, playerY + 46,
                    playing ? GREEN : MUTED);

            drawControl(ctx, "‹", controlsX, controlsY, controlSize, false, mouseX, mouseY);
            drawControl(ctx, playing ? "Ⅱ" : "▶", controlsX + controlSize + gap, controlsY,
                    controlSize, true, mouseX, mouseY);
            drawControl(ctx, "›", controlsX + (controlSize + gap) * 2, controlsY,
                    controlSize, false, mouseX, mouseY);
            return;
        }

        int padding = 17;

        int artSize = Math.min(
                Math.max(48, playerW - padding * 2),
                Math.min(170, Math.max(48, playerH / 3))
        );

        int artX = playerX + (playerW - artSize) / 2;
        int artY = playerY + 25;

        drawAlbumArt(ctx, artX, artY, artSize);

        int infoY = artY + artSize + 23;

        drawText(
                ctx,
                "NOW SELECTED",
                playerX + padding,
                infoY,
                ACCENT
        );

        drawText(
                ctx,
                trim(
                        getSelectedTitle(),
                        playerW - padding * 2
                ),
                playerX + padding,
                infoY + 20,
                WHITE
        );

        drawText(
                ctx,
                "LOCAL AUDIO",
                playerX + padding,
                infoY + 40,
                MUTED
        );

        int visualY = infoY + 75;

        drawVisualizer(
                ctx,
                playerX + padding,
                visualY,
                playerW - padding * 2,
                34,
                PLAYER.isPlaying()
        );

        fill(
                ctx,
                playerX + padding,
                visualY + 48,
                playerW - padding * 2,
                1,
                0xFF4C3A5C
        );

        boolean playing = PLAYER.isPlaying();

        drawText(
                ctx,
                playing ? "PLAYING" : "STOPPED",
                playerX + padding,
                visualY + 61,
                playing ? GREEN : MUTED
        );

        drawText(
                ctx,
                formatTime(PLAYER.getPlaybackPositionMs()),
                playerX + padding,
                visualY + 80,
                TEXT
        );

        // Controls stay near the bottom of the player panel.
        int controlSize = 38;
        int gap = 12;

        int totalW = controlSize * 3 + gap * 2;
        int controlsX = playerX + (playerW - totalW) / 2;
        int controlsY = playerY + playerH - 72;

        drawControl(
                ctx,
                "‹",
                controlsX,
                controlsY,
                controlSize,
                false,
                mouseX,
                mouseY
        );

        drawControl(
                ctx,
                playing ? "Ⅱ" : "▶",
                controlsX + controlSize + gap,
                controlsY,
                controlSize,
                true,
                mouseX,
                mouseY
        );

        drawControl(
                ctx,
                "›",
                controlsX + (controlSize + gap) * 2,
                controlsY,
                controlSize,
                false,
                mouseX,
                mouseY
        );

        drawText(
                ctx,
                "VORTEX LYRICS",
                playerX + padding,
                playerY + playerH - 20,
                MUTED
        );
    }

    // ------------------------------------------------------------
    // RIGHT HEADER
    // ------------------------------------------------------------

    private void drawHeader(DrawContext ctx) {
        String title = switch (selectedTab) {
            case 0 -> "Your Playlist";
            case 1 -> "Visual Appearance";
            case 2 -> "Text Settings";
            case 3 -> "About VortexLyrics";
            default -> "VortexLyrics";
        };

        String subtitle = switch (selectedTab) {
            case 0 -> "Your personal music collection";
            case 1 -> "Customize the interface appearance";
            case 2 -> "Customize lyrics displayed in your world";
            case 3 -> "Information about the modification";
            default -> "";
        };

        int titleY = compactLayout ? panelY + 132 : panelY + 23;
        drawText(ctx, trim(title, contentW - 8), contentX + 2, titleY, WHITE);
        drawText(ctx, trim(subtitle, contentW - 8), contentX + 2, titleY + 20, MUTED);
        fill(ctx, contentX, titleY + 42, contentW, 1, 0xFF503D65);
    }

    // ------------------------------------------------------------
    // BUTTONS
    // ------------------------------------------------------------

    private void drawButton(
            DrawContext ctx,
            String label,
            int x,
            int y,
            int w,
            int h,
            int mouseX,
            int mouseY
    ) {
        boolean hovered = inside(mouseX, mouseY, x, y, w, h);

        if (hovered) {
            rounded(ctx, x - 1, y - 1, w + 2, h + 2, 9, 0xFF8050A8);
        }
        rounded(ctx, x, y, w, h, 8, hovered ? CARD_HOVER : CARD_LIGHT);

        int tx = x + (w - textRenderer.getWidth(label)) / 2;

        drawText(
                ctx,
                label,
                tx,
                y + (h - 9) / 2,
                hovered ? WHITE : ACCENT_LIGHT
        );
    }

    // ------------------------------------------------------------
    // SCROLLBAR
    // ------------------------------------------------------------

    private void drawScrollbar(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {
        if (maxScroll() <= 0) return;

        int x = viewportX + viewportW + 3;
        int y = viewportY;
        int h = viewportH;

        rounded(ctx, x, y, 4, h, 2, TRACK);

        int thumbH = Math.max(
                24,
                h * h / Math.max(1, scrollContentHeight)
        );

        thumbH = Math.min(h, thumbH);

        int travel = h - thumbH;

        int thumbY = y + (int) Math.round(
                travel * currentScroll() / maxScroll()
        );

        boolean hovered = inside(
                mouseX,
                mouseY,
                x - 5,
                thumbY - 3,
                14,
                thumbH + 6
        ) || draggingScrollbar;

        rounded(
                ctx,
                x - (hovered ? 1 : 0),
                thumbY,
                hovered ? 6 : 4,
                thumbH,
                3,
                hovered ? ACCENT_LIGHT : ACCENT
        );
    }

    // ------------------------------------------------------------
    // PLAYLIST
    // ------------------------------------------------------------

    private void drawLrcBadge(
            DrawContext ctx,
            int x,
            int y,
            boolean hasLyrics
    ) {
        rounded(
                ctx,
                x,
                y,
                35,
                20,
                6,
                hasLyrics ? 0xFF214735 : 0xFF38333F
        );

        drawText(
                ctx,
                "LRC",
                x + 6,
                y + 6,
                hasLyrics ? GREEN : GRAY
        );
    }

    private void drawPlaylist(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {
        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int base = viewportY;

        drawText(
                ctx,
                tracks.size() + " TRACKS",
                viewportX,
                scrollY(base + 8),
                MUTED
        );

        drawButton(
                ctx,
                "REFRESH",
                viewportX + viewportW - 75,
                scrollY(base + 28),
                73,
                25,
                mouseX,
                mouseY
        );

        int rowsY = base + 72;

        if (tracks.isEmpty()) {
            drawCard(
                    ctx,
                    viewportX,
                    scrollY(rowsY),
                    viewportW,
                    100
            );

            drawText(
                    ctx,
                    "Your playlist is empty",
                    viewportX + 14,
                    scrollY(rowsY + 20),
                    TEXT
            );

            drawText(
                    ctx,
                    "Add MP3 or OGG files to:",
                    viewportX + 14,
                    scrollY(rowsY + 43),
                    MUTED
            );

            drawText(
                    ctx,
                    "vortexlyrics/music",
                    viewportX + 14,
                    scrollY(rowsY + 64),
                    ACCENT_LIGHT
            );

            ctx.disableScissor();
            return;
        }

        int step = ROW_HEIGHT + ROW_GAP;

        int first = Math.max(0, playlistScroll / step);
        int visible = viewportH / step + 3;

        for (int i = first;
             i < Math.min(tracks.size(), first + visible);
             i++) {

            int rowY = rowsY + i * step - playlistScroll;

            if (rowY + ROW_HEIGHT < viewportY
                    || rowY > viewportY + viewportH) {
                continue;
            }

            boolean selected = selectedTrack == i;

            boolean hovered = inside(
                    mouseX,
                    mouseY,
                    viewportX,
                    rowY,
                    viewportW,
                    ROW_HEIGHT
            );

            rounded(
                    ctx,
                    viewportX,
                    rowY,
                    viewportW,
                    ROW_HEIGHT,
                    9,
                    selected ? SELECTED : hovered ? CARD_HOVER : CARD
            );

            if (selected) {
                rounded(
                        ctx,
                        viewportX,
                        rowY + 8,
                        3,
                        20,
                        2,
                        ACCENT_LIGHT
                );
            }

            int badgeX = viewportX + viewportW - 44;

            drawText(
                    ctx,
                    trim(
                            tracks.get(i).title(),
                            badgeX - viewportX - 23
                    ),
                    viewportX + 13,
                    rowY + 13,
                    selected ? WHITE : TEXT
            );

            drawLrcBadge(
                    ctx,
                    badgeX,
                    rowY + 8,
                    tracks.get(i).hasLyrics()
            );
        }

        ctx.disableScissor();
    }

    // ------------------------------------------------------------
    // SLIDERS
    // ------------------------------------------------------------

    private void drawSlider(
            DrawContext ctx,
            int x,
            int y,
            int w,
            String title,
            String valueText,
            double value,
            double min,
            double max,
            int accent
    ) {
        drawCard(ctx, x, y, w, 68);

        drawText(ctx, title, x + 13, y + 12, TEXT);

        drawText(
                ctx,
                valueText,
                x + w - textRenderer.getWidth(valueText) - 13,
                y + 12,
                accent
        );

        int bx = x + 13;
        int by = y + 46;
        int bw = Math.max(1, w - 26);

        rounded(ctx, bx, by, bw, 5, 3, TRACK);

        double p = Math.max(
                0,
                Math.min(1, (value - min) / (max - min))
        );

        int filled = (int) (bw * p);

        if (filled > 0) {
            rounded(ctx, bx, by, filled, 5, 3, accent);
        }

        int knobX = Math.max(
                bx,
                Math.min(bx + bw - 8, bx + filled - 4)
        );

        rounded(
                ctx,
                knobX - 1,
                by - 4,
                11,
                13,
                5,
                0xFF38204F
        );

        rounded(
                ctx,
                knobX,
                by - 4,
                9,
                13,
                5,
                WHITE
        );
    }

    private void drawTextSettings(DrawContext ctx) {
        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int y = viewportY;

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 8),
                viewportW,
                "Spawn distance",
                String.format(
                        Locale.ROOT,
                        "%.1f blocks",
                        LyricsConfig.distance
                ),
                LyricsConfig.distance,
                3,
                30,
                ACCENT
        );

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 86),
                viewportW,
                "Text size",
                String.format(
                        Locale.ROOT,
                        "%.3f",
                        LyricsConfig.textScale
                ),
                LyricsConfig.textScale,
                0.02,
                0.09,
                0xFFE49BE0
        );

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 164),
                viewportW,
                "Text width",
                LyricsConfig.textWidth + " px",
                LyricsConfig.textWidth,
                60,
                300,
                0xFF9AA8F5
        );

        ctx.disableScissor();
    }

    // ------------------------------------------------------------
    // VISUAL SETTINGS
    // ------------------------------------------------------------

    private void drawVisual(DrawContext ctx) {
        ctx.enableScissor(viewportX, viewportY, viewportX + viewportW, viewportY + viewportH);

        int y = scrollY(viewportY + 8);
        drawCard(ctx, viewportX, y, viewportW, 150);
        drawText(ctx, "VORTEX PURPLE PALETTE", viewportX + 13, y + 13, TEXT);

        int[] colors = {0xFF08060D, 0xFF21152F, 0xFF49305F, 0xFFA855F7};
        String[] names = {"Base", "Panel", "Button", "Accent"};

        int gap = 7;
        int sw = Math.max(12, (viewportW - 26 - gap * 3) / 4);
        for (int i = 0; i < colors.length; i++) {
            int xx = viewportX + 13 + i * (sw + gap);
            border(ctx, xx, y + 43, sw, 25, 6, 0xFF8B65A8, colors[i]);
            drawText(ctx, names[i], xx, y + 77, MUTED);
        }

        drawText(ctx, "Fully opaque surfaces", viewportX + 13, y + 108, ACCENT_LIGHT);
        drawText(ctx, "No transparency or blur shaders", viewportX + 13, y + 127, MUTED);

        ctx.disableScissor();
    }

    // ------------------------------------------------------------
    // OTHER
    // ------------------------------------------------------------

    private void drawOther(DrawContext ctx) {
        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int y = viewportY;

        int cy = scrollY(y + 8);

        drawCard(ctx, viewportX, cy, viewportW, 122);

        drawText(
                ctx,
                "VortexLyrics",
                viewportX + 14,
                cy + 15,
                WHITE
        );

        drawText(
                ctx,
                trim(
                        "Minecraft music and world lyrics player.",
                        viewportW - 28
                ),
                viewportX + 14,
                cy + 40,
                TEXT
        );

        drawText(
                ctx,
                "Supported audio: MP3 / OGG",
                viewportX + 14,
                cy + 66,
                MUTED
        );

        drawText(
                ctx,
                "Lyrics format: LRC",
                viewportX + 14,
                cy + 87,
                MUTED
        );

        int ly = scrollY(y + 145);

        drawCard(ctx, viewportX, ly, viewportW, 70);

        drawText(
                ctx,
                "Music library",
                viewportX + 14,
                ly + 14,
                TEXT
        );

        drawText(
                ctx,
                "Songs found: " + tracks.size(),
                viewportX + 14,
                ly + 39,
                MUTED
        );

        ctx.disableScissor();
    }

    // ------------------------------------------------------------
    // LIBRARY / PLAYBACK
    // ------------------------------------------------------------

    private void refreshLibrary() {
        tracks = MusicLibrary.scan();

        if (tracks.isEmpty()) {
            selectedTrack = -1;
        } else if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            selectedTrack = 0;
        }

        calculateLayout();
    }

    private void playSelectedTrack() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return;
        }

        File file = tracks.get(selectedTrack).audioFile().toFile();

        if (file.equals(PLAYER.getCurrentFile()) && PLAYER.isPlaying()) {
            PLAYER.stop();
        } else {
            PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {
        if (tracks.isEmpty()) return;

        selectedTrack = selectedTrack < 0
                ? 0
                : Math.floorMod(
                        selectedTrack + direction,
                        tracks.size()
                );

        PLAYER.play(tracks.get(selectedTrack).audioFile().toFile());
    }

    // ------------------------------------------------------------
    // SLIDER INTERACTION
    // ------------------------------------------------------------

    private void updateSlider(double mouseX, int id) {
        int x = viewportX + 13;
        int w = Math.max(1, viewportW - 26);

        double p = Math.max(
                0,
                Math.min(1, (mouseX - x) / (double) w)
        );

        if (id == 0) {
            LyricsConfig.distance = 3 + p * 27;
        } else if (id == 1) {
            LyricsConfig.textScale = (float) (0.02 + p * 0.07);
        } else if (id == 2) {
            LyricsConfig.textWidth = (int) Math.round(60 + p * 240);
        }
    }

    // ------------------------------------------------------------
    // SCROLLBAR INTERACTION
    // ------------------------------------------------------------

    private boolean beginScrollbarDrag(double mx, double my) {
        if (maxScroll() <= 0) return false;

        int x = viewportX + viewportW + 3;
        int h = viewportH;

        int thumbH = Math.max(
                24,
                h * h / Math.max(1, scrollContentHeight)
        );

        thumbH = Math.min(h, thumbH);

        int travel = h - thumbH;

        int thumbY = viewportY + (int) Math.round(
                travel * currentScroll() / maxScroll()
        );

        if (inside(
                mx,
                my,
                x - 5,
                thumbY - 3,
                14,
                thumbH + 6
        )) {
            draggingScrollbar = true;
            scrollbarGrabOffset = my - thumbY;
            return true;
        }

        if (inside(
                mx,
                my,
                x - 5,
                viewportY,
                14,
                viewportH
        )) {
            double ratio = (
                    my - viewportY - thumbH / 2.0
            ) / Math.max(1, travel);

            setCurrentScroll(ratio * maxScroll());

            draggingScrollbar = true;
            scrollbarGrabOffset = thumbH / 2.0;

            return true;
        }

        return false;
    }

    private void updateScrollbarDrag(double mouseY) {
        int h = viewportH;

        int thumbH = Math.max(
                24,
                h * h / Math.max(1, scrollContentHeight)
        );

        thumbH = Math.min(h, thumbH);

        int travel = h - thumbH;

        if (travel <= 0) {
            setCurrentScroll(0);
            return;
        }

        double top = mouseY - scrollbarGrabOffset;

        setCurrentScroll(
                (top - viewportY) / travel * maxScroll()
        );
    }

    // ------------------------------------------------------------
    // RENDER
    // ------------------------------------------------------------

    @Override
    public void render(
            DrawContext ctx,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(ctx);

        calculateLayout();

        drawWindow(ctx);
        drawSidebar(ctx, mouseX, mouseY);
        drawPlayer(ctx, mouseX, mouseY);
        drawHeader(ctx);

        if (selectedTab == 0) {
            drawPlaylist(ctx, mouseX, mouseY);
        } else if (selectedTab == 1) {
            drawVisual(ctx);
        } else if (selectedTab == 2) {
            drawTextSettings(ctx);
        } else {
            drawOther(ctx);
        }

        drawScrollbar(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);
    }

    // ------------------------------------------------------------
    // MOUSE
    // ------------------------------------------------------------

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        calculateLayout();

        // Navigation
        if (compactLayout) {
            int gap = 5;
            int tabW = Math.max(1, (panelW - 24 - gap * 3) / 4);
            for (int i = 0; i < TABS.length; i++) {
                int tx = panelX + 12 + i * (tabW + gap);
                if (inside(mouseX, mouseY, tx, panelY + 10, tabW, 31)) {
                    selectedTab = i;
                    draggingSlider = -1;
                    draggingScrollbar = false;
                    calculateLayout();
                    return true;
                }
            }
        } else {
            int startY = panelY + 70;
            for (int i = 0; i < TABS.length; i++) {
                if (inside(mouseX, mouseY, panelX + 9, startY + i * 48,
                        sidebarW - 18, 39)) {
                    selectedTab = i;
                    draggingSlider = -1;
                    draggingScrollbar = false;
                    calculateLayout();
                    return true;
                }
            }
        }

        // Player controls
        int controlSize = compactLayout ? 28 : 38;
        int gap = compactLayout ? 5 : 12;
        int totalW = controlSize * 3 + gap * 2;
        int controlsX = compactLayout
                ? playerX + playerW - totalW - 9
                : playerX + (playerW - totalW) / 2;
        int controlsY = compactLayout
                ? playerY + (playerH - controlSize) / 2
                : playerY + playerH - 72;

        if (inside(
                mouseX,
                mouseY,
                controlsX,
                controlsY,
                controlSize,
                controlSize
        )) {
            changeTrack(-1);
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + controlSize + gap,
                controlsY,
                controlSize,
                controlSize
        )) {
            playSelectedTrack();
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + (controlSize + gap) * 2,
                controlsY,
                controlSize,
                controlSize
        )) {
            changeTrack(1);
            return true;
        }

        // Scrollbar
        if (beginScrollbarDrag(mouseX, mouseY)) {
            return true;
        }

        // Playlist
        if (selectedTab == 0) {
            int refreshX = viewportX + viewportW - 75;
            int refreshY = viewportY + 28 - playlistScroll;

            if (inside(
                    mouseX,
                    mouseY,
                    refreshX,
                    refreshY,
                    73,
                    25
            )) {
                refreshLibrary();
                return true;
            }

            if (inside(
                    mouseX,
                    mouseY,
                    viewportX,
                    viewportY,
                    viewportW,
                    viewportH
            )) {
                if (!tracks.isEmpty()) {
                    int rowsY = viewportY + 72;
                    int contentY = (int) mouseY + playlistScroll;

                    int index = (
                            contentY - rowsY
                    ) / (ROW_HEIGHT + ROW_GAP);

                    int rowY = rowsY
                            + index * (ROW_HEIGHT + ROW_GAP)
                            - playlistScroll;

                    if (index >= 0
                            && index < tracks.size()
                            && inside(
                                    mouseX,
                                    mouseY,
                                    viewportX,
                                    rowY,
                                    viewportW,
                                    ROW_HEIGHT
                            )) {
                        selectedTrack = index;
                    }
                }

                return true;
            }
        }

        // Settings sliders
        if (selectedTab == 2) {
            int[] offsets = {8, 86, 164};

            for (int i = 0; i < offsets.length; i++) {
                int sy = viewportY
                        + offsets[i]
                        - (int) currentScroll();

                if (inside(
                        mouseX,
                        mouseY,
                        viewportX,
                        sy + 37,
                        viewportW,
                        18
                )) {
                    draggingSlider = i;

                    updateSlider(mouseX, draggingSlider);

                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double deltaX,
            double deltaY
    ) {
        if (button == 0 && draggingSlider >= 0) {
            updateSlider(mouseX, draggingSlider);
            return true;
        }

        if (button == 0 && draggingScrollbar) {
            updateScrollbarDrag(mouseY);
            return true;
        }

        return super.mouseDragged(
                mouseX,
                mouseY,
                button,
                deltaX,
                deltaY
        );
    }

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 0
                && (draggingSlider >= 0 || draggingScrollbar)) {

            boolean changedConfig = draggingSlider >= 0;

            draggingSlider = -1;
            draggingScrollbar = false;

            if (changedConfig) {
                LyricsConfig.save();
            }

            return true;
        }

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {
        calculateLayout();

        if (inside(
                mouseX,
                mouseY,
                viewportX,
                viewportY,
                viewportW + SCROLLBAR_WIDTH + 8,
                viewportH
        )) {
            setCurrentScroll(currentScroll() - amount * 24);
            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public void resize(
            MinecraftClient client,
            int width,
            int height
    ) {
        super.resize(client, width, height);
        calculateLayout();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

