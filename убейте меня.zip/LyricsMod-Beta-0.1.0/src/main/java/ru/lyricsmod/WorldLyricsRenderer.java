
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WorldLyricsRenderer {

    private static final Pattern TIMESTAMP =
            Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");

    private static final List<LyricLine> LINES = new ArrayList<>();

    private static Path loadedFile;
    private static int currentLine = -1;
    private static long lineChangedAt;
    private static String displayedText = "";

    private WorldLyricsRenderer() {
    }

    public static void register() {
        WorldRenderEvents.LAST.register(
                WorldLyricsRenderer::render
        );
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null
                || client.world == null
                || client.textRenderer == null) {
            return;
        }

        File audioFile = MusicPlayer.getActiveFile();

        if (audioFile == null) {
            clear();
            return;
        }

        updateLyrics(audioFile);

        if (LINES.isEmpty()) {
            return;
        }

        long position = MusicPlayer.getActivePlaybackPositionMs();
        int lineIndex = findCurrentLine(position);

        if (lineIndex < 0 || lineIndex >= LINES.size()) {
            return;
        }

        if (lineIndex != currentLine) {
            currentLine = lineIndex;
            displayedText = LINES.get(lineIndex).text();
            lineChangedAt = System.currentTimeMillis();
        }

        if (displayedText.isBlank()) {
            return;
        }

        float alpha = Math.min(
                1.0f,
                (System.currentTimeMillis() - lineChangedAt) / 250.0f
        );

        renderText(context, displayedText, alpha);
    }

    private static void updateLyrics(File audioFile) {
        Path audioPath = audioFile.toPath().toAbsolutePath();

        if (audioPath.equals(loadedFile)) {
            return;
        }

        loadedFile = audioPath;
        currentLine = -1;
        displayedText = "";
        LINES.clear();

        for (MusicLibrary.Track track : MusicLibrary.scan()) {
            if (track.audioFile().toAbsolutePath().equals(audioPath)) {
                if (track.lyricsFile() != null) {
                    loadLrc(track.lyricsFile());
                }
                return;
            }
        }
    }

    private static void loadLrc(Path file) {
        try {
            List<String> lines = Files.readAllLines(
                    file,
                    StandardCharsets.UTF_8
            );

            for (String line : lines) {
                Matcher matcher = TIMESTAMP.matcher(line);

                List<Long> timestamps = new ArrayList<>();

                while (matcher.find()) {
                    long minutes = Long.parseLong(matcher.group(1));
                    long seconds = Long.parseLong(matcher.group(2));

                    String fraction = matcher.group(3);
                    long millis = 0L;

                    if (fraction != null) {
                        millis = Long.parseLong(
                                (fraction + "00").substring(0, 3)
                        );
                    }

                    timestamps.add(
                            minutes * 60_000L
                                    + seconds * 1_000L
                                    + millis
                    );
                }

                if (timestamps.isEmpty()) {
                    continue;
                }

                String text = TIMESTAMP.matcher(line)
                        .replaceAll("")
                        .trim();

                if (text.isEmpty()) {
                    continue;
                }

                for (long timestamp : timestamps) {
                    LINES.add(new LyricLine(timestamp, text));
                }
            }

            LINES.sort(Comparator.comparingLong(LyricLine::time));

            System.out.println(
                    "[VortexLyrics] Loaded " + LINES.size()
                            + " lyric lines."
            );

        } catch (Exception exception) {
            System.err.println(
                    "[VortexLyrics] Failed to load LRC: " + file
            );
            exception.printStackTrace();
        }
    }

    private static int findCurrentLine(long position) {
        int result = -1;

        for (int i = 0; i < LINES.size(); i++) {
            if (LINES.get(i).time() <= position) {
                result = i;
            } else {
                break;
            }
        }

        return result;
    }

    private static void renderText(
            WorldRenderContext context,
            String text,
            float alpha
    ) {
        MinecraftClient client = MinecraftClient.getInstance();

        Vec3d cameraPos = context.camera().getPos();
        Vec3d playerPos = client.player.getPos();

        Vec3d look = client.player.getRotationVec(context.tickDelta());

        Vec3d worldPos = playerPos
                .add(0, client.player.getStandingEyeHeight() * 0.65, 0)
                .add(look.multiply(2.8));

        Vec3d relativePos = worldPos.subtract(cameraPos);

        MatrixStack matrices = context.matrixStack();

        if (matrices == null || context.consumers() == null) {
            return;
        }

        matrices.push();

        matrices.translate(
                relativePos.x,
                relativePos.y,
                relativePos.z
        );

        matrices.multiply(context.camera().getRotation());

        matrices.scale(-0.025f, -0.025f, 0.025f);

        TextRenderer renderer = client.textRenderer;

        float width = renderer.getWidth(text);
        float x = -width / 2.0f;

        int a = Math.max(0, Math.min(255, (int) (255 * alpha)));
        int white = (a << 24) | 0x00FFFFFF;
        int dark = (a << 24) | 0x00251F30;

        // Тёмная боковая грань — имитация объёма.
        renderer.draw(
                text, x + 2, 2, dark, false,
                matrices.peek().getPositionMatrix(),
                context.consumers(),
                TextRenderer.TextLayerType.NORMAL,
                0,
                LightmapTextureManager.MAX_LIGHT_COORDINATE
        );

        renderer.draw(
                text, x + 1, 1, dark, false,
                matrices.peek().getPositionMatrix(),
                context.consumers(),
                TextRenderer.TextLayerType.NORMAL,
                0,
                LightmapTextureManager.MAX_LIGHT_COORDINATE
        );

        // Основная белая поверхность букв.
        renderer.draw(
                text, x, 0, white, false,
                matrices.peek().getPositionMatrix(),
                context.consumers(),
                TextRenderer.TextLayerType.NORMAL,
                0,
                LightmapTextureManager.MAX_LIGHT_COORDINATE
        );

        matrices.pop();
    }

    private static void clear() {
        loadedFile = null;
        currentLine = -1;
        displayedText = "";
        LINES.clear();
    }

    private record LyricLine(long time, String text) {
    }
}
