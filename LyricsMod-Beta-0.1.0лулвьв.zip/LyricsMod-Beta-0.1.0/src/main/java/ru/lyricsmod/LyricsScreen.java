
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class LyricsScreen extends Screen {

    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFC9B5DC;
    private static final int PURPLE = 0xFFD9B0FF;

    private int selectedTab = 0;

    private final float[] hoverProgress = new float[3];

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
    }

    private void roundedRect(
            DrawContext context,
            int x, int y, int w, int h,
            int radius, int color
    ) {
        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        for (int row = 0; row < h; row++) {
            int edge = Math.min(row, h - 1 - row);
            int inset = 0;

            if (edge < radius) {
                double distance = radius - edge;
                inset = radius - (int) Math.sqrt(
                        radius * radius - distance * distance
                );
            }

            context.fill(
                    x + inset,
                    y + row,
                    x + w - inset,
                    y + row + 1,
                    color
            );
        }
    }

    private void glassPanel(
            DrawContext context,
            int x, int y, int w, int h
    ) {
        roundedRect(context, x - 4, y - 4,
                w + 8, h + 8, 20, 0x249D55E8);

        roundedRect(context, x - 2, y - 2,
                w + 4, h + 4, 19, 0x559B5AE0);

        roundedRect(context, x, y,
                w, h, 17, 0xF0181423);

        roundedRect(context, x + 1, y + 1,
                w - 2, h - 2, 16, 0xE91C1729);
    }

    private void drawPlayIcon(
            DrawContext context, int x, int y, int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(
                    x + i, y + i,
                    x + i + 1, y + 17 - i,
                    color
            );
        }
    }

    private void drawSlidersIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x, y + 3, x + 19, y + 5, color);
        context.fill(x, y + 9, x + 19, y + 11, color);
        context.fill(x, y + 15, x + 19, y + 17, color);

        context.fill(x + 5, y + 1, x + 9, y + 7, color);
        context.fill(x + 13, y + 7, x + 17, y + 13, color);
        context.fill(x + 7, y + 13, x + 11, y + 19, color);
    }

    private void drawSettingsIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x + 7, y, x + 12, y + 19, color);
        context.fill(x, y + 7, x + 19, y + 12, color);

        context.fill(x + 3, y + 2, x + 7, y + 6, color);
        context.fill(x + 12, y + 13, x + 16, y + 17, color);
        context.fill(x + 3, y + 13, x + 7, y + 17, color);
        context.fill(x + 12, y + 2, x + 16, y + 6, color);

        roundedRect(context, x + 6, y + 6,
                7, 7, 3, 0xFF59416F);
    }

    private void drawTab(
            DrawContext context,
            int x, int y,
            String label,
            int tab,
            boolean hovered,
            float delta
    ) {
        boolean active = selectedTab == tab;

        float target = hovered ? 1.0f : 0.0f;

        hoverProgress[tab] +=
                (target - hoverProgress[tab])
                        * Math.min(1.0f, delta * 0.7f);

        float progress = hoverProgress[tab];

        float scale = 1.0f + progress * 0.04f;

        int normalColor = active
                ? 0xFF9664C5
                : 0xFF59416F;

        int hoverColor = active
                ? 0xFFAD7BE0
                : 0xFF8055A8;

        int background = lerpColor(
                normalColor, hoverColor, progress
        );

        float centerX = x + 65.5f;
        float centerY = y + 17.0f;

        context.getMatrices().push();

        context.getMatrices().translate(
                centerX, centerY, 0
        );

        context.getMatrices().scale(
                scale, scale, 1.0f
        );

        context.getMatrices().translate(
                -centerX, -centerY, 0
        );

        // Свечение при наведении
        if (progress > 0.01f) {
            roundedRect(
                    context,
                    x - 3, y - 3,
                    137, 40,
                    12,
                    (int) (progress * 0x559D55E8)
            );

            roundedRect(
                    context,
                    x - 1, y - 1,
                    133, 36,
                    10,
                    (int) (progress * 0x669D55E8)
            );
        }

        // Подложка кнопки
        roundedRect(
                context,
                x, y, 131, 34,
                9, background
        );

        int iconColor = LIGHT;

        if (tab == 0) {
            drawPlayIcon(
                    context, x + 12, y + 9, iconColor
            );
        } else if (tab == 1) {
            drawSlidersIcon(
                    context, x + 12, y + 7, iconColor
            );
        } else {
            drawSettingsIcon(
                    context, x + 12, y + 7, iconColor
            );
        }

        context.drawTextWithShadow(
                textRenderer,
                Text.literal(label),
                x + 43, y + 12,
                LIGHT
        );

        context.getMatrices().pop();
    }

    private int lerpColor(int from, int to, float amount) {
        int a = lerpChannel(
                (from >> 24) & 255,
                (to >> 24) & 255, amount
        );

        int r = lerpChannel(
                (from >> 16) & 255,
                (to >> 16) & 255, amount
        );

        int g = lerpChannel(
                (from >> 8) & 255,
                (to >> 8) & 255, amount
        );

        int b = lerpChannel(
                from & 255,
                to & 255, amount
        );

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int lerpChannel(int from, int to, float amount) {
        return (int) (from + (to - from) * amount);
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        int w = Math.min(560, width - 24);
        int h = Math.min(340, height - 24);

        int x = (width - w) / 2;
        int y = (height - h) / 2;

        glassPanel(context, x, y, w, h);

        roundedRect(
                context,
                x + 15, y + 14,
                w - 30, 45,
                11, 0xFF241B34
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("VortexLyrics"),
                x + 29, y + 23, LIGHT
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("BETA 0.1.0"),
                x + 29, y + 39, MUTED
        );

        int sidebarX = x + 15;
        int sidebarY = y + 70;
        int sidebarW = 145;
        int sidebarH = h - 130;

        roundedRect(
                context,
                sidebarX, sidebarY,
                sidebarW, sidebarH,
                12, 0xFF211A30
        );

        int tabX = sidebarX + 7;

        drawTab(
                context, tabX, sidebarY + 10,
                "Playlist", 0,
                isHovered(mouseX, mouseY, tabX, sidebarY + 10),
                delta
        );

        drawTab(
                context, tabX, sidebarY + 52,
                "Visual", 1,
                isHovered(mouseX, mouseY, tabX, sidebarY + 52),
                delta
        );

        drawTab(
                context, tabX, sidebarY + 94,
                "Other", 2,
                isHovered(mouseX, mouseY, tabX, sidebarY + 94),
                delta
        );

        int contentX = sidebarX + sidebarW + 13;
        int contentY = sidebarY;
        int contentW = w - sidebarW - 43;
        int contentH = sidebarH;

        roundedRect(
                context,
                contentX, contentY,
                contentW, contentH,
                12, 0xCC251D34
        );

        if (selectedTab == 0) {
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Welcome to VortexLyrics"),
                    contentX + 17, contentY + 19, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Your music experience starts here."),
                    contentX + 17, contentY + 39, MUTED
            );

        } else if (selectedTab == 1) {
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Visual"),
                    contentX + 17, contentY + 19, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Visual settings are coming soon."),
                    contentX + 17, contentY + 39, MUTED
            );

        } else {
            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Other"),
                    contentX + 17, contentY + 19, LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    Text.literal("Other settings are coming soon."),
                    contentX + 17, contentY + 39, MUTED
            );
        }

        int barY = y + h - 48;

        roundedRect(
                context,
                x + 15, barY,
                w - 30, 34,
                10, 0xFF30243F
        );

        roundedRect(
                context,
                x + 22, barY + 6,
                22, 22,
                7, 0xFF8052A9
        );

        drawPlayIcon(
                context, x + 29, barY + 9,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("VORTEXLYRICS PLAYER"),
                x + 55, barY + 13, LIGHT
        );

        super.render(context, mouseX, mouseY, delta);
    }

    private boolean isHovered(
            int mouseX, int mouseY,
            int x, int y
    ) {
        return mouseX >= x && mouseX <= x + 131
                && mouseY >= y && mouseY <= y + 34;
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 0) {
            int w = Math.min(560, width - 24);
            int h = Math.min(340, height - 24);

            int x = (width - w) / 2;
            int y = (height - h) / 2;

            int sidebarX = x + 15;
            int sidebarY = y + 70;
            int tabX = sidebarX + 7;

            if (mouseX >= tabX && mouseX <= tabX + 131) {
                if (mouseY >= sidebarY + 10
                        && mouseY <= sidebarY + 44) {
                    selectedTab = 0;
                    return true;
                }

                if (mouseY >= sidebarY + 52
                        && mouseY <= sidebarY + 86) {
                    selectedTab = 1;
                    return true;
                }

                if (mouseY >= sidebarY + 94
                        && mouseY <= sidebarY + 128) {
                    selectedTab = 2;
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

