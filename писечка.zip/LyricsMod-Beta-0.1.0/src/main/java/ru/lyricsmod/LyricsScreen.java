
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;
import java.util.Locale;

public class LyricsScreen extends Screen {

    private static final int WHITE = 0xFFF7F0FF;
    private static final int LIGHT = 0xFFE6D7F5;
    private static final int MUTED = 0xFF9D8EAE;

    private static final int PURPLE = 0xFFAC75E8;
    private static final int PURPLE_DARK = 0xFF7550A5;

    private static final int BACKGROUND = 0xF0100D18;
    private static final int SIDEBAR = 0xFF191322;
    private static final int PANEL = 0xFF21192D;
    private static final int CARD = 0xFF2A2038;
    private static final int CARD_HOVER = 0xFF382747;

    private static final int GREEN = 0xFF65D99A;
    private static final int GRAY = 0xFF777080;

    private static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private static final String[] TABS = {
            "Playlist",
            "Visual",
            "Text",
            "Other"
    };

    private List<MusicLibrary.Track> tracks = List.of();

    private int selectedTab = 0;
    private int selectedTrack = -1;
    private int playlistScroll = 0;
    private int draggingSlider = -1;

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    private int sidebarW = 142;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
        refreshLibrary();
    }

    private void refreshLibrary() {
        tracks = MusicLibrary.scan();

        if (tracks.isEmpty()) {
            selectedTrack = -1;
        } else if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            selectedTrack = 0;
        }

        playlistScroll = Math.min(
                playlistScroll,
                Math.max(0, tracks.size() - 1)
        );
    }

    private void playSelectedTrack() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return;
        }

        File file = tracks.get(selectedTrack).audioFile().toFile();

        if (file.equals(MUSIC_PLAYER.getCurrentFile())
                && MUSIC_PLAYER.isPlaying()) {
            MUSIC_PLAYER.stop();
        } else {
            MUSIC_PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {
        if (tracks.isEmpty()) {
            return;
        }

        if (selectedTrack < 0) {
            selectedTrack = 0;
        } else {
            selectedTrack = Math.floorMod(
                    selectedTrack + direction,
                    tracks.size()
            );
        }

        playSelectedTrack();
    }

    private void calculateLayout() {
        panelW = Math.min(700, width - 24);
        panelH = Math.min(430, height - 24);

        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        sidebarW = Math.min(150, panelW / 3);
    }

    private int contentX() {
        return panelX + sidebarW + 24;
    }

    private int contentY() {
        return panelY + 76;
    }

    private int contentWidth() {
        return panelW - sidebarW - 44;
    }

    private int contentBottom() {
        return panelY + panelH - 75;
    }

    private void fill(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int color
    ) {
        if (w <= 0 || h <= 0) {
            return;
        }

        context.fill(x, y, x + w, y + h, color);
    }

    private void text(
            DrawContext context,
            String value,
            int x,
            int y,
            int color
    ) {
        context.drawTextWithShadow(
                textRenderer,
                value,
                x,
                y,
                color
        );
    }

    private String trimText(String value, int maxWidth) {
        if (textRenderer.getWidth(value) <= maxWidth) {
            return value;
        }

        while (!value.isEmpty()
                && textRenderer.getWidth(value + "...") > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }

        return value + "...";
    }

    private void drawCard(
            DrawContext context,
            int x,
            int y,
            int w,
            int h
    ) {
        fill(context, x, y, w, h, CARD);
    }

    private void drawHeader(DrawContext context) {
        text(
                context,
                "VortexLyrics",
                panelX + 17,
                panelY + 16,
                WHITE
        );

        text(
                context,
                "MUSIC EXPERIENCE",
                panelX + 17,
                panelY + 31,
                MUTED
        );

        fill(
                context,
                panelX + 17,
                panelY + 49,
                panelW - 34,
                1,
                0xFF40304E
        );
    }

    private void drawSidebar(DrawContext context, int mouseX, int mouseY) {
        fill(
                context,
                panelX,
                panelY,
                sidebarW,
                panelH,
                SIDEBAR
        );

        String[] icons = {
                "♫",
                "◈",
                "T",
                "i"
        };

        int startY = panelY + 75;

        for (int i = 0; i < TABS.length; i++) {
            int y = startY + i * 43;

            boolean selected = selectedTab == i;

            boolean hovered =
                    mouseX >= panelX + 10
                    && mouseX <= panelX + sidebarW - 10
                    && mouseY >= y
                    && mouseY <= y + 34;

            if (selected) {
                fill(
                        context,
                        panelX + 10,
                        y,
                        sidebarW - 20,
                        34,
                        0xFF51356E
                );

                fill(
                        context,
                        panelX + 10,
                        y + 5,
                        3,
                        24,
                        PURPLE
                );
            } else if (hovered) {
                fill(
                        context,
                        panelX + 10,
                        y,
                        sidebarW - 20,
                        34,
                        CARD_HOVER
                );
            }

            text(
                    context,
                    icons[i],
                    panelX + 22,
                    y + 11,
                    selected ? WHITE : MUTED
            );

            text(
                    context,
                    TABS[i],
                    panelX + 43,
                    y + 11,
                    selected ? WHITE : LIGHT
            );
        }

        fill(
                context,
                panelX + sidebarW - 1,
                panelY + 60,
                1,
                panelH - 72,
                0xFF382A45
        );

        text(
                context,
                "VORTEX",
                panelX + 17,
                panelY + panelH - 25,
                MUTED
        );
    }

    private void drawTitle(
            DrawContext context,
            String title,
            String subtitle
    ) {
        int x = contentX();
        int y = contentY();

        text(context, title, x, y, WHITE);
        text(context, subtitle, x, y + 17, MUTED);
    }

    private void drawLrcBadge(
            DrawContext context,
            int x,
            int y,
            boolean hasLyrics
    ) {
        int color = hasLyrics ? GREEN : GRAY;
        int background = hasLyrics
                ? 0xFF214534
                : 0xFF38333F;

        fill(context, x, y, 30, 15, background);

        text(
                context,
                "LRC",
                x + 5,
                y + 4,
                color
        );
    }

    private void drawPlaylist(DrawContext context, int mouseX, int mouseY) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Your Playlist",
                "Your music collection"
        );

        text(
                context,
                tracks.size() + " TRACKS",
                x,
                y + 38,
                MUTED
        );

        int refreshX = x + w - 62;

        boolean refreshHover =
                mouseX >= refreshX
                && mouseX <= refreshX + 60
                && mouseY >= y + 33
                && mouseY <= y + 55;

        text(
                context,
                "REFRESH",
                refreshX,
                y + 40,
                refreshHover ? WHITE : PURPLE
        );

        int listY = y + 65;
        int rowHeight = 30;

        int visible = Math.max(
                1,
                (contentBottom() - listY) / rowHeight
        );

        if (tracks.isEmpty()) {
            drawCard(context, x, listY, w, 70);

            text(
                    context,
                    "Your playlist is empty",
                    x + 12,
                    listY + 15,
                    LIGHT
            );

            text(
                    context,
                    "Add MP3 or OGG files to vortexlyrics/music",
                    x + 12,
                    listY + 34,
                    MUTED
            );

            return;
        }

        for (int i = playlistScroll;
             i < Math.min(tracks.size(), playlistScroll + visible);
             i++) {

            int rowY = listY + (i - playlistScroll) * rowHeight;

            boolean selected = selectedTrack == i;

            boolean hovered =
                    mouseX >= x
                    && mouseX <= x + w
                    && mouseY >= rowY
                    && mouseY <= rowY + 26;

            int color = selected
                    ? 0xFF49315F
                    : hovered ? CARD_HOVER : CARD;

            fill(context, x, rowY, w, 26, color);

            if (selected) {
                fill(
                        context,
                        x,
                        rowY + 4,
                        3,
                        18,
                        PURPLE
                );
            }

            String title = trimText(
                    tracks.get(i).title(),
                    w - 75
            );

            text(
                    context,
                    title,
                    x + 10,
                    rowY + 9,
                    selected ? WHITE : LIGHT
            );

            drawLrcBadge(
                    context,
                    x + w - 39,
                    rowY + 6,
                    tracks.get(i).hasLyrics()
            );
        }
    }

    private void drawSlider(
            DrawContext context,
            int x,
            int y,
            int w,
            String title,
            String valueText,
            double value,
            double min,
            double max
    ) {
        drawCard(context, x, y, w, 65);

        text(
                context,
                title,
                x + 11,
                y + 9,
                LIGHT
        );

        text(
                context,
                valueText,
                x + w - textRenderer.getWidth(valueText) - 11,
                y + 9,
                PURPLE
        );

        int barX = x + 11;
        int barY = y + 43;
        int barW = w - 22;

        fill(
                context,
                barX,
                barY,
                barW,
                4,
                0xFF493958
        );

        double progress = Math.max(
                0,
                Math.min(1, (value - min) / (max - min))
        );

        int filled = (int) (barW * progress);

        fill(
                context,
                barX,
                barY,
                filled,
                4,
                PURPLE
        );

        int knobX = barX + filled;

        fill(
                context,
                knobX - 4,
                barY - 4,
                9,
                12,
                WHITE
        );
    }

    private void drawTextSettings(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Text Settings",
                "Customize lyrics displayed in your world"
        );

        drawSlider(
                context,
                x,
                y + 48,
                w,
                "Spawn distance",
                String.format(
                        Locale.ROOT,
                        "%.1f blocks",
                        LyricsConfig.distance
                ),
                LyricsConfig.distance,
                3,
                30
        );

        drawSlider(
                context,
                x,
                y + 122,
                w,
                "Text size",
                String.format(
                        Locale.ROOT,
                        "%.3f",
                        LyricsConfig.textScale
                ),
                LyricsConfig.textScale,
                0.02,
                0.09
        );

        drawSlider(
                context,
                x,
                y + 196,
                w,
                "Text width",
                LyricsConfig.textWidth + " px",
                LyricsConfig.textWidth,
                60,
                300
        );

        text(
                context,
                "Words wrap automatically without splitting.",
                x,
                y + 275,
                MUTED
        );
    }

    private void drawVisual(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "Visual Appearance",
                "VortexLyrics interface style"
        );

        int cardY = y + 50;

        drawCard(context, x, cardY, w, 100);

        text(
                context,
                "Current theme",
                x + 13,
                cardY + 13,
                LIGHT
        );

        text(
                context,
                "Violet",
                x + 13,
                cardY + 36,
                PURPLE
        );

        text(
                context,
                "Dark panels and purple accents",
                x + 13,
                cardY + 57,
                MUTED
        );

        int swatchY = cardY + 78;

        fill(context, x + 13, swatchY, 22, 7, BACKGROUND);
        fill(context, x + 40, swatchY, 22, 7, SIDEBAR);
        fill(context, x + 67, swatchY, 22, 7, CARD);
        fill(context, x + 94, swatchY, 22, 7, PURPLE);

        drawCard(context, x, cardY + 112, w, 65);

        text(
                context,
                "Lightweight rendering",
                x + 13,
                cardY + 126,
                LIGHT
        );

        text(
                context,
                "No blur shaders or expensive effects.",
                x + 13,
                cardY + 147,
                MUTED
        );
    }

    private void drawOther(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawTitle(
                context,
                "About VortexLyrics",
                "Information and links"
        );

        int cardY = y + 48;

        drawCard(context, x, cardY, w, 105);

        text(
                context,
                "VortexLyrics",
                x + 13,
                cardY + 14,
                WHITE
        );

        text(
                context,
                "Minecraft music and world lyrics player.",
                x + 13,
                cardY + 36,
                LIGHT
        );

        text(
                context,
                "Supported audio: MP3 / OGG",
                x + 13,
                cardY + 58,
                MUTED
        );

        text(
                context,
                "Lyrics format: LRC",
                x + 13,
                cardY + 76,
                MUTED
        );

        drawCard(context, x, cardY + 117, w, 55);

        text(
                context,
                "Music library",
                x + 13,
                cardY + 130,
                LIGHT
        );

        text(
                context,
                "Songs found: " + tracks.size(),
                x + 13,
                cardY + 150,
                MUTED
        );
    }

    private void drawMiniPlayer(DrawContext context, int mouseX, int mouseY) {
        int x = panelX + 13;
        int y = panelY + panelH - 57;
        int w = panelW - 26;

        fill(context, x, y, w, 44, 0xFF251C31);

        fill(
                context,
                x,
                y,
                w,
                1,
                0xFF59406F
        );

        String trackName = selectedTrack >= 0
                && selectedTrack < tracks.size()
                ? tracks.get(selectedTrack).title()
                : "No track selected";

        text(
                context,
                trimText(trackName, Math.max(50, w - 180)),
                x + 10,
                y + 9,
                LIGHT
        );

        text(
                context,
                "VORTEX PLAYER",
                x + 10,
                y + 25,
                MUTED
        );

        int controlsX = x + w - 112;

        text(
                context,
                "<",
                controlsX,
                y + 15,
                WHITE
        );

        boolean playing = MUSIC_PLAYER.isPlaying();

        text(
                context,
                playing ? "||" : ">",
                controlsX + 32,
                y + 15,
                PURPLE
        );

        text(
                context,
                ">",
                controlsX + 72,
                y + 15,
                WHITE
        );
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        calculateLayout();

        fill(
                context,
                panelX - 1,
                panelY - 1,
                panelW + 2,
                panelH + 2,
                0xFF70518D
        );

        fill(
                context,
                panelX,
                panelY,
                panelW,
                panelH,
                BACKGROUND
        );

        drawHeader(context);
        drawSidebar(context, mouseX, mouseY);

        if (selectedTab == 0) {
            drawPlaylist(context, mouseX, mouseY);
        } else if (selectedTab == 1) {
            drawVisual(context);
        } else if (selectedTab == 2) {
            drawTextSettings(context);
        } else {
            drawOther(context);
        }

        drawMiniPlayer(context, mouseX, mouseY);

        super.render(context, mouseX, mouseY, delta);
    }

    private void updateSlider(double mouseX, int id) {
        int x = contentX() + 11;
        int w = contentWidth() - 22;

        double progress = Math.max(
                0,
                Math.min(1, (mouseX - x) / (double) w)
        );

        if (id == 0) {
            LyricsConfig.distance = 3 + progress * 27;
        } else if (id == 1) {
            LyricsConfig.textScale =
                    (float) (0.02 + progress * 0.07);
        } else if (id == 2) {
            LyricsConfig.textWidth =
                    (int) Math.round(60 + progress * 240);
        }
    }

    private boolean inside(
            double mouseX,
            double mouseY,
            int x,
            int y,
            int w,
            int h
    ) {
        return mouseX >= x
                && mouseX <= x + w
                && mouseY >= y
                && mouseY <= y + h;
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        calculateLayout();

        int startY = panelY + 75;

        for (int i = 0; i < TABS.length; i++) {
            int y = startY + i * 43;

            if (inside(
                    mouseX,
                    mouseY,
                    panelX + 10,
                    y,
                    sidebarW - 20,
                    34
            )) {
                selectedTab = i;
                draggingSlider = -1;
                return true;
            }
        }

        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        if (selectedTab == 0) {
            int refreshX = x + w - 62;

            if (inside(
                    mouseX,
                    mouseY,
                    refreshX,
                    y + 33,
                    60,
                    22
            )) {
                refreshLibrary();
                return true;
            }

            int listY = y + 65;
            int rowHeight = 30;

            int visible = Math.max(
                    1,
                    (contentBottom() - listY) / rowHeight
            );

            for (int i = playlistScroll;
                 i < Math.min(tracks.size(), playlistScroll + visible);
                 i++) {

                int rowY = listY + (i - playlistScroll) * rowHeight;

                if (inside(mouseX, mouseY, x, rowY, w, 26)) {
                    selectedTrack = i;
                    return true;
                }
            }
        }

        if (selectedTab == 2) {
            int[] sliderY = {
                    y + 48 + 43,
                    y + 122 + 43,
                    y + 196 + 43
            };

            for (int i = 0; i < 3; i++) {
                if (inside(
                        mouseX,
                        mouseY,
                        x + 5,
                        sliderY[i] - 10,
                        w - 10,
                        24
                )) {
                    draggingSlider = i;
                    updateSlider(mouseX, i);
                    LyricsConfig.save();
                    return true;
                }
            }
        }

        int playerY = panelY + panelH - 57;
        int controlsX = panelX + 13 + panelW - 26 - 112;

        if (inside(
                mouseX,
                mouseY,
                controlsX - 5,
                playerY,
                25,
                44
        )) {
            changeTrack(-1);
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + 24,
                playerY,
                38,
                44
        )) {
            playSelectedTrack();
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + 65,
                playerY,
                30,
                44
        )) {
            changeTrack(1);
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double deltaX,
            double deltaY
    ) {
        if (draggingSlider >= 0 && button == 0) {
            updateSlider(mouseX, draggingSlider);
            return true;
        }

        return super.mouseDragged(
                mouseX,
                mouseY,
                button,
                deltaX,
                deltaY
        );
    }

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (draggingSlider >= 0) {
            draggingSlider = -1;
            LyricsConfig.save();
            return true;
        }

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {
        if (selectedTab == 0) {
            int visible = Math.max(
                    1,
                    (contentBottom() - contentY() - 65) / 30
            );

            int maxScroll = Math.max(
                    0,
                    tracks.size() - visible
            );

            playlistScroll -= (int) Math.signum(amount);

            playlistScroll = Math.max(
                    0,
                    Math.min(maxScroll, playlistScroll)
            );

            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

