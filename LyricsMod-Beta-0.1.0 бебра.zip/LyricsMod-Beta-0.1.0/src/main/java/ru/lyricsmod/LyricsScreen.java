
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

public class LyricsScreen extends Screen {

    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFC9B5DC;

    private int selectedTab = 0;
    private final float[] hoverProgress = new float[3];

    private float playerProgress = 0.0f;
    private boolean playerOpen = false;

    // 1 = маленький, 2 = средний, 3 = большой
    private int interfaceScale = 2;

    private String currentTrackTitle = "No track selected";
    private float scrollTime = 0.0f;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
    }

    private float getInterfaceScale() {
        if (interfaceScale == 1) return 0.85f;
        if (interfaceScale == 3) return 1.15f;
        return 1.0f;
    }

    private int getMainX() {
        return width / 2;
    }

    private int getMainWidth() {
        return width - getMainX() - 12;
    }

    private int getMainHeight() {
        return Math.max(1, Math.min(340, height - 24));
    }

    private int getMainY() {
        return (height - getMainHeight()) / 2;
    }

    private int getPlayerSize() {
        return Math.max(130,
                Math.min(220, Math.min(height - 48, width / 2 - 32)));
    }

    private int getPlayerY() {
        return (height - getPlayerSize()) / 2;
    }

    private int getPlayerX() {
        int mainX = getMainX();
        int size = getPlayerSize();

        return mainX - size - 12
                + (int) ((size + 12) * (1.0f - playerProgress));
    }

    private double getUnscaledMouseX(double mouseX) {
        float scale = getInterfaceScale();
        return width / 2.0 + (mouseX - width / 2.0) / scale;
    }

    private double getUnscaledMouseY(double mouseY) {
        float scale = getInterfaceScale();
        return height / 2.0 + (mouseY - height / 2.0) / scale;
    }

    private void drawClippedText(
            DrawContext context, String text,
            int x, int y, int maxWidth, int color
    ) {
        if (maxWidth <= 0) return;

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);
        context.drawTextWithShadow(textRenderer, text, x, y, color);
        context.disableScissor();
    }

    private void drawWrappedText(
            DrawContext context, String text,
            int x, int y, int maxWidth, int maxHeight, int color
    ) {
        if (maxWidth <= 0 || maxHeight <= 0) return;

        List<OrderedText> lines =
                textRenderer.wrapLines(Text.literal(text), maxWidth);

        context.enableScissor(x, y - 2, x + maxWidth, y + maxHeight);

        int lineY = y;

        for (OrderedText line : lines) {
            if (lineY + 9 > y + maxHeight) break;

            context.drawTextWithShadow(textRenderer, line, x, lineY, color);
            lineY += 10;
        }

        context.disableScissor();
    }

    private void drawScrollingText(
            DrawContext context, String text,
            int x, int y, int maxWidth, int color
    ) {
        if (maxWidth <= 0 || text == null || text.isEmpty()) return;

        int textWidth = textRenderer.getWidth(text);

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);

        if (textWidth <= maxWidth) {
            context.drawTextWithShadow(textRenderer, text, x, y, color);
        } else {
            float delay = 1.2f;
            float speed = 24.0f;
            float gap = 28.0f;

            float elapsed = Math.max(0.0f, scrollTime - delay);
            float offset = (elapsed * speed) % (textWidth + gap);

            int drawX = x - (int) offset;

            context.drawTextWithShadow(textRenderer, text, drawX, y, color);
            context.drawTextWithShadow(
                    textRenderer, text,
                    drawX + textWidth + (int) gap, y, color
            );
        }

        context.disableScissor();
    }

    private void roundedRect(
            DrawContext context,
            int x, int y, int w, int h,
            int radius, int color
    ) {
        if (w <= 0 || h <= 0) return;

        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        if (radius == 0) {
            context.fill(x, y, x + w, y + h, color);
            return;
        }

        int band = Math.max(1, radius / 3);
        band = Math.min(band, h / 2);

        int inset1 = calculateInset(radius, band);
        int inset2 = calculateInset(radius, band * 2);

        context.fill(x + inset1, y, x + w - inset1, y + band, color);
        context.fill(x + inset2, y + band, x + w - inset2, y + band * 2, color);

        int middleTop = y + band * 2;
        int middleBottom = y + h - band * 2;

        if (middleBottom > middleTop) {
            context.fill(x, middleTop, x + w, middleBottom, color);
        }

        context.fill(
                x + inset2, y + h - band * 2,
                x + w - inset2, y + h - band, color
        );

        context.fill(
                x + inset1, y + h - band,
                x + w - inset1, y + h, color
        );
    }

    private int calculateInset(int radius, int distance) {
        double remaining = radius - distance;

        return Math.max(0,
                radius - (int) Math.sqrt(
                        radius * radius - remaining * remaining
                ));
    }

    private void glassPanel(
            DrawContext context, int x, int y, int w, int h
    ) {
        roundedRect(context, x - 4, y - 4, w + 8, h + 8, 20, 0x249D55E8);
        roundedRect(context, x - 2, y - 2, w + 4, h + 4, 19, 0x559B5AE0);
        roundedRect(context, x, y, w, h, 17, 0xF0181423);
        roundedRect(context, x + 1, y + 1, w - 2, h - 2, 16, 0xE91C1729);
    }

    private void drawPlayIcon(
            DrawContext context, int x, int y, int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(x + i, y + i, x + i + 1, y + 17 - i, color);
        }
    }

    private void drawSlidersIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x, y + 3, x + 19, y + 5, color);
        context.fill(x, y + 9, x + 19, y + 11, color);
        context.fill(x, y + 15, x + 19, y + 17, color);

        context.fill(x + 5, y + 1, x + 9, y + 7, color);
        context.fill(x + 13, y + 7, x + 17, y + 13, color);
        context.fill(x + 7, y + 13, x + 11, y + 19, color);
    }

    private void drawSettingsIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x + 7, y, x + 12, y + 19, color);
        context.fill(x, y + 7, x + 19, y + 12, color);

        context.fill(x + 3, y + 2, x + 7, y + 6, color);
        context.fill(x + 12, y + 13, x + 16, y + 17, color);
        context.fill(x + 3, y + 13, x + 7, y + 17, color);
        context.fill(x + 12, y + 2, x + 16, y + 6, color);

        roundedRect(context, x + 6, y + 6, 7, 7, 3, 0xFF59416F);
    }

    private void drawTab(
            DrawContext context,
            int x, int y, int tabWidth,
            String label, int tab,
            boolean hovered, float delta
    ) {
        boolean active = selectedTab == tab;
        float target = hovered ? 1.0f : 0.0f;

        hoverProgress[tab] +=
                (target - hoverProgress[tab]) * Math.min(1.0f, delta * 0.7f);

        float progress = hoverProgress[tab];
        float scale = 1.0f + progress * 0.04f;

        int normalColor = active ? 0xFF9664C5 : 0xFF59416F;
        int hoverColor = active ? 0xFFAD7BE0 : 0xFF8055A8;

        int background = lerpColor(normalColor, hoverColor, progress);

        float centerX = x + tabWidth / 2.0f;
        float centerY = y + 17.0f;

        context.getMatrices().push();
        context.getMatrices().translate(centerX, centerY, 0);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-centerX, -centerY, 0);

        roundedRect(context, x, y, tabWidth, 34, 9, background);

        if (tab == 0) {
            drawPlayIcon(context, x + 8, y + 9, LIGHT);
        } else if (tab == 1) {
            drawSlidersIcon(context, x + 8, y + 7, LIGHT);
        } else {
            drawSettingsIcon(context, x + 8, y + 7, LIGHT);
        }

        drawClippedText(context, label, x + 36, y + 12, tabWidth - 42, LIGHT);

        context.getMatrices().pop();
    }

    private int lerpColor(int from, int to, float amount) {
        int a = lerpChannel((from >> 24) & 255, (to >> 24) & 255, amount);
        int r = lerpChannel((from >> 16) & 255, (to >> 16) & 255, amount);
        int g = lerpChannel((from >> 8) & 255, (to >> 8) & 255, amount);
        int b = lerpChannel(from & 255, to & 255, amount);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int lerpChannel(int from, int to, float amount) {
        return (int) (from + (to - from) * amount);
    }

    private void drawPlayerPanel(DrawContext context) {
        int size = getPlayerSize();
        int x = getPlayerX();
        int y = getPlayerY();

        glassPanel(context, x, y, size, size);

        roundedRect(context, x + 12, y + 12, size - 24, 30, 9, 0xFF241B34);
        drawClippedText(context, "VORTEX PLAYER", x + 20, y + 22, size - 40, LIGHT);

        int discSize = Math.min(65, Math.max(34, size - 105));
        int discX = x + (size - discSize) / 2;
        int discY = y + 48;

        roundedRect(context, discX, discY, discSize, discSize, discSize / 2, 0xFF39254D);
        roundedRect(context, discX + 6, discY + 6, discSize - 12, discSize - 12,
                (discSize - 12) / 2, 0xFF62417F);
        roundedRect(context, discX + discSize / 2 - 5, discY + discSize / 2 - 5,
                10, 10, 5, 0xFFEAD9FF);

        int titleY = y + size - 55;

        drawScrollingText(context, currentTrackTitle, x + 18, titleY, size - 36, LIGHT);

        if (size >= 160) {
            drawWrappedText(context, "Choose a song in Playlist",
                    x + 18, titleY + 13, size - 36, 16, MUTED);
        }

        roundedRect(context, x + 18, y + size - 39, size - 36, 3, 2, 0xFF59416F);

        int buttonY = y + size - 30;

        roundedRect(context, x + size / 2 - 48, buttonY, 28, 24, 8, 0xFF59416F);
        roundedRect(context, x + size / 2 - 12, buttonY - 3, 30, 30, 10, 0xFF9664C5);
        roundedRect(context, x + size / 2 + 26, buttonY, 28, 24, 8, 0xFF59416F);

        context.fill(x + size / 2 - 39, buttonY + 6, x + size / 2 - 37, buttonY + 18, LIGHT);
        context.fill(x + size / 2 - 35, buttonY + 7, x + size / 2 - 28, buttonY + 17, LIGHT);

        drawPlayIcon(context, x + size / 2 - 3, buttonY + 4, LIGHT);

        context.fill(x + size / 2 + 32, buttonY + 7, x + size / 2 + 39, buttonY + 17, LIGHT);
        context.fill(x + size / 2 + 40, buttonY + 6, x + size / 2 + 42, buttonY + 18, LIGHT);
    }

    private void drawPlayerHandle(
            DrawContext context, int mouseX, int mouseY
    ) {
        int x = getMainX() - 7;
        int y = height / 2 - 35;

        boolean hovered = mouseX >= x - 3 && mouseX <= x + 17
                && mouseY >= y && mouseY <= y + 70;

        int color = hovered ? 0xFFAD7BE0 : 0xFF8052A9;

        roundedRect(context, x, y, 14, 70, 7, color);
        roundedRect(context, x + 6, y + 23, 2, 24, 1, LIGHT);
    }

    private void drawScaleSettings(DrawContext context, int x, int y, int width) {
        drawClippedText(context, "Interface Scale", x, y, width, LIGHT);
        drawWrappedText(context, "Choose your interface size.",
                x, y + 20, width, 24, MUTED);

        int buttonY = y + 58;
        int gap = 7;
        int buttonWidth = Math.max(25, (width - gap * 2) / 3);

        for (int i = 1; i <= 3; i++) {
            int buttonX = x + (i - 1) * (buttonWidth + gap);
            boolean active = interfaceScale == i;

            int color = active ? 0xFF9664C5 : 0xFF59416F;

            roundedRect(context, buttonX, buttonY,
                    buttonWidth, 32, 8, color);

            String label = String.valueOf(i);
            int labelWidth = textRenderer.getWidth(label);

            context.drawTextWithShadow(
                    textRenderer,
                    label,
                    buttonX + (buttonWidth - labelWidth) / 2,
                    buttonY + 12,
                    LIGHT
            );
        }

        String description;

        if (interfaceScale == 1) {
            description = "Small";
        } else if (interfaceScale == 3) {
            description = "Large";
        } else {
            description = "Medium";
        }

        drawClippedText(context, "Selected: " + description,
                x, buttonY + 43, width, MUTED);
    }

    @Override
    public void render(
            DrawContext context, int mouseX, int mouseY, float delta
    ) {
        renderBackground(context);

        scrollTime += Math.max(0.0f, Math.min(delta, 1.0f));

        float scale = getInterfaceScale();

        int uiMouseX = (int) getUnscaledMouseX(mouseX);
        int uiMouseY = (int) getUnscaledMouseY(mouseY);

        context.getMatrices().push();
        context.getMatrices().translate(width / 2.0, height / 2.0, 0);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-width / 2.0, -height / 2.0, 0);

        float target = playerOpen ? 1.0f : 0.0f;
        playerProgress += (target - playerProgress) * 0.18f;

        if (Math.abs(target - playerProgress) < 0.001f) {
            playerProgress = target;
        }

        if (playerProgress > 0.001f) {
            context.enableScissor(0, 0, getMainX(), height);
            drawPlayerPanel(context);
            context.disableScissor();
        }

        int w = getMainWidth();
        int h = getMainHeight();
        int x = getMainX();
        int y = getMainY();

        glassPanel(context, x, y, w, h);

        roundedRect(context, x + 15, y + 14, w - 30, 45, 11, 0xFF241B34);

        drawClippedText(context, "VortexLyrics", x + 29, y + 23, w - 58, LIGHT);
        drawClippedText(context, "BETA 0.1.0", x + 29, y + 39, w - 58, MUTED);

        int sidebarX = x + 15;
        int sidebarY = y + 70;
        int sidebarW = Math.min(145, Math.max(120, w - 205));
        int sidebarH = h - 130;

        roundedRect(context, sidebarX, sidebarY, sidebarW, sidebarH, 12, 0xFF211A30);

        int tabX = sidebarX + 7;
        int tabWidth = sidebarW - 14;

        drawTab(context, tabX, sidebarY + 10, tabWidth, "Playlist", 0,
                isHovered(uiMouseX, uiMouseY, tabX, sidebarY + 10, tabWidth), delta);

        drawTab(context, tabX, sidebarY + 52, tabWidth, "Visual", 1,
                isHovered(uiMouseX, uiMouseY, tabX, sidebarY + 52, tabWidth), delta);

        drawTab(context, tabX, sidebarY + 94, tabWidth, "Other", 2,
                isHovered(uiMouseX, uiMouseY, tabX, sidebarY + 94, tabWidth), delta);

        int contentX = sidebarX + sidebarW + 13;
        int contentY = sidebarY;
        int contentW = w - sidebarW - 43;
        int contentH = sidebarH;

        roundedRect(context, contentX, contentY, contentW, contentH, 12, 0xCC251D34);

        int textX = contentX + 12;
        int textWidth = contentW - 24;

        if (selectedTab == 0) {
            drawClippedText(context, "Welcome to VortexLyrics",
                    textX, contentY + 19, textWidth, LIGHT);
            drawWrappedText(context, "Your music experience starts here.",
                    textX, contentY + 39, textWidth, contentH - 48, MUTED);
        } else if (selectedTab == 1) {
            drawClippedText(context, "Visual", textX, contentY + 19, textWidth, LIGHT);
            drawWrappedText(context, "Visual settings are coming soon.",
                    textX, contentY + 39, textWidth, contentH - 48, MUTED);
        } else {
            drawScaleSettings(context, textX, contentY + 19, textWidth);
        }

        int barY = y + h - 48;

        roundedRect(context, x + 15, barY, w - 30, 34, 10, 0xFF30243F);
        roundedRect(context, x + 22, barY + 6, 22, 22, 7, 0xFF8052A9);

        drawPlayIcon(context, x + 29, barY + 9, 0xFFFFFFFF);
        drawClippedText(context, "VORTEXLYRICS PLAYER",
                x + 55, barY + 13, w - 85, LIGHT);

        drawPlayerHandle(context, uiMouseX, uiMouseY);

        context.getMatrices().pop();

        super.render(context, mouseX, mouseY, delta);
    }

    private boolean isHovered(
            int mouseX, int mouseY, int x, int y, int tabWidth
    ) {
        return mouseX >= x && mouseX <= x + tabWidth
                && mouseY >= y && mouseY <= y + 34;
    }

    @Override
    public boolean mouseClicked(
            double mouseX, double mouseY, int button
    ) {
        if (button == 0) {
            double uiMouseX = getUnscaledMouseX(mouseX);
            double uiMouseY = getUnscaledMouseY(mouseY);

            int handleX = getMainX() - 10;
            int handleY = height / 2 - 35;

            if (uiMouseX >= handleX && uiMouseX <= handleX + 20
                    && uiMouseY >= handleY && uiMouseY <= handleY + 70) {
                playerOpen = !playerOpen;
                return true;
            }

            int sidebarX = getMainX() + 15;
            int sidebarY = getMainY() + 70;
            int sidebarW = Math.min(145, Math.max(120, getMainWidth() - 205));

            int tabX = sidebarX + 7;
            int tabWidth = sidebarW - 14;

            if (uiMouseX >= tabX && uiMouseX <= tabX + tabWidth) {
                if (uiMouseY >= sidebarY + 10 && uiMouseY <= sidebarY + 44) {
                    selectedTab = 0;
                    return true;
                }

                if (uiMouseY >= sidebarY + 52 && uiMouseY <= sidebarY + 86) {
                    selectedTab = 1;
                    return true;
                }

                if (uiMouseY >= sidebarY + 94 && uiMouseY <= sidebarY + 128) {
                    selectedTab = 2;
                    return true;
                }
            }

            if (selectedTab == 2) {
                int contentX = sidebarX + sidebarW + 13;
                int contentY = sidebarY;
                int contentW = getMainWidth() - sidebarW - 43;

                int textX = contentX + 12;
                int textWidth = contentW - 24;

                int buttonY = contentY + 19 + 58;
                int gap = 7;
                int buttonWidth = Math.max(25, (textWidth - gap * 2) / 3);

                for (int i = 1; i <= 3; i++) {
                    int buttonX = textX + (i - 1) * (buttonWidth + gap);

                    if (uiMouseX >= buttonX
                            && uiMouseX <= buttonX + buttonWidth
                            && uiMouseY >= buttonY
                            && uiMouseY <= buttonY + 32) {
                        interfaceScale = i;
                        return true;
                    }
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        super.close();
    }
}

