
package ru.lyricsmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;
import java.util.Locale;

public class LyricsScreen extends Screen {

    // =========================================================
    // COLOR PALETTE
    // =========================================================

    private static final int BG_SCREEN       = 0xFF08060D;
    private static final int BG_PANEL        = 0xFF21152F;
    private static final int BG_PANEL_DARK   = 0xFF190F25;
    private static final int BG_PANEL_LIGHT  = 0xFF2A1B3B;

    private static final int CARD            = 0xFF352347;
    private static final int CARD_LIGHT      = 0xFF402A55;
    private static final int CARD_DARK       = 0xFF2C1D3B;
    private static final int CARD_BORDER     = 0xFF513967;

    private static final int BUTTON          = 0xFF69418D;
    private static final int BUTTON_ALT      = 0xFF76509A;
    private static final int BUTTON_DARK     = 0xFF49305F;
    private static final int BUTTON_HOVER    = 0xFF925BC0;
    private static final int BUTTON_PRESSED  = 0xFF573477;
    private static final int BUTTON_DISABLED = 0xFF382A46;

    private static final int ACCENT           = 0xFFA855F7;
    private static final int ACCENT_LIGHT     = 0xFFC084FC;
    private static final int ACCENT_BRIGHT    = 0xFFD8B4FE;
    private static final int ACCENT_DARK      = 0xFF7835B5;
    private static final int ACCENT_DEEP      = 0xFF6B21A8;

    private static final int TEXT_WHITE       = 0xFFF7F0FF;
    private static final int TEXT_PRIMARY     = 0xFFE9DDF7;
    private static final int TEXT_SECONDARY   = 0xFFC4B5D5;
    private static final int TEXT_MUTED       = 0xFF857494;
    private static final int TEXT_DISABLED    = 0xFF62546F;

    private static final int SUCCESS           = 0xFF65D6A3;
    private static final int WARNING           = 0xFFF2BD68;
    private static final int ERROR             = 0xFFF07891;
    private static final int INFO              = 0xFF83B8FF;

    private static final int BORDER            = 0xFF513967;
    private static final int BORDER_LIGHT      = 0xFF76518F;
    private static final int SCROLL_TRACK      = 0xFF24182F;
    private static final int SCROLL_THUMB      = 0xFF76509A;

    // =========================================================
    // CONSTANTS
    // =========================================================

    private static final String[] TABS = {
            "Playlist", "Visual", "Text", "Other"
    };

    private static final String[] ICONS = {
            "♫", "◈", "T", "i"
    };

    private static final int ROW_HEIGHT = 38;
    private static final int ROW_GAP = 7;
    private static final int SCROLLBAR_WIDTH = 6;

    private static final MusicPlayer PLAYER = new MusicPlayer();

    // =========================================================
    // STATE
    // =========================================================

    private List<MusicLibrary.Track> tracks = List.of();

    private int selectedTab = 0;
    private int selectedTrack = -1;

    private double playlistScroll = 0;
    private double settingsScroll = 0;

    private int draggingSlider = -1;
    private boolean draggingScrollbar;
    private double scrollbarGrabOffset;

    // =========================================================
    // LAYOUT
    // =========================================================

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    private int sidebarW;

    private int playerX;
    private int playerY;
    private int playerW;
    private int playerH;

    private int contentX;
    private int contentY;
    private int contentW;
    private int contentH;

    private int viewportX;
    private int viewportY;
    private int viewportW;
    private int viewportH;

    private int scrollContentHeight;

    private boolean compact;
    private boolean tiny;

    private int padding;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));

        tracks = MusicLibrary.scan();

        if (!tracks.isEmpty()) {
            selectedTrack = 0;
        }
    }

    // =========================================================
    // RESPONSIVE LAYOUT
    // =========================================================

    private void calculateLayout() {

        int sw = Math.max(1, width);
        int sh = Math.max(1, height);

        /*
         * На обычном экране меню занимает примерно половину
         * доступной площади. На маленьком экране оно использует
         * почти всю доступную область.
         */

        double widthRatio = sw < 650 ? 0.95 : 0.72;
        double heightRatio = sh < 420 ? 0.95 : 0.76;

        panelW = Math.min(
                920,
                Math.max(1, (int) (sw * widthRatio))
        );

        panelH = Math.min(
                560,
                Math.max(1, (int) (sh * heightRatio))
        );

        panelW = Math.min(panelW, Math.max(1, sw - 12));
        panelH = Math.min(panelH, Math.max(1, sh - 12));

        panelX = (sw - panelW) / 2;
        panelY = (sh - panelH) / 2;

        tiny = panelW < 390 || panelH < 320;
        compact = panelW < 680 || panelH < 430;

        padding = tiny ? 8 : compact ? 11 : 17;

        sidebarW = compact ? 0 : 66;

        if (!compact) {
            calculateWideLayout();
        } else {
            calculateCompactLayout();
        }

        contentW = Math.max(1, contentW);
        viewportW = Math.max(1, viewportW);
        viewportH = Math.max(1, viewportH);

        scrollContentHeight = getContentHeight();
        clampScroll();
    }

    private void calculateWideLayout() {

        playerX = panelX + sidebarW + 14;
        playerY = panelY + 17;

        playerW = Math.max(
                190,
                Math.min(255, (panelW - sidebarW) / 3)
        );

        playerH = panelH - 34;

        contentX = playerX + playerW + 13;
        contentY = panelY + 17;

        contentW = panelX + panelW - padding - contentX;
        contentH = panelH - 34;

        viewportX = contentX + 2;
        viewportY = contentY + 69;

        viewportW = contentW - SCROLLBAR_WIDTH - 11;
        viewportH = contentY + contentH - viewportY - 9;
    }

    private void calculateCompactLayout() {

        int innerX = panelX + padding;
        int innerW = panelW - padding * 2;

        // Navigation is placed at the top.
        playerX = innerX;
        playerY = panelY + (tiny ? 43 : 49);
        playerW = innerW;
        playerH = tiny ? 54 : 65;

        contentX = innerX;
        contentY = playerY + playerH + 9;

        contentW = innerW;
        contentH = panelY + panelH - contentY - padding;

        viewportX = contentX + 3;
        viewportY = contentY + (tiny ? 49 : 59);

        viewportW = contentW - SCROLLBAR_WIDTH - 11;
        viewportH = contentY + contentH - viewportY - 8;
    }

    private int getContentHeight() {

        return switch (selectedTab) {
            case 0 -> tracks.isEmpty()
                    ? 180
                    : 48 + tracks.size() * (ROW_HEIGHT + ROW_GAP);

            case 1 -> 230;
            case 2 -> 260;
            case 3 -> 230;

            default -> 100;
        };
    }

    private int maxScroll() {
        return Math.max(0, scrollContentHeight - viewportH);
    }

    private double currentScroll() {
        return selectedTab == 0
                ? playlistScroll
                : settingsScroll;
    }

    private void setCurrentScroll(double value) {

        value = Math.max(0, Math.min(maxScroll(), value));

        if (selectedTab == 0) {
            playlistScroll = value;
        } else {
            settingsScroll = value;
        }
    }

    private void clampScroll() {
        setCurrentScroll(currentScroll());
    }

    private int scrollY(int y) {
        return y - (int) Math.round(currentScroll());
    }

    // =========================================================
    // DRAWING UTILITIES
    // =========================================================

    private void fill(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            int color
    ) {
        if (w > 0 && h > 0) {
            ctx.fill(x, y, x + w, y + h, color);
        }
    }

    private void rounded(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int color
    ) {
        if (w <= 0 || h <= 0) return;

        radius = Math.max(
                0,
                Math.min(radius, Math.min(w, h) / 2)
        );

        if (radius == 0) {
            fill(ctx, x, y, w, h, color);
            return;
        }

        fill(ctx, x + radius, y, w - radius * 2, h, color);
        fill(ctx, x, y + radius, w, h - radius * 2, color);

        for (int i = 0; i < radius; i++) {

            double d = radius - i - 0.5;

            int inset = (int) Math.ceil(
                    radius - Math.sqrt(
                            Math.max(0, radius * radius - d * d)
                    )
            );

            fill(
                    ctx,
                    x + inset,
                    y + i,
                    w - inset * 2,
                    1,
                    color
            );

            fill(
                    ctx,
                    x + inset,
                    y + h - 1 - i,
                    w - inset * 2,
                    1,
                    color
            );
        }
    }

    private void border(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int borderColor,
            int background
    ) {
        rounded(ctx, x, y, w, h, radius, borderColor);

        rounded(
                ctx,
                x + 1,
                y + 1,
                w - 2,
                h - 2,
                Math.max(0, radius - 1),
                background
        );
    }

    private void drawText(
            DrawContext ctx,
            String value,
            int x,
            int y,
            int color
    ) {
        ctx.drawTextWithShadow(
                textRenderer,
                value,
                x,
                y,
                color
        );
    }

    private String trim(String value, int maxWidth) {

        if (maxWidth <= 0) return "";

        if (textRenderer.getWidth(value) <= maxWidth) {
            return value;
        }

        String suffix = "...";

        while (!value.isEmpty()
                && textRenderer.getWidth(value + suffix) > maxWidth) {

            value = value.substring(0, value.length() - 1);
        }

        return value.isEmpty() ? "" : value + suffix;
    }

    private boolean inside(
            double mx,
            double my,
            int x,
            int y,
            int w,
            int h
    ) {
        return mx >= x
                && mx < x + w
                && my >= y
                && my < y + h;
    }

    private void drawCard(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h
    ) {
        rounded(ctx, x, y, w, h, 11, CARD);
        border(ctx, x, y, w, h, 11, CARD_BORDER, CARD);
    }

    // =========================================================
    // WINDOW
    // =========================================================

    private void drawWindow(DrawContext ctx) {

        // Solid layered neon outline. No alpha or shaders.
        rounded(
                ctx,
                panelX - 3,
                panelY - 3,
                panelW + 6,
                panelH + 6,
                23,
                ACCENT_DEEP
        );

        rounded(
                ctx,
                panelX - 1,
                panelY - 1,
                panelW + 2,
                panelH + 2,
                21,
                ACCENT_DARK
        );

        rounded(
                ctx,
                panelX,
                panelY,
                panelW,
                panelH,
                20,
                BG_SCREEN
        );

        if (!compact) {
            rounded(
                    ctx,
                    panelX,
                    panelY,
                    sidebarW + 9,
                    panelH,
                    19,
                    BG_PANEL_DARK
            );
        }

        rounded(
                ctx,
                playerX,
                playerY,
                playerW,
                playerH,
                15,
                compact ? CARD_DARK : BG_PANEL
        );

        rounded(
                ctx,
                contentX,
                contentY,
                contentW,
                contentH,
                15,
                BG_PANEL
        );
    }

    // =========================================================
    // NAVIGATION
    // =========================================================

    private void drawTab(
            DrawContext ctx,
            int index,
            int x,
            int y,
            int w,
            int h,
            int mouseX,
            int mouseY,
            boolean horizontal
    ) {

        boolean selected = selectedTab == index;

        boolean hovered = inside(
                mouseX,
                mouseY,
                x,
                y,
                w,
                h
        );

        int background;

        if (selected) {
            background = ACCENT_DARK;
        } else if (hovered) {
            background = BUTTON_HOVER;
        } else {
            background = BUTTON_DARK;
        }

        if (hovered) {
            rounded(
                    ctx,
                    x - 1,
                    y - 1,
                    w + 2,
                    h + 2,
                    11,
                    ACCENT
            );
        }

        rounded(ctx, x, y, w, h, 10, background);

        if (selected) {
            rounded(
                    ctx,
                    x + 5,
                    y + h - 3,
                    w - 10,
                    2,
                    1,
                    ACCENT_BRIGHT
            );
        }

        String label = horizontal
                ? TABS[index]
                : ICONS[index];

        int tx = x + (w - textRenderer.getWidth(label)) / 2;
        int ty = y + (h - 9) / 2;

        drawText(
                ctx,
                label,
                tx,
                ty,
                selected || hovered ? TEXT_WHITE : TEXT_SECONDARY
        );
    }

    private void drawSidebar(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {

        if (compact) {

            int gap = 5;
            int x = panelX + padding;
            int y = panelY + 9;

            int available = panelW - padding * 2;
            int tabW = Math.max(
                    1,
                    (available - gap * 3) / 4
            );

            int tabH = tiny ? 27 : 32;

            for (int i = 0; i < TABS.length; i++) {
                drawTab(
                        ctx,
                        i,
                        x + i * (tabW + gap),
                        y,
                        tabW,
                        tabH,
                        mouseX,
                        mouseY,
                        true
                );
            }

            return;
        }

        drawText(
                ctx,
                "V",
                panelX + 24,
                panelY + 21,
                ACCENT_BRIGHT
        );

        drawText(
                ctx,
                "O",
                panelX + 24,
                panelY + 35,
                ACCENT_LIGHT
        );

        fill(
                ctx,
                panelX + 15,
                panelY + 59,
                sidebarW - 24,
                1,
                BORDER
        );

        int startY = panelY + 76;

        for (int i = 0; i < TABS.length; i++) {

            drawTab(
                    ctx,
                    i,
                    panelX + 10,
                    startY + i * 49,
                    sidebarW - 20,
                    40,
                    mouseX,
                    mouseY,
                    false
            );
        }

        drawText(
                ctx,
                "1.0",
                panelX + 21,
                panelY + panelH - 28,
                TEXT_MUTED
        );
    }

    // =========================================================
    // PLAYER
    // =========================================================

    private String getSelectedTitle() {

        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return "No track selected";
        }

        return tracks.get(selectedTrack).title();
    }

    private String formatTime(long milliseconds) {

        long seconds = Math.max(0, milliseconds / 1000);

        return String.format(
                Locale.ROOT,
                "%02d:%02d",
                seconds / 60,
                seconds % 60
        );
    }

    private void drawAlbumArt(
            DrawContext ctx,
            int x,
            int y,
            int size
    ) {

        rounded(ctx, x, y, size, size, 15, ACCENT_DARK);

        rounded(
                ctx,
                x + 5,
                y + 5,
                size - 10,
                size - 10,
                12,
                BG_PANEL_DARK
        );

        rounded(
                ctx,
                x + size / 5,
                y + size / 5,
                size * 3 / 5,
                size * 3 / 5,
                size / 5,
                CARD_DARK
        );

        String symbol = "♫";

        drawText(
                ctx,
                symbol,
                x + (size - textRenderer.getWidth(symbol)) / 2,
                y + (size - 9) / 2,
                ACCENT_BRIGHT
        );

        rounded(
                ctx,
                x + size / 5,
                y + size - 13,
                size * 3 / 5,
                3,
                2,
                ACCENT
        );
    }

    private void drawVisualizer(
            DrawContext ctx,
            int x,
            int y,
            int w,
            int h,
            boolean playing
    ) {

        int count = Math.max(5, Math.min(28, w / 7));
        int gap = 3;
        int barW = Math.max(
                2,
                (w - gap * (count - 1)) / count
        );

        for (int i = 0; i < count; i++) {

            int pattern = (i * 17 + i * i * 3) % 23;
            int barH = 5 + pattern * h / 35;

            if (!playing) {
                barH = 5 + pattern / 5;
            }

            int bx = x + i * (barW + gap);
            int by = y + h - barH;

            rounded(
                    ctx,
                    bx,
                    by,
                    barW,
                    barH,
                    2,
                    playing ? ACCENT : BORDER_LIGHT
            );
        }
    }

    private void drawControl(
            DrawContext ctx,
            String symbol,
            int x,
            int y,
            int size,
            int style,
            int mouseX,
            int mouseY
    ) {

        boolean hovered = inside(
                mouseX,
                mouseY,
                x,
                y,
                size,
                size
        );

        int background;

        if (style == 2) {
            background = hovered
                    ? ACCENT_LIGHT
                    : ACCENT;
        } else if (style == 1) {
            background = hovered
                    ? BUTTON_HOVER
                    : BUTTON_ALT;
        } else {
            background = hovered
                    ? CARD_LIGHT
                    : BUTTON_DARK;
        }

        if (hovered) {
            rounded(
                    ctx,
                    x - 2,
                    y - 2,
                    size + 4,
                    size + 4,
                    size / 2 + 2,
                    ACCENT
            );
        }

        rounded(
                ctx,
                x,
                y,
                size,
                size,
                size / 2,
                background
        );

        int color = style == 2
                ? BG_SCREEN
                : TEXT_WHITE;

        drawText(
                ctx,
                symbol,
                x + (size - textRenderer.getWidth(symbol)) / 2,
                y + (size - 9) / 2,
                color
        );
    }

    private void drawPlayer(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {

        boolean playing = PLAYER.isPlaying();

        int controlSize = compact ? (tiny ? 24 : 28) : 38;
        int gap = compact ? 4 : 10;

        int controlsW = controlSize * 3 + gap * 2;

        int controlsX = compact
                ? playerX + playerW - controlsW - 7
                : playerX + (playerW - controlsW) / 2;

        int controlsY = compact
                ? playerY + (playerH - controlSize) / 2
                : playerY + playerH - 69;

        if (compact) {

            int textX = playerX + 10;
            int textW = Math.max(
                    30,
                    controlsX - textX - 7
            );

            drawText(
                    ctx,
                    "NOW PLAYING",
                    textX,
                    playerY + 7,
                    ACCENT_LIGHT
            );

            drawText(
                    ctx,
                    trim(getSelectedTitle(), textW),
                    textX,
                    playerY + 23,
                    TEXT_WHITE
            );

            drawText(
                    ctx,
                    playing ? "PLAYING" : "STOPPED",
                    textX,
                    playerY + (tiny ? 39 : 43),
                    playing ? SUCCESS : TEXT_MUTED
            );

        } else {

            int padding = 15;

            int artSize = Math.min(
                    145,
                    Math.min(
                            playerW - padding * 2,
                            playerH / 3
                    )
            );

            artSize = Math.max(48, artSize);

            int artX = playerX + (playerW - artSize) / 2;
            int artY = playerY + 22;

            drawAlbumArt(
                    ctx,
                    artX,
                    artY,
                    artSize
            );

            int infoY = artY + artSize + 17;

            drawText(
                    ctx,
                    "NOW SELECTED",
                    playerX + padding,
                    infoY,
                    ACCENT_LIGHT
            );

            drawText(
                    ctx,
                    trim(
                            getSelectedTitle(),
                            playerW - padding * 2
                    ),
                    playerX + padding,
                    infoY + 19,
                    TEXT_WHITE
            );

            drawText(
                    ctx,
                    "LOCAL AUDIO",
                    playerX + padding,
                    infoY + 38,
                    TEXT_MUTED
            );

            int visualY = Math.min(
                    infoY + 76,
                    controlsY - 63
            );

            drawVisualizer(
                    ctx,
                    playerX + padding,
                    visualY,
                    playerW - padding * 2,
                    29,
                    playing
            );

            drawText(
                    ctx,
                    playing ? "PLAYING" : "STOPPED",
                    playerX + padding,
                    visualY + 38,
                    playing ? SUCCESS : TEXT_MUTED
            );

            drawText(
                    ctx,
                    formatTime(PLAYER.getPlaybackPositionMs()),
                    playerX + padding,
                    visualY + 54,
                    TEXT_SECONDARY
            );

            drawText(
                    ctx,
                    "VORTEX LYRICS",
                    playerX + padding,
                    playerY + playerH - 19,
                    TEXT_MUTED
            );
        }

        drawControl(
                ctx,
                "‹",
                controlsX,
                controlsY,
                controlSize,
                0,
                mouseX,
                mouseY
        );

        drawControl(
                ctx,
                playing ? "■" : "▶",
                controlsX + controlSize + gap,
                controlsY,
                controlSize,
                2,
                mouseX,
                mouseY
        );

        drawControl(
                ctx,
                "›",
                controlsX + (controlSize + gap) * 2,
                controlsY,
                controlSize,
                1,
                mouseX,
                mouseY
        );
    }

    // =========================================================
    // HEADER
    // =========================================================

    private String getTabTitle() {

        return switch (selectedTab) {
            case 0 -> "Your Playlist";
            case 1 -> "Visual Appearance";
            case 2 -> "Text Settings";
            case 3 -> "About VortexLyrics";
            default -> "VortexLyrics";
        };
    }

    private String getTabSubtitle() {

        return switch (selectedTab) {
            case 0 -> "Your personal music collection";
            case 1 -> "Customize the interface appearance";
            case 2 -> "Customize lyrics in your world";
            case 3 -> "Information about the modification";
            default -> "";
        };
    }

    private void drawHeader(DrawContext ctx) {

        int titleY = compact
                ? contentY + 10
                : contentY + 13;

        drawText(
                ctx,
                trim(getTabTitle(), contentW - 20),
                contentX + 12,
                titleY,
                TEXT_WHITE
        );

        drawText(
                ctx,
                trim(getTabSubtitle(), contentW - 20),
                contentX + 12,
                titleY + 19,
                TEXT_MUTED
        );

        fill(
                ctx,
                contentX + 10,
                viewportY - 8,
                contentW - 20,
                1,
                BORDER
        );
    }

    // =========================================================
    // BUTTONS
    // =========================================================

    private void drawButton(
            DrawContext ctx,
            String label,
            int x,
            int y,
            int w,
            int h,
            int mouseX,
            int mouseY,
            int style
    ) {

        boolean hovered = inside(
                mouseX,
                mouseY,
                x,
                y,
                w,
                h
        );

        int background;

        if (style == 2) {
            background = hovered
                    ? ACCENT_LIGHT
                    : ACCENT;
        } else if (style == 1) {
            background = hovered
                    ? BUTTON_HOVER
                    : BUTTON;
        } else {
            background = hovered
                    ? CARD_LIGHT
                    : BUTTON_DARK;
        }

        if (hovered) {
            rounded(
                    ctx,
                    x - 1,
                    y - 1,
                    w + 2,
                    h + 2,
                    9,
                    ACCENT
            );
        }

        rounded(
                ctx,
                x,
                y,
                w,
                h,
                8,
                background
        );

        int color = style == 2
                ? BG_SCREEN
                : TEXT_WHITE;

        drawText(
                ctx,
                label,
                x + (w - textRenderer.getWidth(label)) / 2,
                y + (h - 9) / 2,
                color
        );
    }

    // =========================================================
    // SCROLLBAR
    // =========================================================

    private int getThumbHeight() {

        return Math.min(
                viewportH,
                Math.max(
                        23,
                        viewportH * viewportH
                                / Math.max(1, scrollContentHeight)
                )
        );
    }

    private int getThumbY() {

        int thumbH = getThumbHeight();
        int travel = viewportH - thumbH;

        if (travel <= 0 || maxScroll() <= 0) {
            return viewportY;
        }

        return viewportY + (int) Math.round(
                travel * currentScroll() / maxScroll()
        );
    }

    private void drawScrollbar(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {

        if (maxScroll() <= 0) return;

        int x = viewportX + viewportW + 3;
        int thumbH = getThumbHeight();
        int thumbY = getThumbY();

        rounded(
                ctx,
                x,
                viewportY,
                5,
                viewportH,
                3,
                SCROLL_TRACK
        );

        boolean hovered = inside(
                mouseX,
                mouseY,
                x - 5,
                thumbY - 3,
                15,
                thumbH + 6
        ) || draggingScrollbar;

        rounded(
                ctx,
                x - (hovered ? 1 : 0),
                thumbY,
                hovered ? 7 : 5,
                thumbH,
                3,
                hovered ? ACCENT_LIGHT : SCROLL_THUMB
        );
    }

    // =========================================================
    // PLAYLIST
    // =========================================================

    private void drawLrcBadge(
            DrawContext ctx,
            int x,
            int y,
            boolean hasLyrics
    ) {

        rounded(
                ctx,
                x,
                y,
                35,
                20,
                6,
                hasLyrics ? 0xFF214735 : 0xFF38333F
        );

        drawText(
                ctx,
                "LRC",
                x + 6,
                y + 6,
                hasLyrics ? SUCCESS : TEXT_MUTED
        );
    }

    private void drawPlaylist(
            DrawContext ctx,
            int mouseX,
            int mouseY
    ) {

        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int top = viewportY;

        drawText(
                ctx,
                tracks.size() + " TRACKS",
                viewportX + 2,
                scrollY(top + 8),
                TEXT_MUTED
        );

        drawButton(
                ctx,
                "REFRESH",
                viewportX + viewportW - 78,
                scrollY(top + 3),
                76,
                25,
                mouseX,
                mouseY,
                1
        );

        int rowsY = top + 43;

        if (tracks.isEmpty()) {

            int emptyY = scrollY(rowsY);

            drawCard(
                    ctx,
                    viewportX,
                    emptyY,
                    viewportW,
                    105
            );

            drawText(
                    ctx,
                    "Your playlist is empty",
                    viewportX + 13,
                    emptyY + 18,
                    TEXT_PRIMARY
            );

            drawText(
                    ctx,
                    "Add MP3 or OGG files to:",
                    viewportX + 13,
                    emptyY + 42,
                    TEXT_MUTED
            );

            drawText(
                    ctx,
                    "vortexlyrics/music",
                    viewportX + 13,
                    emptyY + 65,
                    ACCENT_LIGHT
            );

            ctx.disableScissor();
            return;
        }

        int step = ROW_HEIGHT + ROW_GAP;

        int first = Math.max(
                0,
                (int) (playlistScroll / step)
        );

        int visible = viewportH / step + 3;

        for (int i = first;
             i < Math.min(tracks.size(), first + visible);
             i++) {

            int rowY = rowsY + i * step
                    - (int) playlistScroll;

            if (rowY + ROW_HEIGHT < viewportY
                    || rowY > viewportY + viewportH) {
                continue;
            }

            boolean selected = selectedTrack == i;

            boolean hovered = inside(
                    mouseX,
                    mouseY,
                    viewportX,
                    rowY,
                    viewportW,
                    ROW_HEIGHT
            );

            int background = selected
                    ? ACCENT_DEEP
                    : hovered
                    ? BUTTON_HOVER
                    : CARD;

            rounded(
                    ctx,
                    viewportX,
                    rowY,
                    viewportW,
                    ROW_HEIGHT,
                    9,
                    background
            );

            if (selected) {
                rounded(
                        ctx,
                        viewportX,
                        rowY + 7,
                        3,
                        ROW_HEIGHT - 14,
                        2,
                        ACCENT_BRIGHT
                );
            }

            int badgeX = viewportX + viewportW - 44;

            drawText(
                    ctx,
                    trim(
                            tracks.get(i).title(),
                            badgeX - viewportX - 23
                    ),
                    viewportX + 13,
                    rowY + 14,
                    selected || hovered
                            ? TEXT_WHITE
                            : TEXT_PRIMARY
            );

            drawLrcBadge(
                    ctx,
                    badgeX,
                    rowY + 9,
                    tracks.get(i).hasLyrics()
            );
        }

        ctx.disableScissor();
    }

    // =========================================================
    // SLIDERS
    // =========================================================

    private void drawSlider(
            DrawContext ctx,
            int x,
            int y,
            int w,
            String title,
            String valueText,
            double value,
            double min,
            double max,
            int accent
    ) {

        drawCard(ctx, x, y, w, 70);

        drawText(
                ctx,
                title,
                x + 13,
                y + 12,
                TEXT_PRIMARY
        );

        drawText(
                ctx,
                valueText,
                x + w - textRenderer.getWidth(valueText) - 13,
                y + 12,
                accent
        );

        int bx = x + 13;
        int by = y + 48;
        int bw = Math.max(1, w - 26);

        rounded(
                ctx,
                bx,
                by,
                bw,
                5,
                3,
                SCROLL_TRACK
        );

        double progress = Math.max(
                0,
                Math.min(1, (value - min) / (max - min))
        );

        int filled = (int) (bw * progress);

        if (filled > 0) {
            rounded(
                    ctx,
                    bx,
                    by,
                    filled,
                    5,
                    3,
                    accent
            );
        }

        int knobX = Math.max(
                bx,
                Math.min(bx + bw - 8, bx + filled - 4)
        );

        rounded(
                ctx,
                knobX - 1,
                by - 4,
                11,
                13,
                5,
                ACCENT_DARK
        );

        rounded(
                ctx,
                knobX,
                by - 4,
                9,
                13,
                5,
                TEXT_WHITE
        );
    }

    private void drawTextSettings(DrawContext ctx) {

        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int y = viewportY;

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 5),
                viewportW,
                "Spawn distance",
                String.format(
                        Locale.ROOT,
                        "%.1f blocks",
                        LyricsConfig.distance
                ),
                LyricsConfig.distance,
                3,
                30,
                ACCENT
        );

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 85),
                viewportW,
                "Text size",
                String.format(
                        Locale.ROOT,
                        "%.3f",
                        LyricsConfig.textScale
                ),
                LyricsConfig.textScale,
                0.02,
                0.09,
                0xFFE49BE0
        );

        drawSlider(
                ctx,
                viewportX,
                scrollY(y + 165),
                viewportW,
                "Text width",
                LyricsConfig.textWidth + " px",
                LyricsConfig.textWidth,
                60,
                300,
                0xFF9AA8F5
        );

        ctx.disableScissor();
    }

    // =========================================================
    // VISUAL SETTINGS
    // =========================================================

    private void drawVisual(DrawContext ctx) {

        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int y = scrollY(viewportY + 6);

        drawCard(
                ctx,
                viewportX,
                y,
                viewportW,
                195
        );

        drawText(
                ctx,
                "VORTEX COLOR SYSTEM",
                viewportX + 13,
                y + 13,
                TEXT_PRIMARY
        );

        int[] colors = {
                BG_SCREEN,
                BG_PANEL,
                BG_PANEL_LIGHT,
                CARD,
                CARD_LIGHT,
                BUTTON_DARK,
                BUTTON,
                BUTTON_ALT,
                BUTTON_HOVER,
                ACCENT_DARK,
                ACCENT,
                ACCENT_LIGHT,
                ACCENT_BRIGHT,
                SUCCESS,
                WARNING,
                ERROR
        };

        String[] names = {
                "Screen", "Panel", "Inner", "Card",
                "Card+", "Dark", "Button", "Button+",
                "Hover", "Active", "Accent", "Light",
                "Neon", "Success", "Warning", "Error"
        };

        int gap = 6;
        int columns = viewportW < 230 ? 2 : 4;

        int sw = Math.max(
                1,
                (viewportW - 26 - gap * (columns - 1)) / columns
        );

        int sh = 24;
        int startX = viewportX + 13;
        int startY = y + 39;

        for (int i = 0; i < colors.length; i++) {

            int col = i % columns;
            int row = i / columns;

            int xx = startX + col * (sw + gap);
            int yy = startY + row * 36;

            border(
                    ctx,
                    xx,
                    yy,
                    sw,
                    sh,
                    6,
                    BORDER_LIGHT,
                    colors[i]
            );

            drawText(
                    ctx,
                    trim(names[i], sw),
                    xx,
                    yy + 25,
                    TEXT_MUTED
            );
        }

        int noteY = y + 179;

        if (noteY < viewportY + viewportH) {
            drawText(
                    ctx,
                    "Opaque surfaces • No blur shaders",
                    viewportX + 13,
                    noteY,
                    ACCENT_LIGHT
            );
        }

        ctx.disableScissor();
    }

    // =========================================================
    // OTHER
    // =========================================================

    private void drawOther(DrawContext ctx) {

        ctx.enableScissor(
                viewportX,
                viewportY,
                viewportX + viewportW,
                viewportY + viewportH
        );

        int y = viewportY;

        int firstY = scrollY(y + 7);

        drawCard(
                ctx,
                viewportX,
                firstY,
                viewportW,
                120
        );

        drawText(
                ctx,
                "VortexLyrics",
                viewportX + 14,
                firstY + 15,
                TEXT_WHITE
        );

        drawText(
                ctx,
                trim(
                        "Minecraft music and world lyrics player.",
                        viewportW - 28
                ),
                viewportX + 14,
                firstY + 41,
                TEXT_PRIMARY
        );

        drawText(
                ctx,
                "Supported audio: MP3 / OGG",
                viewportX + 14,
                firstY + 68,
                TEXT_MUTED
        );

        drawText(
                ctx,
                "Lyrics format: LRC",
                viewportX + 14,
                firstY + 90,
                TEXT_MUTED
        );

        int secondY = scrollY(y + 137);

        drawCard(
                ctx,
                viewportX,
                secondY,
                viewportW,
                70
        );

        drawText(
                ctx,
                "Music library",
                viewportX + 14,
                secondY + 14,
                TEXT_PRIMARY
        );

        drawText(
                ctx,
                "Songs found: " + tracks.size(),
                viewportX + 14,
                secondY + 39,
                TEXT_MUTED
        );

        ctx.disableScissor();
    }

    // =========================================================
    // LIBRARY AND PLAYBACK
    // =========================================================

    private void refreshLibrary() {

        tracks = MusicLibrary.scan();

        if (tracks.isEmpty()) {
            selectedTrack = -1;
        } else if (selectedTrack < 0
                || selectedTrack >= tracks.size()) {
            selectedTrack = 0;
        }

        calculateLayout();
    }

    private void playSelectedTrack() {

        if (selectedTrack < 0
                || selectedTrack >= tracks.size()) {
            return;
        }

        File file = tracks.get(selectedTrack)
                .audioFile()
                .toFile();

        if (file.equals(PLAYER.getCurrentFile())
                && PLAYER.isPlaying()) {
            PLAYER.stop();
        } else {
            PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {

        if (tracks.isEmpty()) return;

        selectedTrack = selectedTrack < 0
                ? 0
                : Math.floorMod(
                        selectedTrack + direction,
                        tracks.size()
                );

        PLAYER.play(
                tracks.get(selectedTrack)
                        .audioFile()
                        .toFile()
        );
    }

    // =========================================================
    // SLIDER INPUT
    // =========================================================

    private void updateSlider(double mouseX, int id) {

        int x = viewportX + 13;
        int w = Math.max(1, viewportW - 26);

        double p = Math.max(
                0,
                Math.min(1, (mouseX - x) / (double) w)
        );

        switch (id) {

            case 0 ->
                    LyricsConfig.distance = 3 + p * 27;

            case 1 ->
                    LyricsConfig.textScale =
                            (float) (0.02 + p * 0.07);

            case 2 ->
                    LyricsConfig.textWidth =
                            (int) Math.round(60 + p * 240);
        }
    }

    // =========================================================
    // SCROLLBAR INPUT
    // =========================================================

    private boolean beginScrollbarDrag(
            double mouseX,
            double mouseY
    ) {

        if (maxScroll() <= 0) return false;

        int x = viewportX + viewportW + 3;
        int thumbH = getThumbHeight();
        int thumbY = getThumbY();

        if (inside(
                mouseX,
                mouseY,
                x - 5,
                thumbY - 3,
                15,
                thumbH + 6
        )) {

            draggingScrollbar = true;
            scrollbarGrabOffset = mouseY - thumbY;

            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                x - 5,
                viewportY,
                15,
                viewportH
        )) {

            int travel = viewportH - thumbH;

            double ratio = (
                    mouseY - viewportY - thumbH / 2.0
            ) / Math.max(1, travel);

            setCurrentScroll(ratio * maxScroll());

            draggingScrollbar = true;
            scrollbarGrabOffset = thumbH / 2.0;

            return true;
        }

        return false;
    }

    private void updateScrollbarDrag(double mouseY) {

        int thumbH = getThumbHeight();
        int travel = viewportH - thumbH;

        if (travel <= 0) {
            setCurrentScroll(0);
            return;
        }

        double top = mouseY - scrollbarGrabOffset;

        setCurrentScroll(
                (top - viewportY) / travel * maxScroll()
        );
    }

    // =========================================================
    // RENDER
    // =========================================================

    @Override
    public void render(
            DrawContext ctx,
            int mouseX,
            int mouseY,
            float delta
    ) {

        renderBackground(ctx);

        calculateLayout();

        drawWindow(ctx);
        drawSidebar(ctx, mouseX, mouseY);
        drawPlayer(ctx, mouseX, mouseY);
        drawHeader(ctx);

        switch (selectedTab) {

            case 0 ->
                    drawPlaylist(ctx, mouseX, mouseY);

            case 1 ->
                    drawVisual(ctx);

            case 2 ->
                    drawTextSettings(ctx);

            case 3 ->
                    drawOther(ctx);
        }

        drawScrollbar(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);
    }

    // =========================================================
    // MOUSE CLICK
    // =========================================================

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {

        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        calculateLayout();

        // Navigation

        if (compact) {

            int gap = 5;
            int available = panelW - padding * 2;

            int tabW = Math.max(
                    1,
                    (available - gap * 3) / 4
            );

            int tabH = tiny ? 27 : 32;

            for (int i = 0; i < TABS.length; i++) {

                int tx = panelX + padding
                        + i * (tabW + gap);

                if (inside(
                        mouseX,
                        mouseY,
                        tx,
                        panelY + 9,
                        tabW,
                        tabH
                )) {

                    selectedTab = i;

                    draggingSlider = -1;
                    draggingScrollbar = false;

                    calculateLayout();

                    return true;
                }
            }

        } else {

            int startY = panelY + 76;

            for (int i = 0; i < TABS.length; i++) {

                if (inside(
                        mouseX,
                        mouseY,
                        panelX + 10,
                        startY + i * 49,
                        sidebarW - 20,
                        40
                )) {

                    selectedTab = i;

                    draggingSlider = -1;
                    draggingScrollbar = false;

                    calculateLayout();

                    return true;
                }
            }
        }

        // Player controls

        int controlSize = compact
                ? (tiny ? 24 : 28)
                : 38;

        int gap = compact ? 4 : 10;

        int totalW = controlSize * 3 + gap * 2;

        int controlsX = compact
                ? playerX + playerW - totalW - 7
                : playerX + (playerW - totalW) / 2;

        int controlsY = compact
                ? playerY + (playerH - controlSize) / 2
                : playerY + playerH - 69;

        if (inside(
                mouseX,
                mouseY,
                controlsX,
                controlsY,
                controlSize,
                controlSize
        )) {

            changeTrack(-1);
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + controlSize + gap,
                controlsY,
                controlSize,
                controlSize
        )) {

            playSelectedTrack();
            return true;
        }

        if (inside(
                mouseX,
                mouseY,
                controlsX + (controlSize + gap) * 2,
                controlsY,
                controlSize,
                controlSize
        )) {

            changeTrack(1);
            return true;
        }

        // Scrollbar

        if (beginScrollbarDrag(mouseX, mouseY)) {
            return true;
        }

        // Playlist

        if (selectedTab == 0) {

            int refreshX = viewportX + viewportW - 78;
            int refreshY = viewportY + 3
                    - (int) playlistScroll;

            if (inside(
                    mouseX,
                    mouseY,
                    refreshX,
                    refreshY,
                    76,
                    25
            )) {

                refreshLibrary();
                return true;
            }

            if (inside(
                    mouseX,
                    mouseY,
                    viewportX,
                    viewportY,
                    viewportW,
                    viewportH
            )) {

                if (!tracks.isEmpty()) {

                    int rowsY = viewportY + 43;

                    int contentY = (int) (
                            mouseY + playlistScroll
                    );

                    int index = (
                            contentY - rowsY
                    ) / (ROW_HEIGHT + ROW_GAP);

                    int rowY = rowsY
                            + index * (ROW_HEIGHT + ROW_GAP)
                            - (int) playlistScroll;

                    if (index >= 0
                            && index < tracks.size()
                            && inside(
                                    mouseX,
                                    mouseY,
                                    viewportX,
                                    rowY,
                                    viewportW,
                                    ROW_HEIGHT
                            )) {

                        selectedTrack = index;
                    }
                }

                return true;
            }
        }

        // Text settings sliders

        if (selectedTab == 2) {

            int[] offsets = {
                    5, 85, 165
            };

            for (int i = 0; i < offsets.length; i++) {

                int sliderY = viewportY
                        + offsets[i]
                        - (int) currentScroll();

                if (inside(
                        mouseX,
                        mouseY,
                        viewportX,
                        sliderY + 38,
                        viewportW,
                        19
                )) {

                    draggingSlider = i;

                    updateSlider(
                            mouseX,
                            draggingSlider
                    );

                    return true;
                }
            }
        }

        return super.mouseClicked(
                mouseX,
                mouseY,
                button
        );
    }

    // =========================================================
    // MOUSE DRAG
    // =========================================================

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double deltaX,
            double deltaY
    ) {

        if (button == 0 && draggingSlider >= 0) {

            updateSlider(
                    mouseX,
                    draggingSlider
            );

            return true;
        }

        if (button == 0 && draggingScrollbar) {

            updateScrollbarDrag(mouseY);

            return true;
        }

        return super.mouseDragged(
                mouseX,
                mouseY,
                button,
                deltaX,
                deltaY
        );
    }

    // =========================================================
    // MOUSE RELEASE
    // =========================================================

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {

        if (button == 0
                && (draggingSlider >= 0 || draggingScrollbar)) {

            boolean saveConfig = draggingSlider >= 0;

            draggingSlider = -1;
            draggingScrollbar = false;

            if (saveConfig) {
                LyricsConfig.save();
            }

            return true;
        }

        return super.mouseReleased(
                mouseX,
                mouseY,
                button
        );
    }

    // =========================================================
    // MOUSE SCROLL
    // =========================================================

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {

        calculateLayout();

        if (inside(
                mouseX,
                mouseY,
                viewportX,
                viewportY,
                viewportW + SCROLLBAR_WIDTH + 8,
                viewportH
        )) {

            setCurrentScroll(
                    currentScroll() - amount * 24
            );

            return true;
        }

        return super.mouseScrolled(
                mouseX,
                mouseY,
                amount
        );
    }

    // =========================================================
    // RESIZE
    // =========================================================

    @Override
    public void resize(
            MinecraftClient client,
            int width,
            int height
    ) {

        super.resize(client, width, height);

        calculateLayout();
    }

    // =========================================================
    // GAME
    // =========================================================

    @Override
    public boolean shouldPause() {
        return false;
    }
}
