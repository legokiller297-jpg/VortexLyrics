
package ru.lyricsmod;

import net.minecraft.client.sound.AudioStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.Locale;

public final class FileAudioStream implements AudioStream {

    private final AudioInputStream stream;
    private final AudioFormat format;

    private boolean closed;
    private boolean firstBufferLogged;

    public FileAudioStream(Path file) throws Exception {
        AudioInputStream original = null;

        log(file, "Открытие файла: " + file);

        try {
            String name = file.getFileName()
                    .toString()
                    .toLowerCase(Locale.ROOT);

            javax.sound.sampled.spi.FormatConversionProvider converter;

            if (name.endsWith(".mp3")) {
                original = new javazoom.spi.mpeg.sampled.file
                        .MpegAudioFileReader()
                        .getAudioInputStream(file.toFile());

                converter = new javazoom.spi.mpeg.sampled.convert
                        .MpegFormatConversionProvider();

            } else if (name.endsWith(".ogg")) {
                original = new javazoom.spi.vorbis.sampled.file
                        .VorbisAudioFileReader()
                        .getAudioInputStream(file.toFile());

                converter = new javazoom.spi.vorbis.sampled.convert
                        .VorbisFormatConversionProvider();

            } else {
                throw new UnsupportedAudioFileException(
                        "Поддерживаются только MP3 и OGG"
                );
            }

            AudioFormat sourceFormat = original.getFormat();

            log(file, "Исходный формат: " + sourceFormat);

            int channels = sourceFormat.getChannels();
            float sampleRate = sourceFormat.getSampleRate();

            if (channels <= 0 || sampleRate <= 0) {
                throw new UnsupportedAudioFileException(
                        "Не удалось определить параметры аудио"
                );
            }

            AudioFormat pcmFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    sampleRate,
                    16,
                    channels,
                    channels * 2,
                    sampleRate,
                    false
            );

            AudioInputStream converted =
                    converter.getAudioInputStream(pcmFormat, original);

            stream = converted;
            format = pcmFormat;

            log(file, "Декодирование успешно. PCM: " + pcmFormat);

        } catch (Throwable error) {
            if (original != null) {
                try {
                    original.close();
                } catch (Exception ignored) {
                }
            }

            logError(file, "Ошибка создания аудиопотока", error);

            if (error instanceof Exception exception) {
                throw exception;
            }

            if (error instanceof Error fatalError) {
                throw fatalError;
            }

            throw new RuntimeException(error);
        }
    }

    @Override
    public synchronized ByteBuffer getBuffer(int size)
            throws IOException {

        if (closed) {
            throw new IOException("Audio stream is closed");
        }

        try {
            byte[] bytes = new byte[size];
            int total = 0;

            while (total < size) {
                int read = stream.read(
                        bytes,
                        total,
                        size - total
                );

                if (read < 0) {
                    break;
                }

                if (read > 0) {
                    total += read;
                }
            }

            if (!firstBufferLogged) {
                firstBufferLogged = true;
                logFromStream("Первый аудиобуфер: " + total + " байт");
            }

            if (total == 0) {
                logFromStream("Аудиопоток достиг конца файла");
            }

            ByteBuffer buffer = ByteBuffer.allocateDirect(total);
            buffer.put(bytes, 0, total);
            buffer.flip();

            return buffer;

        } catch (IOException error) {
            logFromStreamError("Ошибка чтения аудио", error);
            throw error;
        }
    }

    @Override
    public AudioFormat getFormat() {
        return format;
    }

    @Override
    public synchronized void close() throws IOException {
        if (!closed) {
            closed = true;
            logFromStream("Аудиопоток закрывается");
            stream.close();
        }
    }

    private void logFromStream(String message) {
        System.out.println("[VortexLyrics] " + message);
    }

    private void logFromStreamError(String message, Throwable error) {
        System.err.println("[VortexLyrics] " + message);
        error.printStackTrace();
    }

    private static void log(Path audioFile, String message) {
        writeLog(audioFile, message, null);
    }

    private static void logError(
            Path audioFile,
            String message,
            Throwable error
    ) {
        writeLog(audioFile, message, error);
    }

    private static void writeLog(
            Path audioFile,
            String message,
            Throwable error
    ) {
        try {
            Path musicFolder = audioFile.toAbsolutePath().getParent();
            Path modFolder = musicFolder.getParent();
            Path logFile = modFolder.resolve("vortexlyrics-debug.txt");

            Files.createDirectories(modFolder);

            StringBuilder text = new StringBuilder();

            text.append("[")
                    .append(LocalDateTime.now())
                    .append("] ")
                    .append(message)
                    .append(System.lineSeparator());

            if (error != null) {
                StringWriter writer = new StringWriter();
                error.printStackTrace(new PrintWriter(writer));
                text.append(writer);
            }

            Files.writeString(
                    logFile,
                    text.toString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );

        } catch (Throwable loggingError) {
            System.err.println(
                    "[VortexLyrics] Не удалось записать debug-файл"
            );
            loggingError.printStackTrace();
        }
    }
}

