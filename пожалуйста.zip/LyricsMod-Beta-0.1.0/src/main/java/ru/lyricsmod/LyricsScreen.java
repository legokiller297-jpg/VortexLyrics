
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.io.File;
import java.util.List;

public class LyricsScreen extends Screen {

    // Main palette
    private static final int WHITE = 0xFFF5EDFF;
    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFBBA9D0;
    private static final int DIM = 0xFF806D98;

    private static final int BACKGROUND = 0xF014101F;
    private static final int PANEL = 0xF51B1528;
    private static final int PANEL_LIGHT = 0xFF281D38;
    private static final int PURPLE = 0xFF8D5CC2;
    private static final int PURPLE_LIGHT = 0xFFB77AEF;
    private static final int PURPLE_DARK = 0xFF49305F;
    private static final int ROW = 0xFF251D32;
    private static final int ROW_SELECTED = 0xFF49305F;

    private static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private int selectedTab = 0;

    private final float[] hoverProgress = new float[3];

    private float refreshHover;
    private float previousHover;
    private float playHover;
    private float nextHover;
    private float handleHover;

    private float playerProgress;
    private boolean playerOpen;

    private long animationStartTime;
    private float animationStartProgress;
    private float animationTarget;
    private long animationDuration = 400L;

    private String currentTrackTitle = "No track selected";
    private String currentTrackSubtitle = "Choose a song in Playlist";

    private float scrollTime;

    private List<MusicLibrary.Track> tracks = List.of();
    private int selectedTrackIndex = -1;
    private int playlistScroll;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));

        animationStartTime = Util.getMeasuringTimeMs();
        refreshLibrary();
    }

    // ------------------------------------------------------------
    // Library and playback
    // ------------------------------------------------------------

    private void refreshLibrary() {
        String previousTitle = currentTrackTitle;

        tracks = MusicLibrary.scan();
        selectedTrackIndex = -1;

        for (int i = 0; i < tracks.size(); i++) {
            if (tracks.get(i).title().equalsIgnoreCase(previousTitle)) {
                selectedTrackIndex = i;
                break;
            }
        }

        if (selectedTrackIndex >= 0) {
            updateSelectedTrack();
        } else {
            currentTrackTitle = "No track selected";
            currentTrackSubtitle = "Choose a song in Playlist";
        }

        playlistScroll = Math.max(
                0,
                Math.min(
                        playlistScroll,
                        Math.max(0, tracks.size() - getPlaylistVisibleCount())
                )
        );
    }

    private void updateSelectedTrack() {
        if (selectedTrackIndex < 0 || selectedTrackIndex >= tracks.size()) {
            return;
        }

        MusicLibrary.Track track = tracks.get(selectedTrackIndex);

        currentTrackTitle = track.title();
        currentTrackSubtitle = track.hasLyrics()
                ? "LRC lyrics found"
                : "No lyrics file";
    }

    private void playSelectedTrack() {
        if (selectedTrackIndex < 0 || selectedTrackIndex >= tracks.size()) {
            return;
        }

        MusicLibrary.Track track = tracks.get(selectedTrackIndex);
        File file = track.audioFile().toFile();

        if (MUSIC_PLAYER.isPlaying()
                && file.equals(MUSIC_PLAYER.getCurrentFile())) {
            MUSIC_PLAYER.stop();
            return;
        }

        MUSIC_PLAYER.play(file);
    }

    private void playRelativeTrack(int direction) {
        if (tracks.isEmpty()) {
            return;
        }

        if (selectedTrackIndex < 0) {
            selectedTrackIndex = 0;
        } else {
            selectedTrackIndex = Math.floorMod(
                    selectedTrackIndex + direction,
                    tracks.size()
            );
        }

        updateSelectedTrack();
        playSelectedTrack();
    }

    // ------------------------------------------------------------
    // Layout
    // ------------------------------------------------------------

    private int getPlaylistVisibleCount() {
        return Math.max(1, (getMainHeight() - 195) / 35);
    }

    private int getMainX() {
        return width / 2;
    }

    private int getMainWidth() {
        return width - getMainX() - 12;
    }

    private int getMainHeight() {
        return Math.max(1, Math.min(340, height - 24));
    }

    private int getMainY() {
        return (height - getMainHeight()) / 2;
    }

    private int getPlayerSize() {
        return Math.max(
                130,
                Math.min(220, Math.min(height - 48, width / 2 - 32))
        );
    }

    private int getPlayerY() {
        return (height - getPlayerSize()) / 2;
    }

    private int getPlayerX() {
        int size = getPlayerSize();

        return getMainX() - size - 12
                + (int) ((size + 12) * (1.0f - playerProgress));
    }

    private int getSidebarX() {
        return getMainX() + 15;
    }

    private int getSidebarY() {
        return getMainY() + 70;
    }

    private int getSidebarWidth() {
        return Math.min(145, Math.max(120, getMainWidth() - 205));
    }

    private int getContentX() {
        return getSidebarX() + getSidebarWidth() + 13;
    }

    private int getContentY() {
        return getSidebarY();
    }

    private int getContentWidth() {
        return Math.max(1, getMainWidth() - getSidebarWidth() - 43);
    }

    private int getContentHeight() {
        return Math.max(1, getMainHeight() - 130);
    }

    private int getRefreshX() {
        return getContentX() + getContentWidth() - 62;
    }

    private int getRefreshY() {
        return getContentY() + 12;
    }

    private boolean inside(
            double mouseX,
            double mouseY,
            int x,
            int y,
            int w,
            int h
    ) {
        return mouseX >= x && mouseX <= x + w
                && mouseY >= y && mouseY <= y + h;
    }

    // ------------------------------------------------------------
    // Animation
    // ------------------------------------------------------------

    private float animate(float current, boolean hovered, float delta) {
        float target = hovered ? 1.0f : 0.0f;
        float speed = Math.min(1.0f, Math.max(0.0f, delta) * 10.0f);

        return current + (target - current) * speed;
    }

    private void togglePlayer() {
        playerOpen = !playerOpen;

        animationStartProgress = playerProgress;
        animationTarget = playerOpen ? 1.0f : 0.0f;
        animationStartTime = Util.getMeasuringTimeMs();

        // Closing is slightly slower than opening.
        animationDuration = playerOpen ? 400L : 550L;
    }

    private void updatePlayerAnimation() {
        long elapsed = Math.max(0L, Util.getMeasuringTimeMs() - animationStartTime);

        float t = Math.min(1.0f, elapsed / (float) animationDuration);

        // Smooth ease-in-out curve.
        float eased = t * t * (3.0f - 2.0f * t);

        playerProgress = animationStartProgress
                + (animationTarget - animationStartProgress) * eased;

        if (t >= 1.0f) {
            playerProgress = animationTarget;
        }
    }

    // ------------------------------------------------------------
    // Drawing helpers
    // ------------------------------------------------------------

    private int lerpColor(int from, int to, float amount) {
        amount = Math.max(0.0f, Math.min(1.0f, amount));

        int a = lerpChannel((from >> 24) & 255, (to >> 24) & 255, amount);
        int r = lerpChannel((from >> 16) & 255, (to >> 16) & 255, amount);
        int g = lerpChannel((from >> 8) & 255, (to >> 8) & 255, amount);
        int b = lerpChannel(from & 255, to & 255, amount);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private int lerpChannel(int from, int to, float amount) {
        return (int) (from + (to - from) * amount);
    }

    private void roundedRect(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            int color
    ) {
        if (w <= 0 || h <= 0) {
            return;
        }

        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        if (radius == 0) {
            context.fill(x, y, x + w, y + h, color);
            return;
        }

        int band = Math.max(1, radius / 3);
        band = Math.min(band, h / 2);

        int inset1 = calculateInset(radius, band);
        int inset2 = calculateInset(radius, Math.min(radius, band * 2));

        context.fill(x + inset1, y, x + w - inset1, y + band, color);

        context.fill(
                x + inset2, y + band,
                x + w - inset2, y + band * 2, color
        );

        int middleTop = y + band * 2;
        int middleBottom = y + h - band * 2;

        if (middleBottom > middleTop) {
            context.fill(x, middleTop, x + w, middleBottom, color);
        }

        context.fill(
                x + inset2, y + h - band * 2,
                x + w - inset2, y + h - band, color
        );

        context.fill(
                x + inset1, y + h - band,
                x + w - inset1, y + h, color
        );
    }

    private int calculateInset(int radius, int distance) {
        double remaining = radius - distance;

        return Math.max(
                0,
                radius - (int) Math.sqrt(
                        Math.max(0, radius * radius - remaining * remaining)
                )
        );
    }

    private void glassPanel(
            DrawContext context,
            int x,
            int y,
            int w,
            int h
    ) {
        // Ambient purple edge and layered glass surface.
        roundedRect(context, x - 5, y - 5, w + 10, h + 10, 22, 0x189E5CEB);
        roundedRect(context, x - 3, y - 3, w + 6, h + 6, 20, 0x359A60D5);
        roundedRect(context, x - 1, y - 1, w + 2, h + 2, 18, 0xAA39264F);
        roundedRect(context, x, y, w, h, 17, BACKGROUND);
        roundedRect(context, x + 1, y + 1, w - 2, h - 2, 16, PANEL);

        // Subtle top highlight.
        context.fill(x + 18, y + 1, x + w - 18, y + 2, 0x2EDFC0FF);
    }

    private void drawButton(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int radius,
            float progress,
            int normalColor,
            int hoverColor
    ) {
        float scale = 1.0f + progress * 0.035f;
        int color = lerpColor(normalColor, hoverColor, progress);

        float centerX = x + w / 2.0f;
        float centerY = y + h / 2.0f;

        context.getMatrices().push();
        context.getMatrices().translate(centerX, centerY, 0);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-centerX, -centerY, 0);

        if (progress > 0.05f) {
            roundedRect(
                    context,
                    x - 2, y - 2, w + 4, h + 4,
                    radius + 2,
                    (int) (progress * 35) << 24 | 0x00B77AEF
            );
        }

        roundedRect(context, x, y, w, h, radius, color);
        context.getMatrices().pop();
    }

    private void drawClippedText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int color
    ) {
        if (maxWidth <= 0 || text == null || text.isEmpty()) {
            return;
        }

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);
        context.drawTextWithShadow(textRenderer, text, x, y, color);
        context.disableScissor();
    }

    private void drawWrappedText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int maxHeight,
            int color
    ) {
        if (maxWidth <= 0 || maxHeight <= 0 || text == null) {
            return;
        }

        List<OrderedText> lines =
                textRenderer.wrapLines(Text.literal(text), maxWidth);

        context.enableScissor(x, y - 2, x + maxWidth, y + maxHeight);

        int lineY = y;

        for (OrderedText line : lines) {
            if (lineY + 9 > y + maxHeight) {
                break;
            }

            context.drawTextWithShadow(textRenderer, line, x, lineY, color);
            lineY += 10;
        }

        context.disableScissor();
    }

    private void drawScrollingText(
            DrawContext context,
            String text,
            int x,
            int y,
            int maxWidth,
            int color
    ) {
        if (maxWidth <= 0 || text == null || text.isEmpty()) {
            return;
        }

        int textWidth = textRenderer.getWidth(text);

        context.enableScissor(x, y - 2, x + maxWidth, y + 12);

        if (textWidth <= maxWidth) {
            context.drawTextWithShadow(textRenderer, text, x, y, color);
        } else {
            float delay = 1.2f;
            float speed = 3.0f;
            float gap = 28.0f;

            float elapsed = Math.max(0.0f, scrollTime - delay);
            float offset = (elapsed * speed) % (textWidth + gap);

            int drawX = x - (int) offset;

            context.drawTextWithShadow(textRenderer, text, drawX, y, color);
            context.drawTextWithShadow(
                    textRenderer,
                    text,
                    drawX + textWidth + (int) gap,
                    y,
                    color
            );
        }

        context.disableScissor();
    }

    // ------------------------------------------------------------
    // Icons
    // ------------------------------------------------------------

    private void drawPlayIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(x + i, y + i, x + i + 1, y + 17 - i, color);
        }
    }

    private void drawSlidersIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        context.fill(x, y + 3, x + 19, y + 5, color);
        context.fill(x, y + 9, x + 19, y + 11, color);
        context.fill(x, y + 15, x + 19, y + 17, color);

        context.fill(x + 5, y + 1, x + 9, y + 7, color);
        context.fill(x + 13, y + 7, x + 17, y + 13, color);
        context.fill(x + 7, y + 13, x + 11, y + 19, color);
    }

    private void drawSettingsIcon(
            DrawContext context,
            int x,
            int y,
            int color
    ) {
        context.fill(x + 7, y, x + 12, y + 19, color);
        context.fill(x, y + 7, x + 19, y + 12, color);

        context.fill(x + 3, y + 2, x + 7, y + 6, color);
        context.fill(x + 12, y + 13, x + 16, y + 17, color);
        context.fill(x + 3, y + 13, x + 7, y + 17, color);
        context.fill(x + 12, y + 2, x + 16, y + 6, color);

        roundedRect(context, x + 6, y + 6, 7, 7, 3, PURPLE_DARK);
    }

    // ------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------

    private void drawTab(
            DrawContext context,
            int x,
            int y,
            int tabWidth,
            String label,
            int tab,
            boolean hovered,
            float delta
    ) {
        boolean active = selectedTab == tab;

        hoverProgress[tab] = animate(hoverProgress[tab], hovered, delta);

        float progress = hoverProgress[tab];

        int normalColor = active ? 0xFF68458E : 0xFF292035;
        int hoverColor = active ? 0xFF9864C7 : 0xFF49315F;

        drawButton(
                context, x, y, tabWidth, 34, 9,
                progress, normalColor, hoverColor
        );

        if (tab == 0) {
            drawPlayIcon(context, x + 8, y + 9, LIGHT);
        } else if (tab == 1) {
            drawSlidersIcon(context, x + 8, y + 7, LIGHT);
        } else {
            drawSettingsIcon(context, x + 8, y + 7, LIGHT);
        }

        drawClippedText(
                context,
                label,
                x + 36,
                y + 12,
                tabWidth - 42,
                active ? WHITE : LIGHT
        );

        if (active) {
            roundedRect(context, x + 2, y + 8, 2, 18, 1, PURPLE_LIGHT);
        }
    }

    private void drawSectionTitle(
            DrawContext context,
            String title,
            int x,
            int y,
            int width
    ) {
        drawClippedText(context, title, x, y, width, WHITE);
        context.fill(x, y + 17, x + Math.max(20, width), y + 18, 0x553F3152);
    }

    // ------------------------------------------------------------
    // Player drawer
    // ------------------------------------------------------------

    private void drawPlayerPanelContent(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        int size = getPlayerSize();
        int x = getPlayerX();
        int y = getPlayerY();

        roundedRect(
                context,
                x + 12, y + 12,
                size - 24, 30,
                9,
                0xFF281E38
        );

        drawClippedText(
                context,
                "VORTEX PLAYER",
                x + 20,
                y + 22,
                size - 40,
                LIGHT
        );

        int coverSize = Math.max(38, Math.min(48, size - 76));
        int coverX = x + 14;
        int coverY = y + 50;

        roundedRect(
                context,
                coverX - 2, coverY - 2,
                coverSize + 4, coverSize + 4,
                11,
                0x665E3D80
        );

        roundedRect(
                context,
                coverX, coverY,
                coverSize, coverSize,
                9,
                0xFF39254D
        );

        roundedRect(
                context,
                coverX + 4, coverY + 4,
                coverSize - 8, coverSize - 8,
                7,
                0xFF62417F
        );

        String question = "V";
        int questionWidth = textRenderer.getWidth(question);

        context.drawTextWithShadow(
                textRenderer,
                question,
                coverX + (coverSize - questionWidth) / 2,
                coverY + (coverSize - 9) / 2,
                LIGHT
        );

        int textX = coverX + coverSize + 9;
        int textWidth = size - coverSize - 37;
        int titleY = coverY + 3;

        drawScrollingText(
                context,
                currentTrackTitle,
                textX,
                titleY,
                textWidth,
                LIGHT
        );

        drawWrappedText(
                context,
                currentTrackSubtitle,
                textX,
                titleY + 15,
                textWidth,
                25,
                MUTED
        );

        int timelineX = x + 15;
        int timelineY = y + size - 43;
        int timelineWidth = size - 30;

        roundedRect(
                context,
                timelineX,
                timelineY,
                timelineWidth,
                3,
                2,
                0xFF49375F
        );

        roundedRect(
                context,
                timelineX,
                timelineY,
                4,
                3,
                2,
                PURPLE_LIGHT
        );

        int buttonY = y + size - 32;
        int centerX = x + size / 2;

        int prevX = centerX - 45;
        int playX = centerX - 14;
        int nextX = centerX + 19;

        previousHover = animate(
                previousHover,
                inside(mouseX, mouseY, prevX, buttonY + 2, 26, 23),
                delta
        );

        playHover = animate(
                playHover,
                inside(mouseX, mouseY, playX, buttonY - 1, 28, 28),
                delta
        );

        nextHover = animate(
                nextHover,
                inside(mouseX, mouseY, nextX, buttonY + 2, 26, 23),
                delta
        );

        drawButton(
                context,
                prevX, buttonY + 2, 26, 23, 7,
                previousHover,
                0xFF40304F,
                0xFF7952A0
        );

        drawButton(
                context,
                playX, buttonY - 1, 28, 28, 9,
                playHover,
                PURPLE,
                PURPLE_LIGHT
        );

        drawButton(
                context,
                nextX, buttonY + 2, 26, 23, 7,
                nextHover,
                0xFF40304F,
                0xFF7952A0
        );

        // Previous icon
        context.fill(centerX - 37, buttonY + 8, centerX - 35, buttonY + 19, LIGHT);
        context.fill(centerX - 34, buttonY + 8, centerX - 26, buttonY + 19, LIGHT);

        // Play icon
        drawPlayIcon(context, centerX - 5, buttonY + 5, WHITE);

        // Next icon
        context.fill(centerX + 26, buttonY + 8, centerX + 34, buttonY + 19, LIGHT);
        context.fill(centerX + 35, buttonY + 8, centerX + 37, buttonY + 19, LIGHT);
    }

    private void drawPlayerHandle(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        int x = getMainX() - 7;
        int y = height / 2 - 35;

        boolean hovered = inside(mouseX, mouseY, x - 3, y, 20, 70);

        handleHover = animate(handleHover, hovered, delta);

        drawButton(
                context,
                x, y, 14, 70, 7,
                handleHover,
                0xFF68458E,
                0xFFAD7BE0
        );

        roundedRect(context, x + 6, y + 23, 2, 24, 1, LIGHT);
    }

    // ------------------------------------------------------------
    // Other tab
    // ------------------------------------------------------------

    private void drawOtherTab(
            DrawContext context,
            int x,
            int y,
            int panelWidth,
            int panelHeight
    ) {
        drawSectionTitle(context, "About VortexLyrics", x, y, panelWidth);

        int cardY = y + 30;
        int cardHeight = Math.min(75, Math.max(48, panelHeight / 3));

        roundedRect(
                context,
                x, cardY,
                panelWidth, cardHeight,
                10,
                ROW
        );

        roundedRect(
                context,
                x + 10, cardY + 12,
                4, cardHeight - 24,
                2,
                PURPLE_LIGHT
        );

        drawClippedText(
                context,
                "VORTEX LYRICS",
                x + 23,
                cardY + 13,
                panelWidth - 35,
                WHITE
        );

        drawWrappedText(
                context,
                "A music player and lyrics interface for Minecraft.",
                x + 23,
                cardY + 29,
                panelWidth - 35,
                cardHeight - 30,
                MUTED
        );

        int infoY = cardY + cardHeight + 18;

        drawClippedText(
                context,
                "Library",
                x + 4,
                infoY,
                panelWidth - 8,
                LIGHT
        );

        drawWrappedText(
                context,
                "Songs found: " + tracks.size(),
                x + 4,
                infoY + 17,
                panelWidth - 8,
                30,
                MUTED
        );

        drawClippedText(
                context,
                "Supported audio",
                x + 4,
                infoY + 53,
                panelWidth - 8,
                LIGHT
        );

        drawWrappedText(
                context,
                "MP3 and OGG",
                x + 4,
                infoY + 70,
                panelWidth - 8,
                25,
                MUTED
        );

        drawClippedText(
                context,
                "Lyrics format",
                x + 4,
                infoY + 105,
                panelWidth - 8,
                LIGHT
        );

        drawWrappedText(
                context,
                "LRC synchronized lyrics files",
                x + 4,
                infoY + 122,
                panelWidth - 8,
                30,
                MUTED
        );
    }

    // ------------------------------------------------------------
    // Settings tab
    // ------------------------------------------------------------

    private void drawSettingsTab(
            DrawContext context,
            int x,
            int y,
            int panelWidth,
            int panelHeight
    ) {
        drawSectionTitle(context, "Settings", x, y, panelWidth);

        int cardY = y + 30;
        int cardHeight = 48;

        roundedRect(
                context,
                x, cardY,
                panelWidth, cardHeight,
                9,
                ROW
        );

        drawClippedText(
                context,
                "Interface",
                x + 11,
                cardY + 9,
                panelWidth - 22,
                LIGHT
        );

        drawClippedText(
                context,
                "Purple glass theme",
                x + 11,
                cardY + 25,
                panelWidth - 22,
                MUTED
        );

        int secondY = cardY + cardHeight + 10;

        roundedRect(
                context,
                x, secondY,
                panelWidth, cardHeight,
                9,
                ROW
        );

        drawClippedText(
                context,
                "Performance",
                x + 11,
                secondY + 9,
                panelWidth - 22,
                LIGHT
        );

        drawClippedText(
                context,
                "Lightweight layered effects",
                x + 11,
                secondY + 25,
                panelWidth - 22,
                MUTED
        );

        int thirdY = secondY + cardHeight + 10;

        roundedRect(
                context,
                x, thirdY,
                panelWidth, cardHeight,
                9,
                ROW
        );

        drawClippedText(
                context,
                "Audio",
                x + 11,
                thirdY + 9,
                panelWidth - 22,
                LIGHT
        );

        drawClippedText(
                context,
                "MP3 / OGG playback",
                x + 11,
                thirdY + 25,
                panelWidth - 22,
                MUTED
        );

        int noteY = thirdY + cardHeight + 14;

        drawWrappedText(
                context,
                "More configurable options can be added here later.",
                x + 3,
                noteY,
                panelWidth - 6,
                Math.max(20, panelHeight - (noteY - y)),
                DIM
        );
    }

    // ------------------------------------------------------------
    // Playlist
    // ------------------------------------------------------------

    private void drawPlaylist(
            DrawContext context,
            int contentX,
            int contentY,
            int contentW,
            int contentH
    ) {
        drawClippedText(
                context,
                "Playlist (" + tracks.size() + ")",
                contentX + 12,
                contentY + 17,
                contentW - 85,
                WHITE
        );

        int refreshX = getRefreshX();
        int refreshY = getRefreshY();

        drawButton(
                context,
                refreshX, refreshY, 50, 23, 7,
                refreshHover,
                0xFF40304F,
                0xFF8055A8
        );

        drawClippedText(
                context,
                "Refresh",
                refreshX + 5,
                refreshY + 6,
                42,
                LIGHT
        );

        int listX = contentX + 7;
        int listY = contentY + 48;
        int rowWidth = Math.max(1, contentW - 14);
        int rowHeight = 30;
        int rowStep = 35;
        int visibleCount = getPlaylistVisibleCount();

        if (tracks.isEmpty()) {
            drawWrappedText(
                    context,
                    "No songs found. Add MP3 or OGG files to the vortexlyrics/music folder.",
                    contentX + 12,
                    contentY + 65,
                    contentW - 24,
                    contentH - 75,
                    MUTED
            );
            return;
        }

        context.enableScissor(
                listX,
                listY,
                listX + rowWidth,
                listY + visibleCount * rowStep
        );

        int end = Math.min(tracks.size(), playlistScroll + visibleCount);

        for (int i = playlistScroll; i < end; i++) {
            int visibleIndex = i - playlistScroll;
            int rowY = listY + visibleIndex * rowStep;

            boolean selected = i == selectedTrackIndex;

            roundedRect(
                    context,
                    listX, rowY,
                    rowWidth, rowHeight,
                    8,
                    selected ? ROW_SELECTED : ROW
            );

            if (selected) {
                roundedRect(
                        context,
                        listX + 2, rowY + 7,
                        2, rowHeight - 14,
                        1,
                        PURPLE_LIGHT
                );
            }

            MusicLibrary.Track track = tracks.get(i);

            drawClippedText(
                    context,
                    track.title(),
                    listX + 9,
                    rowY + 10,
                    rowWidth - 65,
                    LIGHT
            );

            String status = track.hasLyrics() ? "LRC" : "NO LRC";

            drawClippedText(
                    context,
                    status,
                    listX + rowWidth - 49,
                    rowY + 10,
                    43,
                    track.hasLyrics() ? 0xFFB9F6CA : MUTED
            );
        }

        context.disableScissor();

        if (tracks.size() > visibleCount) {
            String counter = (playlistScroll + 1)
                    + "-" + end + " / " + tracks.size();

            drawClippedText(
                    context,
                    counter,
                    contentX + 12,
                    contentY + contentH - 15,
                    contentW - 24,
                    MUTED
            );
        }
    }

    // ------------------------------------------------------------
    // Main render
    // ------------------------------------------------------------

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        scrollTime += Math.max(0.0f, Math.min(delta, 1.0f));

        updatePlayerAnimation();

        refreshHover = animate(
                refreshHover,
                selectedTab == 0 && inside(
                        mouseX,
                        mouseY,
                        getRefreshX(),
                        getRefreshY(),
                        50,
                        23
                ),
                delta
        );

        // Draw the player drawer only while it is visible.
        if (playerProgress > 0.001f) {
            context.enableScissor(0, 0, getMainX(), height);

            glassPanel(
                    context,
                    getPlayerX(),
                    getPlayerY(),
                    getPlayerSize(),
                    getPlayerSize()
            );

            drawPlayerPanelContent(context, mouseX, mouseY, delta);

            context.disableScissor();
        }

        int mainX = getMainX();
        int mainY = getMainY();
        int mainW = getMainWidth();
        int mainH = getMainHeight();

        glassPanel(context, mainX, mainY, mainW, mainH);

        // Header
        drawClippedText(
                context,
                "VortexLyrics",
                mainX + 18,
                mainY + 18,
                mainW - 36,
                WHITE
        );

        drawClippedText(
                context,
                "MUSIC EXPERIENCE",
                mainX + 18,
                mainY + 34,
                mainW - 36,
                DIM
        );

        int sidebarX = getSidebarX();
        int sidebarY = getSidebarY();
        int sidebarW = getSidebarWidth();

        int tabWidth = sidebarW;
        int tabHeight = 34;
        int tabGap = 9;

        drawTab(
                context,
                sidebarX,
                sidebarY,
                tabWidth,
                "Music",
                0,
                inside(mouseX, mouseY, sidebarX, sidebarY, tabWidth, tabHeight),
                delta
        );

        drawTab(
                context,
                sidebarX,
                sidebarY + tabHeight + tabGap,
                tabWidth,
                "Other",
                1,
                inside(
                        mouseX,
                        mouseY,
                        sidebarX,
                        sidebarY + tabHeight + tabGap,
                        tabWidth,
                        tabHeight
                ),
                delta
        );

        drawTab(
                context,
                sidebarX,
                sidebarY + (tabHeight + tabGap) * 2,
                tabWidth,
                "Settings",
                2,
                inside(
                        mouseX,
                        mouseY,
                        sidebarX,
                        sidebarY + (tabHeight + tabGap) * 2,
                        tabWidth,
                        tabHeight
                ),
                delta
        );

        int contentX = getContentX();
        int contentY = getContentY();
        int contentW = getContentWidth();
        int contentH = getContentHeight();

        if (selectedTab == 0) {
            drawPlaylist(
                    context,
                    contentX,
                    contentY,
                    contentW,
                    contentH
            );
        } else if (selectedTab == 1) {
            drawOtherTab(
                    context,
                    contentX + 12,
                    contentY + 17,
                    contentW - 24,
                    contentH - 20
            );
        } else {
            drawSettingsTab(
                    context,
                    contentX + 12,
                    contentY + 17,
                    contentW - 24,
                    contentH - 20
            );
        }

        drawPlayerHandle(context, mouseX, mouseY, delta);

        super.render(context, mouseX, mouseY, delta);
    }

    // ------------------------------------------------------------
    // Mouse input
    // ------------------------------------------------------------

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        int handleX = getMainX() - 7;
        int handleY = height / 2 - 35;

        if (inside(mouseX, mouseY, handleX - 3, handleY, 20, 70)) {
            togglePlayer();
            return true;
        }

        if (playerOpen && playerProgress > 0.95f) {
            int size = getPlayerSize();
            int x = getPlayerX();
            int y = getPlayerY();

            int centerX = x + size / 2;
            int buttonY = y + size - 32;

            if (inside(
                    mouseX,
                    mouseY,
                    centerX - 45,
                    buttonY + 2,
                    26,
                    23
            )) {
                playRelativeTrack(-1);
                return true;
            }

            if (inside(
                    mouseX,
                    mouseY,
                    centerX - 14,
                    buttonY - 1,
                    28,
                    28
            )) {
                playSelectedTrack();
                return true;
            }

            if (inside(
                    mouseX,
                    mouseY,
                    centerX + 19,
                    buttonY + 2,
                    26,
                    23
            )) {
                playRelativeTrack(1);
                return true;
            }
        }

        if (selectedTab == 0 && inside(
                mouseX,
                mouseY,
                getRefreshX(),
                getRefreshY(),
                50,
                23
        )) {
            refreshLibrary();
            return true;
        }

        int sidebarX = getSidebarX();
        int sidebarY = getSidebarY();
        int sidebarW = getSidebarWidth();

        int tabHeight = 34;
        int tabGap = 9;

        for (int i = 0; i < 3; i++) {
            int tabY = sidebarY + i * (tabHeight + tabGap);

            if (inside(
                    mouseX,
                    mouseY,
                    sidebarX,
                    tabY,
                    sidebarW,
                    tabHeight
            )) {
                selectedTab = i;
                return true;
            }
        }

        if (selectedTab == 0) {
            int listX = getContentX() + 7;
            int listY = getContentY() + 48;
            int rowWidth = getContentWidth() - 14;
            int rowStep = 35;
            int visibleCount = getPlaylistVisibleCount();

            if (inside(
                    mouseX,
                    mouseY,
                    listX,
                    listY,
                    rowWidth,
                    visibleCount * rowStep
            )) {
                int visibleIndex = (int) ((mouseY - listY) / rowStep);
                int index = playlistScroll + visibleIndex;

                if (visibleIndex >= 0
                        && visibleIndex < visibleCount
                        && index >= 0
                        && index < tracks.size()) {
                    selectedTrackIndex = index;
                    updateSelectedTrack();
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    // Fabric / Minecraft 1.20.1
    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {
        if (selectedTab == 0) {
            int listX = getContentX() + 7;
            int listY = getContentY() + 48;
            int rowWidth = getContentWidth() - 14;
            int visibleCount = getPlaylistVisibleCount();

            if (inside(
                    mouseX,
                    mouseY,
                    listX,
                    listY,
                    rowWidth,
                    visibleCount * 35
            )) {
                int maxScroll = Math.max(
                        0,
                        tracks.size() - visibleCount
                );

                playlistScroll -= (int) Math.signum(amount);

                playlistScroll = Math.max(
                        0,
                        Math.min(maxScroll, playlistScroll)
                );

                return true;
            }
        }

        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
