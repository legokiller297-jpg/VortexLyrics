
package ru.lyricsmod;

import net.minecraft.client.MinecraftClient;
import java.io.File;

public final class MusicPlayer {

    private static MusicPlayer activePlayer;

    private File currentFile;
    private FileMusicSound currentSound;
    private long playbackStartNanos;

    public void play(File file) {
        if (file == null || !file.isFile()) {
            System.err.println("[VortexLyrics] Audio file not found.");
            return;
        }

        stop();

        MinecraftClient client = MinecraftClient.getInstance();

        currentFile = file;
        currentSound = new FileMusicSound(file);
        playbackStartNanos = System.nanoTime();
        activePlayer = this;

        client.getSoundManager().play(currentSound);
    }

    public void stop() {
        MinecraftClient client = MinecraftClient.getInstance();

        if (currentSound != null) {
            client.getSoundManager().stop(currentSound);
        }

        currentSound = null;
        currentFile = null;
        playbackStartNanos = 0L;

        if (activePlayer == this) {
            activePlayer = null;
        }
    }

    public boolean isPlaying() {
        if (currentSound == null) {
            return false;
        }

        return MinecraftClient.getInstance()
                .getSoundManager()
                .isPlaying(currentSound);
    }

    public File getCurrentFile() {
        return currentFile;
    }

    public long getPlaybackPositionMs() {
        if (currentFile == null || playbackStartNanos == 0L) {
            return 0L;
        }

        return (System.nanoTime() - playbackStartNanos) / 1_000_000L;
    }

    public static File getActiveFile() {
        return activePlayer == null
                ? null
                : activePlayer.getCurrentFile();
    }

    public static long getActivePlaybackPositionMs() {
        return activePlayer == null
                ? 0L
                : activePlayer.getPlaybackPositionMs();
    }
}

