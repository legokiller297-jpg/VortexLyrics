
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.sound.v1.FabricSoundInstance;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.AudioStream;
import net.minecraft.client.sound.SoundLoader;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

public final class FileMusicSound extends AbstractSoundInstance
        implements FabricSoundInstance {

    private final File file;

    public FileMusicSound(File file) {
        super(
                new Identifier("lyricsmod", "music_stream"),
                SoundCategory.MUSIC,
                Random.create()
        );

        this.file = file;
        this.repeat = false;
        this.volume = 1.0f;
        this.relative = true;
    }

    @Override
    public CompletableFuture<AudioStream> getAudioStream(
            SoundLoader loader,
            Identifier id,
            boolean repeatInstantly
    ) {
        System.out.println(
                "[VortexLyrics] Запрошен аудиопоток: " + file
        );

        return CompletableFuture.supplyAsync(() -> {
            try {
                System.out.println(
                        "[VortexLyrics] Начинаю декодирование: " + file
                );

                debug(file, "Перед созданием FileAudioStream: " + file, null);

                AudioStream audioStream =
                        new FileAudioStream(file.toPath());

                System.out.println(
                        "[VortexLyrics] Аудиопоток создан успешно"
                );

                debug(file, "FileAudioStream создан успешно", null);

                return audioStream;

            } catch (Throwable error) {
                System.err.println(
                        "[VortexLyrics] Ошибка создания аудиопотока"
                );

                error.printStackTrace();

                debug(
                        file,
                        "Ошибка до или во время создания FileAudioStream",
                        error
                );

                throw new CompletionException(error);
            }
        });
    }

    private static void debug(
            File audioFile,
            String message,
            Throwable error
    ) {
        try {
            Path musicFolder =
                    audioFile.toPath().toAbsolutePath().getParent();

            if (musicFolder == null || musicFolder.getParent() == null) {
                System.err.println(
                        "[VortexLyrics] Не удалось определить папку debug-файла"
                );
                return;
            }

            Path logFile = musicFolder.getParent()
                    .resolve("vortexlyrics-debug.txt");

            StringBuilder text = new StringBuilder();

            text.append("[")
                    .append(LocalDateTime.now())
                    .append("] ")
                    .append(message)
                    .append(System.lineSeparator());

            if (error != null) {
                StringWriter writer = new StringWriter();
                error.printStackTrace(new PrintWriter(writer));
                text.append(writer);
            }

            Files.writeString(
                    logFile,
                    text.toString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );

        } catch (Throwable loggingError) {
            System.err.println(
                    "[VortexLyrics] Не удалось записать debug-файл"
            );

            loggingError.printStackTrace();
        }
    }
}

