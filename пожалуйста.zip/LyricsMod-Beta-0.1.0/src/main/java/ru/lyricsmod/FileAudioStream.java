
package ru.lyricsmod;

import net.minecraft.client.sound.AudioStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.spi.FormatConversionProvider;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.Locale;

public final class FileAudioStream implements AudioStream {

    private final AudioInputStream stream;
    private final AudioFormat format;

    private boolean closed;
    private boolean firstBufferLogged;

    public FileAudioStream(Path file) throws Exception {
        AudioInputStream original = null;
        AudioInputStream converted = null;

        System.out.println(
                "[VortexLyrics] STEP 0: конструктор FileAudioStream запущен"
        );

        log(file, "Конструктор FileAudioStream запущен: " + file);

        try {
            String name = file.getFileName()
                    .toString()
                    .toLowerCase(Locale.ROOT);

            FormatConversionProvider converter;

            if (name.endsWith(".mp3")) {
                System.out.println(
                        "[VortexLyrics] STEP 1: открываю MP3"
                );

                original = new javazoom.spi.mpeg.sampled.file
                        .MpegAudioFileReader()
                        .getAudioInputStream(file.toFile());

                converter = new javazoom.spi.mpeg.sampled.convert
                        .MpegFormatConversionProvider();

            } else if (name.endsWith(".ogg")) {
                System.out.println(
                        "[VortexLyrics] STEP 1: открываю OGG"
                );

                original = new javazoom.spi.vorbis.sampled.file
                        .VorbisAudioFileReader()
                        .getAudioInputStream(file.toFile());

                converter = new javazoom.spi.vorbis.sampled.convert
                        .VorbisFormatConversionProvider();

            } else {
                throw new UnsupportedAudioFileException(
                        "Поддерживаются только MP3 и OGG"
                );
            }

            System.out.println(
                    "[VortexLyrics] STEP 2: исходный поток открыт"
            );

            AudioFormat sourceFormat = original.getFormat();

            log(file, "Исходный формат: " + sourceFormat);

            int channels = sourceFormat.getChannels();
            float sampleRate = sourceFormat.getSampleRate();

            if (channels <= 0 || sampleRate <= 0) {
                throw new UnsupportedAudioFileException(
                        "Некорректные параметры аудио"
                );
            }

            AudioFormat pcmFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    sampleRate,
                    16,
                    channels,
                    channels * 2,
                    sampleRate,
                    false
            );

            if (!converter.isConversionSupported(
                    pcmFormat,
                    sourceFormat
            )) {
                throw new UnsupportedAudioFileException(
                        "Нельзя преобразовать аудио в PCM: "
                                + sourceFormat
                );
            }

            System.out.println(
                    "[VortexLyrics] STEP 3: начинаю PCM"
            );

            converted = converter.getAudioInputStream(
                    pcmFormat,
                    original
            );

            System.out.println(
                    "[VortexLyrics] STEP 4: PCM готов"
            );

            if (converted == null) {
                throw new IOException(
                        "Декодер вернул пустой аудиопоток"
                );
            }

            stream = converted;
            format = pcmFormat;

            log(file, "Аудиопоток успешно создан: " + pcmFormat);

            System.out.println(
                    "[VortexLyrics] Декодирование успешно завершено"
            );

        } catch (Throwable error) {
            if (converted != null) {
                try {
                    converted.close();
                } catch (Exception ignored) {
                }
            }

            if (original != null) {
                try {
                    original.close();
                } catch (Exception ignored) {
                }
            }

            logError(file, "Ошибка создания аудиопотока", error);

            System.err.println(
                    "[VortexLyrics] ОШИБКА ДЕКОДИРОВАНИЯ"
            );

            error.printStackTrace();

            if (error instanceof Exception exception) {
                throw exception;
            }

            if (error instanceof Error fatalError) {
                throw fatalError;
            }

            throw new RuntimeException(error);
        }
    }

    @Override
    public synchronized ByteBuffer getBuffer(int size)
            throws IOException {

        if (closed) {
            throw new IOException("Аудиопоток закрыт");
        }

        try {
            byte[] bytes = new byte[size];
            int total = 0;

            while (total < size) {
                int read = stream.read(
                        bytes,
                        total,
                        size - total
                );

                if (read < 0) {
                    break;
                }

                if (read > 0) {
                    total += read;
                }
            }

            if (!firstBufferLogged) {
                firstBufferLogged = true;

                logFromStream(
                        "Первый аудиобуфер получен: "
                                + total + " байт"
                );
            }

            ByteBuffer buffer = ByteBuffer.allocateDirect(total);
            buffer.put(bytes, 0, total);
            buffer.flip();

            return buffer;

        } catch (IOException error) {
            logFromStreamError("Ошибка чтения аудио", error);
            throw error;
        }
    }

    @Override
    public AudioFormat getFormat() {
        return format;
    }

    @Override
    public synchronized void close() throws IOException {
        if (!closed) {
            closed = true;
            logFromStream("Закрытие аудиопотока");
            stream.close();
        }
    }

    private void logFromStream(String message) {
        System.out.println("[VortexLyrics] " + message);
    }

    private void logFromStreamError(
            String message,
            Throwable error
    ) {
        System.err.println("[VortexLyrics] " + message);
        error.printStackTrace();
    }

    private static void log(Path file, String message) {
        writeLog(file, message, null);
    }

    private static void logError(
            Path file,
            String message,
            Throwable error
    ) {
        writeLog(file, message, error);
    }

    private static void writeLog(
            Path audioFile,
            String message,
            Throwable error
    ) {
        try {
            Path musicFolder =
                    audioFile.toAbsolutePath().getParent();

            if (musicFolder == null || musicFolder.getParent() == null) {
                return;
            }

            Path logFile = musicFolder.getParent()
                    .resolve("vortexlyrics-debug.txt");

            StringBuilder text = new StringBuilder();

            text.append("[")
                    .append(LocalDateTime.now())
                    .append("] ")
                    .append(message)
                    .append(System.lineSeparator());

            if (error != null) {
                StringWriter writer = new StringWriter();
                error.printStackTrace(new PrintWriter(writer));
                text.append(writer);
            }

            Files.writeString(
                    logFile,
                    text.toString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );

        } catch (Throwable loggingError) {
            System.err.println(
                    "[VortexLyrics] Не удалось записать debug-файл"
            );

            loggingError.printStackTrace();
        }
    }
}

