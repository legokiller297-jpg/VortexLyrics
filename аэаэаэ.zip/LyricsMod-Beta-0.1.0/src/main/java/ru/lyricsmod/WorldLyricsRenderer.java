
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WorldLyricsRenderer {

    private static final Pattern TIMESTAMP_PATTERN =
            Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");

    private static final List<LyricLine> LINES = new ArrayList<>();

    private static File loadedFile;
    private static int currentLine = -1;
    private static Vec3d lineWorldPosition;

    private WorldLyricsRenderer() {
    }

    public static void register() {
        WorldRenderEvents.LAST.register(WorldLyricsRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null
                || client.world == null
                || client.textRenderer == null) {
            clear();
            return;
        }

        // Не сбрасываем текст во время паузы Minecraft.
        if (client.isPaused()) {
            return;
        }

        File audioFile = MusicPlayer.getActiveFile();

        // Музыка остановлена.
        if (audioFile == null) {
            clear();
            return;
        }

        // Музыка завершилась естественным образом.
        if (MusicPlayer.hasActiveFinished()) {
            MusicPlayer.stopActive();
            clear();
            return;
        }

        // Не обновляем текст, пока музыка не воспроизводится.
        if (!MusicPlayer.isActivePlaying()) {
            return;
        }

        updateLyrics(audioFile);

        if (LINES.isEmpty()) {
            return;
        }

        long playbackPosition =
                MusicPlayer.getActivePlaybackPositionMs();

        int newLine = findCurrentLine(playbackPosition);

        if (newLine != currentLine) {
            currentLine = newLine;

            lineWorldPosition = currentLine >= 0
                    ? calculateWorldPosition(client)
                    : null;
        }

        if (currentLine < 0
                || currentLine >= LINES.size()
                || lineWorldPosition == null) {
            return;
        }

        renderText(
                context,
                client,
                LINES.get(currentLine).text
        );
    }

    private static void updateLyrics(File audioFile) {
        if (loadedFile != null && loadedFile.equals(audioFile)) {
            return;
        }

        // Очищаем данные предыдущей песни.
        LINES.clear();
        currentLine = -1;
        lineWorldPosition = null;
        loadedFile = audioFile;

        // Ищем трек через старую MusicLibrary.
        Path audioPath = audioFile.toPath();

        MusicLibrary.Track track = MusicLibrary.scan()
                .stream()
                .filter(item -> item.audioFile().equals(audioPath))
                .findFirst()
                .orElse(null);

        if (track == null || !track.hasLyrics()) {
            return;
        }

        Path lyricsPath = track.lyricsFile();

        if (lyricsPath == null || !Files.isRegularFile(lyricsPath)) {
            return;
        }

        try {
            List<String> fileLines = Files.readAllLines(
                    lyricsPath,
                    StandardCharsets.UTF_8
            );

            for (String line : fileLines) {
                Matcher matcher = TIMESTAMP_PATTERN.matcher(line);

                List<Long> timestamps = new ArrayList<>();
                int lastTimestampEnd = 0;

                while (matcher.find()) {
                    long minutes =
                            Long.parseLong(matcher.group(1));

                    long seconds =
                            Long.parseLong(matcher.group(2));

                    String fraction = matcher.group(3);
                    long milliseconds = 0L;

                    if (fraction != null) {
                        if (fraction.length() == 1) {
                            milliseconds =
                                    Long.parseLong(fraction) * 100L;
                        } else if (fraction.length() == 2) {
                            milliseconds =
                                    Long.parseLong(fraction) * 10L;
                        } else {
                            milliseconds =
                                    Long.parseLong(fraction);
                        }
                    }

                    timestamps.add(
                            minutes * 60_000L
                                    + seconds * 1_000L
                                    + milliseconds
                    );

                    lastTimestampEnd = matcher.end();
                }

                if (timestamps.isEmpty()) {
                    continue;
                }

                String lyricText =
                        line.substring(lastTimestampEnd).trim();

                if (lyricText.isEmpty()) {
                    continue;
                }

                for (long timestamp : timestamps) {
                    LINES.add(
                            new LyricLine(timestamp, lyricText)
                    );
                }
            }

            LINES.sort(
                    Comparator.comparingLong(item -> item.timeMs)
            );

        } catch (Exception exception) {
            System.err.println(
                    "[VortexLyrics] Failed to load LRC: "
                            + exception.getMessage()
            );

            LINES.clear();
            currentLine = -1;
            lineWorldPosition = null;
        }
    }

    private static int findCurrentLine(long positionMs) {
        int result = -1;

        for (int i = 0; i < LINES.size(); i++) {
            if (positionMs >= LINES.get(i).timeMs) {
                result = i;
            } else {
                break;
            }
        }

        return result;
    }

    private static Vec3d calculateWorldPosition(
            MinecraftClient client
    ) {
        Vec3d playerPos =
                client.player.getCameraPosVec(1.0f);

        Vec3d look =
                client.player.getRotationVec(1.0f);

        Vec3d right = new Vec3d(
                -look.z,
                0.0,
                look.x
        ).normalize();

        double distance = LyricsConfig.distance;

        double sideOffset = ThreadLocalRandom.current()
                .nextDouble(-2.5, 2.5);

        Vec3d target = playerPos
                .add(look.multiply(distance))
                .add(right.multiply(sideOffset));

        double x = target.x;
        double z = target.z;
        double y;

        if (LyricsConfig.lyricsXray) {
            // X-RAY: текст находится перед игроком.
            y = playerPos.y
                    + ThreadLocalRandom.current()
                    .nextDouble(-1.5, 2.5);
        } else {
            // ABOVE BLOCKS: текст находится над поверхностью.
            int blockX = (int) Math.floor(x);
            int blockZ = (int) Math.floor(z);

            int topY = client.world.getTopY(
                    Heightmap.Type.MOTION_BLOCKING,
                    blockX,
                    blockZ
            );

            y = topY + 1.4;
        }

        return new Vec3d(x, y, z);
    }

    private static void renderText(
            WorldRenderContext context,
            MinecraftClient client,
            String text
    ) {
        if (lineWorldPosition == null) {
            return;
        }

        MatrixStack matrices = context.matrixStack();

        if (matrices == null) {
            return;
        }

        Vec3d cameraPos = context.camera().getPos();

        double x = lineWorldPosition.x - cameraPos.x;
        double y = lineWorldPosition.y - cameraPos.y;
        double z = lineWorldPosition.z - cameraPos.z;

        matrices.push();

        try {
            matrices.translate(x, y, z);
            matrices.multiply(context.camera().getRotation());

            float scale = LyricsConfig.textScale;

            matrices.scale(-scale, -scale, scale);

            TextRenderer textRenderer = client.textRenderer;

            OrderedText orderedText =
                    Text.literal(text).asOrderedText();

            int textWidth = textRenderer.getWidth(orderedText);
            int maxWidth = LyricsConfig.textWidth;

            float drawX =
                    -Math.min(textWidth, maxWidth) / 2.0f;

            float drawY = 0.0f;

            TextRenderer.TextLayerType layerType =
                    LyricsConfig.lyricsXray
                            ? TextRenderer.TextLayerType.SEE_THROUGH
                            : TextRenderer.TextLayerType.NORMAL;

            textRenderer.draw(
                    orderedText,
                    drawX,
                    drawY,
                    0xFFFFFFFF,
                    false,
                    matrices.peek().getPositionMatrix(),
                    context.consumers(),
                    layerType,
                    0,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE
            );

        } finally {
            matrices.pop();
        }
    }

    private static void clear() {
        LINES.clear();
        loadedFile = null;
        currentLine = -1;
        lineWorldPosition = null;
    }

    private static final class LyricLine {

        private final long timeMs;
        private final String text;

        private LyricLine(long timeMs, String text) {
            this.timeMs = timeMs;
            this.text = text;
        }
    }
}

