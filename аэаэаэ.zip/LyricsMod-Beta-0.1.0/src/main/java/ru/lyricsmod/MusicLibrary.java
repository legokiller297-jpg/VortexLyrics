
package ru.lyricsmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

public final class MusicLibrary {

    private static final Path ROOT =
            FabricLoader.getInstance()
                    .getGameDir()
                    .resolve("vortexlyrics");

    private static final Path MUSIC_DIR =
            ROOT.resolve("music");

    private static final Path LYRICS_DIR =
            ROOT.resolve("lyrics");

    private static final List<Track> TRACKS =
            new ArrayList<>();

    private MusicLibrary() {
    }

    public record Track(
            String title,
            Path audioFile,
            Path lyricsFile
    ) {

        public boolean hasLyrics() {
            return lyricsFile != null
                    && Files.isRegularFile(lyricsFile);
        }

        public Path getLrcFile() {
            return lyricsFile;
        }

        public Path getFile() {
            return audioFile;
        }
    }

    public static Path getMusicDirectory() {
        return MUSIC_DIR;
    }

    public static Path getLyricsDirectory() {
        return LYRICS_DIR;
    }

    /**
     * Сканирует папки и обновляет список музыкальных треков.
     */
    public static synchronized List<Track> scan() {
        List<Track> tracks = new ArrayList<>();

        try {
            Files.createDirectories(MUSIC_DIR);
            Files.createDirectories(LYRICS_DIR);

            Map<String, Path> lyrics = new HashMap<>();

            try (Stream<Path> files = Files.list(LYRICS_DIR)) {
                files.filter(Files::isRegularFile)
                        .filter(MusicLibrary::isLyricsFile)
                        .forEach(path -> lyrics.putIfAbsent(
                                getName(path).toLowerCase(Locale.ROOT),
                                path
                        ));
            }

            try (Stream<Path> files = Files.list(MUSIC_DIR)) {
                files.filter(Files::isRegularFile)
                        .filter(MusicLibrary::isAudioFile)
                        .forEach(path -> {
                            String title = getName(path);

                            Path lyricsFile = lyrics.get(
                                    title.toLowerCase(Locale.ROOT)
                            );

                            tracks.add(new Track(
                                    title,
                                    path,
                                    lyricsFile
                            ));
                        });
            }

            tracks.sort(
                    Comparator.comparing(
                            Track::title,
                            String.CASE_INSENSITIVE_ORDER
                    )
            );

            TRACKS.clear();
            TRACKS.addAll(tracks);

        } catch (IOException exception) {
            System.err.println(
                    "[VortexLyrics] Failed to scan music folders:"
            );
            exception.printStackTrace();
        }

        return List.copyOf(TRACKS);
    }

    /**
     * Возвращает последний отсканированный список треков.
     */
    public static synchronized List<Track> getTracks() {
        return List.copyOf(TRACKS);
    }

    /**
     * Находит трек по пути к аудиофайлу.
     */
    public static synchronized Track findTrack(Path audioFile) {
        if (audioFile == null) {
            return null;
        }

        Path normalized = audioFile.toAbsolutePath().normalize();

        for (Track track : TRACKS) {
            if (track.audioFile()
                    .toAbsolutePath()
                    .normalize()
                    .equals(normalized)) {
                return track;
            }
        }

        return null;
    }

    /**
     * Находит трек и при необходимости обновляет библиотеку.
     */
    public static synchronized Track findTrackOrScan(Path audioFile) {
        Track track = findTrack(audioFile);

        if (track != null) {
            return track;
        }

        scan();
        return findTrack(audioFile);
    }

    /**
     * Проверяет, является ли файл аудиофайлом.
     */
    private static boolean isAudioFile(Path path) {
        String name = path.getFileName()
                .toString()
                .toLowerCase(Locale.ROOT);

        return name.endsWith(".mp3")
                || name.endsWith(".ogg");
    }

    /**
     * Проверяет расширение LRC.
     */
    private static boolean isLyricsFile(Path path) {
        return path.getFileName()
                .toString()
                .toLowerCase(Locale.ROOT)
                .endsWith(".lrc");
    }

    /**
     * Получает имя файла без расширения.
     */
    private static String getName(Path path) {
        String fileName = path.getFileName().toString();

        int dot = fileName.lastIndexOf('.');

        return dot > 0
                ? fileName.substring(0, dot)
                : fileName;
    }
}

