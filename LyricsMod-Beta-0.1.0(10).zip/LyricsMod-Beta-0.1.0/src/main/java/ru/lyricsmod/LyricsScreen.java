
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class LyricsScreen extends Screen {

    private static final int PURPLE = 0xFFB77AFF;
    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFAA98C2;

    private static final Identifier SUNGHYUN =
            new Identifier("lyricsmod", "sunghyun");

    private int selectedTab = 0;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
    }

    private Text uiText(String value) {
        return Text.literal(value)
                .setStyle(Style.EMPTY.withFont(SUNGHYUN));
    }

    private void roundedRect(
            DrawContext context,
            int x, int y, int w, int h,
            int radius, int color
    ) {
        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        for (int row = 0; row < h; row++) {
            int edge = Math.min(row, h - 1 - row);
            int inset = 0;

            if (edge < radius) {
                double distance = radius - edge;
                inset = radius - (int) Math.sqrt(
                        radius * radius - distance * distance
                );
            }

            context.fill(
                    x + inset,
                    y + row,
                    x + w - inset,
                    y + row + 1,
                    color
            );
        }
    }

    private void glassPanel(
            DrawContext context,
            int x, int y, int w, int h
    ) {
        roundedRect(context, x - 4, y - 4,
                w + 8, h + 8, 20, 0x249D55E8);

        roundedRect(context, x - 2, y - 2,
                w + 4, h + 4, 19, 0x559B5AE0);

        roundedRect(context, x, y,
                w, h, 17, 0xF0181423);

        roundedRect(context, x + 1, y + 1,
                w - 2, h - 2, 16, 0xE91C1729);
    }

    private void drawPlayIcon(
            DrawContext context, int x, int y, int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(
                    x + i, y + i,
                    x + i + 1, y + 17 - i,
                    color
            );
        }
    }

    private void drawSlidersIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x, y + 3, x + 19, y + 5, color);
        context.fill(x, y + 9, x + 19, y + 11, color);
        context.fill(x, y + 15, x + 19, y + 17, color);

        context.fill(x + 5, y + 1, x + 9, y + 7, color);
        context.fill(x + 13, y + 7, x + 17, y + 13, color);
        context.fill(x + 7, y + 13, x + 11, y + 19, color);
    }

    private void drawSettingsIcon(
            DrawContext context, int x, int y, int color
    ) {
        context.fill(x + 7, y, x + 12, y + 19, color);
        context.fill(x, y + 7, x + 19, y + 12, color);

        context.fill(x + 3, y + 2, x + 7, y + 6, color);
        context.fill(x + 12, y + 13, x + 16, y + 17, color);

        context.fill(x + 3, y + 13, x + 7, y + 17, color);
        context.fill(x + 12, y + 2, x + 16, y + 6, color);

        roundedRect(
                context,
                x + 6, y + 6, 7, 7,
                3, 0xFF241B34
        );
    }

    private void drawTab(
            DrawContext context,
            int x, int y,
            String label,
            int tab,
            boolean hovered
    ) {
        boolean active = selectedTab == tab;

        int background;

        if (active) {
            background = 0xFF69458D;
        } else if (hovered) {
            background = 0xFF49345F;
        } else {
            background = 0xFF30263F;
        }

        roundedRect(
                context,
                x, y, 131, 34,
                8, background
        );

        int iconColor = active || hovered ? LIGHT : PURPLE;

        if (tab == 0) {
            drawPlayIcon(context, x + 12, y + 9, iconColor);
        } else if (tab == 1) {
            drawSlidersIcon(context, x + 12, y + 7, iconColor);
        } else {
            drawSettingsIcon(context, x + 12, y + 7, iconColor);
        }

        int textColor = active ? LIGHT : (hovered ? LIGHT : MUTED);

        context.drawTextWithShadow(
                textRenderer,
                uiText(label),
                x + 43,
                y + 12,
                textColor
        );
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        int w = Math.min(560, width - 24);
        int h = Math.min(340, height - 24);

        int x = (width - w) / 2;
        int y = (height - h) / 2;

        glassPanel(context, x, y, w, h);

        roundedRect(
                context,
                x + 15, y + 14,
                w - 30, 45,
                11, 0xFF241B34
        );

        context.drawTextWithShadow(
                textRenderer,
                uiText("VortexLyrics"),
                x + 29, y + 23,
                LIGHT
        );

        context.drawTextWithShadow(
                textRenderer,
                uiText("BETA 0.1.0"),
                x + 29, y + 39,
                MUTED
        );

        int sidebarX = x + 15;
        int sidebarY = y + 70;
        int sidebarW = 145;
        int sidebarH = h - 130;

        roundedRect(
                context,
                sidebarX, sidebarY,
                sidebarW, sidebarH,
                12, 0xCC211A30
        );

        int tabX = sidebarX + 7;

        drawTab(
                context,
                tabX, sidebarY + 10,
                "Playlist", 0,
                mouseX >= tabX && mouseX <= tabX + 131
                        && mouseY >= sidebarY + 10
                        && mouseY <= sidebarY + 44
        );

        drawTab(
                context,
                tabX, sidebarY + 52,
                "Visual", 1,
                mouseX >= tabX && mouseX <= tabX + 131
                        && mouseY >= sidebarY + 52
                        && mouseY <= sidebarY + 86
        );

        drawTab(
                context,
                tabX, sidebarY + 94,
                "Other", 2,
                mouseX >= tabX && mouseX <= tabX + 131
                        && mouseY >= sidebarY + 94
                        && mouseY <= sidebarY + 128
        );

        int contentX = sidebarX + sidebarW + 13;
        int contentY = sidebarY;
        int contentW = w - sidebarW - 43;
        int contentH = sidebarH;

        roundedRect(
                context,
                contentX, contentY,
                contentW, contentH,
                12, 0xCC251D34
        );

        if (selectedTab == 0) {
            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Welcome to VortexLyrics"),
                    contentX + 17,
                    contentY + 19,
                    LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Your music experience starts here."),
                    contentX + 17,
                    contentY + 39,
                    MUTED
            );

        } else if (selectedTab == 1) {
            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Visual"),
                    contentX + 17,
                    contentY + 19,
                    LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Visual settings are coming soon."),
                    contentX + 17,
                    contentY + 39,
                    MUTED
            );

        } else {
            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Other"),
                    contentX + 17,
                    contentY + 19,
                    LIGHT
            );

            context.drawTextWithShadow(
                    textRenderer,
                    uiText("Other settings are coming soon."),
                    contentX + 17,
                    contentY + 39,
                    MUTED
            );
        }

        int barY = y + h - 48;

        roundedRect(
                context,
                x + 15, barY,
                w - 30, 34,
                10, 0xFF30243F
        );

        roundedRect(
                context,
                x + 22, barY + 6,
                22, 22,
                7, 0xFF8052A9
        );

        drawPlayIcon(
                context,
                x + 29, barY + 9,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(
                textRenderer,
                uiText("VORTEXLYRICS PLAYER"),
                x + 55, barY + 13,
                LIGHT
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 0) {
            int w = Math.min(560, width - 24);
            int h = Math.min(340, height - 24);

            int x = (width - w) / 2;
            int y = (height - h) / 2;

            int sidebarX = x + 15;
            int sidebarY = y + 70;
            int tabX = sidebarX + 7;

            if (mouseX >= tabX && mouseX <= tabX + 131) {
                if (mouseY >= sidebarY + 10
                        && mouseY <= sidebarY + 44) {
                    selectedTab = 0;
                    return true;
                }

                if (mouseY >= sidebarY + 52
                        && mouseY <= sidebarY + 86) {
                    selectedTab = 1;
                    return true;
                }

                if (mouseY >= sidebarY + 94
                        && mouseY <= sidebarY + 128) {
                    selectedTab = 2;
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

