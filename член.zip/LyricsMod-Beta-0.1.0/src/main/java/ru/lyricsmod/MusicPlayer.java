
package ru.lyricsmod;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class MusicPlayer {

    private static final int BUFFER_SIZE = 4096;

    private volatile File currentFile;
    private volatile SourceDataLine audioLine;
    private volatile Thread playbackThread;

    private volatile boolean playing;
    private volatile boolean paused;
    private volatile boolean stopped;

    private volatile long seekRequest = -1;
    private volatile long basePositionMillis;
    private volatile long writtenBytes;
    private volatile long durationMillis;

    private volatile float volume = 0.8f;

    public synchronized void play(File file) {
        if (file == null || !file.isFile()) {
            System.err.println("[VortexLyrics] Audio file not found.");
            return;
        }

        stop();

        currentFile = file;
        stopped = false;
        paused = false;
        playing = true;
        seekRequest = -1;
        basePositionMillis = 0;
        writtenBytes = 0;
        durationMillis = 0;

        playbackThread = new Thread(
                this::playbackLoop,
                "VortexLyrics-Audio"
        );

        playbackThread.setDaemon(true);
        playbackThread.start();
    }

    private void playbackLoop() {
        AudioInputStream source = null;
        AudioInputStream decoded = null;

        try {
            source = openSource(currentFile);
            decoded = convertToPcm(source);

            AudioFormat format = decoded.getFormat();

            DataLine.Info info = new DataLine.Info(
                    SourceDataLine.class,
                    format
            );

            audioLine = (SourceDataLine) AudioSystem.getLine(info);
            audioLine.open(format);
            applyVolume();
            audioLine.start();

            long frameLength = decoded.getFrameLength();

            if (frameLength > 0 && format.getFrameRate() > 0) {
                durationMillis = (long) (
                        frameLength / format.getFrameRate() * 1000
                );
            }

            byte[] buffer = new byte[BUFFER_SIZE];

            while (!stopped) {
                if (paused) {
                    Thread.sleep(20);
                    continue;
                }

                long requestedSeek = seekRequest;

                if (requestedSeek >= 0) {
                    seekRequest = -1;

                    decoded.close();
                    source.close();
                    audioLine.flush();

                    basePositionMillis = requestedSeek;
                    writtenBytes = 0;

                    source = openSource(currentFile);
                    decoded = convertToPcm(source);

                    skipToPosition(decoded, requestedSeek, format);

                    audioLine.start();
                    continue;
                }

                int bytesRead = decoded.read(buffer);

                if (bytesRead == -1) {
                    break;
                }

                int offset = 0;

                while (offset < bytesRead && !stopped && !paused) {
                    offset += audioLine.write(
                            buffer,
                            offset,
                            bytesRead - offset
                    );
                }

                writtenBytes += offset;
            }

            if (!stopped && audioLine != null) {
                audioLine.drain();
            }

        } catch (Exception e) {
            if (!stopped) {
                System.err.println(
                        "[VortexLyrics] Playback error: " + e.getMessage()
                );
            }
        } finally {
            closeQuietly(decoded);
            closeQuietly(source);

            SourceDataLine line = audioLine;

            if (line != null) {
                line.stop();
                line.flush();
                line.close();
            }

            audioLine = null;
            playing = false;
            paused = false;
            stopped = true;
        }
    }

    private AudioInputStream openSource(File file)
            throws UnsupportedAudioFileException, IOException {
        return AudioSystem.getAudioInputStream(file);
    }

    private AudioInputStream convertToPcm(AudioInputStream source)
            throws Exception {

        AudioFormat original = source.getFormat();

        AudioFormat pcm = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                original.getSampleRate(),
                16,
                original.getChannels(),
                original.getChannels() * 2,
                original.getSampleRate(),
                false
        );

        return AudioSystem.getAudioInputStream(pcm, source);
    }

    private void skipToPosition(
            AudioInputStream stream,
            long millis,
            AudioFormat format
    ) throws IOException {

        long frames = (long) (
                millis * format.getFrameRate() / 1000.0
        );

        long bytes = frames * format.getFrameSize();

        while (bytes > 0) {
            long skipped = stream.skip(bytes);

            if (skipped <= 0) {
                if (stream.read() == -1) {
                    break;
                }
                skipped = 1;
            }

            bytes -= skipped;
        }
    }

    public synchronized void pause() {
        if (!playing || paused) {
            return;
        }

        paused = true;

        if (audioLine != null) {
            audioLine.stop();
        }
    }

    public synchronized void resume() {
        if (!playing || !paused) {
            return;
        }

        paused = false;

        if (audioLine != null) {
            audioLine.start();
        }
    }

    public synchronized void togglePause() {
        if (paused) {
            resume();
        } else {
            pause();
        }
    }

    public synchronized void stop() {
        stopped = true;
        paused = false;
        playing = false;

        SourceDataLine line = audioLine;

        if (line != null) {
            line.stop();
            line.flush();
            line.close();
        }

        Thread thread = playbackThread;

        if (thread != null && thread != Thread.currentThread()) {
            thread.interrupt();
        }

        playbackThread = null;
        audioLine = null;
    }

    public void seekToMillis(long millis) {
        if (!playing || durationMillis <= 0) {
            return;
        }

        seekRequest = Math.max(
                0,
                Math.min(millis, durationMillis)
        );
    }

    public void setVolume(float value) {
        volume = Math.max(0.0f, Math.min(1.0f, value));
        applyVolume();
    }

    private void applyVolume() {
        SourceDataLine line = audioLine;

        if (line == null || !line.isControlSupported(
                FloatControl.Type.MASTER_GAIN
        )) {
            return;
        }

        FloatControl control = (FloatControl) line.getControl(
                FloatControl.Type.MASTER_GAIN
        );

        float gain = volume <= 0.0001f
                ? control.getMinimum()
                : (float) (20.0 * Math.log10(volume));

        gain = Math.max(
                control.getMinimum(),
                Math.min(control.getMaximum(), gain)
        );

        control.setValue(gain);
    }

    public long getPositionMillis() {
        SourceDataLine line = audioLine;

        if (line == null) {
            return basePositionMillis;
        }

        AudioFormat format = line.getFormat();

        if (format.getFrameRate() <= 0 || format.getFrameSize() <= 0) {
            return basePositionMillis;
        }

        long writtenFrames = writtenBytes / format.getFrameSize();

        return basePositionMillis
                + (long) (
                        writtenFrames * 1000.0 / format.getFrameRate()
                );
    }

    public long getDurationMillis() {
        return durationMillis;
    }

    public boolean isPlaying() {
        return playing;
    }

    public boolean isPaused() {
        return paused;
    }

    public File getCurrentFile() {
        return currentFile;
    }

    private void closeQuietly(AudioInputStream stream) {
        if (stream == null) {
            return;
        }

        try {
            stream.close();
        } catch (IOException ignored) {
        }
    }
}
