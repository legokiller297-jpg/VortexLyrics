
package ru.lyricsmod;

import net.minecraft.client.MinecraftClient;

import java.io.File;

public final class MusicPlayer {

    private File currentFile;
    private FileMusicSound currentSound;

    public void play(File file) {
        if (file == null || !file.isFile()) {
            System.err.println("[VortexLyrics] Audio file not found.");
            return;
        }

        stop();

        MinecraftClient client = MinecraftClient.getInstance();

        currentFile = file;
        currentSound = new FileMusicSound(file);

        client.getSoundManager().play(currentSound);
    }

    public void stop() {
        MinecraftClient client = MinecraftClient.getInstance();

        if (currentSound != null) {
            client.getSoundManager().stop(currentSound);
        }

        currentSound = null;
        currentFile = null;
    }

    public boolean isPlaying() {
        if (currentSound == null) {
            return false;
        }

        return MinecraftClient.getInstance()
                .getSoundManager()
                .isPlaying(currentSound);
    }

    public File getCurrentFile() {
        return currentFile;
    }
}

