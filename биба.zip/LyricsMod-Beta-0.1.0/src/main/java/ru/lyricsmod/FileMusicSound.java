
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.sound.v1.FabricSoundInstance;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.AudioStream;
import net.minecraft.client.sound.SoundLoader;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.io.File;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

public class FileMusicSound extends AbstractSoundInstance
        implements FabricSoundInstance {

    private final File file;

    public FileMusicSound(File file) {
        super(
                new Identifier("lyricsmod", "music_stream"),
                SoundCategory.MUSIC,
                Random.create()
        );

        this.file = file;
        this.repeat = false;
        this.volume = 1.0f;
        this.relative = true;
    }

    @Override
    public CompletableFuture<AudioStream> getAudioStream(
            SoundLoader loader,
            Identifier id,
            boolean repeatInstantly
    ) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return new FileAudioStream(file.toPath());
            } catch (Exception exception) {
                throw new CompletionException(exception);
            }
        });
    }
}

