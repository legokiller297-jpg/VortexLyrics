
package ru.lyricsmod;

import net.minecraft.client.sound.AudioStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Path;

public final class FileAudioStream implements AudioStream {

    private final AudioInputStream stream;
    private final AudioFormat format;
    private boolean closed;

    public FileAudioStream(Path file) throws Exception {
        AudioInputStream original =
                AudioSystem.getAudioInputStream(file.toFile());

        AudioFormat sourceFormat = original.getFormat();

        AudioFormat pcmFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                sourceFormat.getSampleRate(),
                16,
                sourceFormat.getChannels(),
                sourceFormat.getChannels() * 2,
                sourceFormat.getSampleRate(),
                false
        );

        try {
            stream = AudioSystem.getAudioInputStream(
                    pcmFormat,
                    original
            );
        } catch (Exception exception) {
            original.close();
            throw exception;
        }

        format = pcmFormat;
    }

    @Override
    public synchronized ByteBuffer getBuffer(int size)
            throws IOException {

        if (closed) {
            throw new IOException("Audio stream is closed");
        }

        byte[] bytes = new byte[size];
        int total = 0;

        while (total < size) {
            int read = stream.read(
                    bytes,
                    total,
                    size - total
            );

            if (read < 0) {
                break;
            }

            if (read > 0) {
                total += read;
            }
        }

        ByteBuffer buffer = ByteBuffer.allocateDirect(total);
        buffer.put(bytes, 0, total);
        buffer.flip();

        return buffer;
    }

    @Override
    public AudioFormat getFormat() {
        return format;
    }

    @Override
    public synchronized void close() throws IOException {
        if (!closed) {
            closed = true;
            stream.close();
        }
    }
}
