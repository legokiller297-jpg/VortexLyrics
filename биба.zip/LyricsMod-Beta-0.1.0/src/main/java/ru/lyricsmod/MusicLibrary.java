
package ru.lyricsmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

public final class MusicLibrary {

    private static final Path ROOT =
            FabricLoader.getInstance().getGameDir()
                    .resolve("vortexlyrics");

    private static final Path MUSIC_DIR = ROOT.resolve("music");
    private static final Path LYRICS_DIR = ROOT.resolve("lyrics");

    private MusicLibrary() {
    }

    public record Track(
            String title,
            Path audioFile,
            Path lyricsFile
    ) {
        public boolean hasLyrics() {
            return lyricsFile != null;
        }
    }

    public static Path getMusicDirectory() {
        return MUSIC_DIR;
    }

    public static Path getLyricsDirectory() {
        return LYRICS_DIR;
    }

    public static List<Track> scan() {
        List<Track> tracks = new ArrayList<>();

        try {
            Files.createDirectories(MUSIC_DIR);
            Files.createDirectories(LYRICS_DIR);

            Map<String, Path> lyrics = new HashMap<>();

            try (Stream<Path> files = Files.list(LYRICS_DIR)) {
                files.filter(Files::isRegularFile)
                        .filter(path -> path.getFileName().toString()
                                .toLowerCase(Locale.ROOT).endsWith(".lrc"))
                        .forEach(path -> lyrics.putIfAbsent(
                                getName(path).toLowerCase(Locale.ROOT),
                                path
                        ));
            }

            try (Stream<Path> files = Files.list(MUSIC_DIR)) {
                files.filter(Files::isRegularFile)
                        .filter(MusicLibrary::isAudioFile)
                        .forEach(path -> {
                            String title = getName(path);
                            Path lyricsFile = lyrics.get(
                                    title.toLowerCase(Locale.ROOT)
                            );

                            tracks.add(new Track(
                                    title,
                                    path,
                                    lyricsFile
                            ));
                        });
            }

            tracks.sort(Comparator.comparing(
                    Track::title,
                    String.CASE_INSENSITIVE_ORDER
            ));

        } catch (IOException exception) {
            System.err.println(
                    "[VortexLyrics] Failed to scan music folders:"
            );
            exception.printStackTrace();
        }

        return tracks;
    }

    private static boolean isAudioFile(Path path) {
        String name = path.getFileName().toString()
                .toLowerCase(Locale.ROOT);

        return name.endsWith(".mp3") || name.endsWith(".ogg");
    }

    private static String getName(Path path) {
        String fileName = path.getFileName().toString();
        int dot = fileName.lastIndexOf('.');

        return dot > 0
                ? fileName.substring(0, dot)
                : fileName;
    }
}
