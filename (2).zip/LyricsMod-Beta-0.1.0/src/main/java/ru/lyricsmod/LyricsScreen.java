
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class LyricsScreen extends Screen {

    private static final int PURPLE = 0xFFB77AFF;
    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFAA98C2;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
    }

    // Rounded rectangle
    private void roundedRect(
            DrawContext context,
            int x, int y, int w, int h,
            int radius, int color
    ) {
        radius = Math.max(0, Math.min(radius, Math.min(w, h) / 2));

        for (int row = 0; row < h; row++) {
            int edge = Math.min(row, h - 1 - row);
            int inset = 0;

            if (edge < radius) {
                double distance = radius - edge;
                inset = radius - (int) Math.sqrt(
                        radius * radius - distance * distance
                );
            }

            context.fill(
                    x + inset,
                    y + row,
                    x + w - inset,
                    y + row + 1,
                    color
            );
        }
    }

    // Glass panel with purple glow
    private void glassPanel(
            DrawContext context,
            int x, int y, int w, int h
    ) {
        roundedRect(
                context, x - 4, y - 4,
                w + 8, h + 8, 20,
                0x249D55E8
        );

        roundedRect(
                context, x - 2, y - 2,
                w + 4, h + 4, 19,
                0x559B5AE0
        );

        roundedRect(
                context, x, y,
                w, h, 17,
                0xF0181423
        );

        roundedRect(
                context, x + 1, y + 1,
                w - 2, h - 2, 16,
                0xE91C1729
        );
    }

    private void drawPlayIcon(
            DrawContext context, int x, int y, int color
    ) {
        for (int i = 0; i < 9; i++) {
            context.fill(
                    x + i, y + i,
                    x + i + 1, y + 17 - i,
                    color
            );
        }
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        int w = Math.min(560, width - 30);
        int h = Math.min(360, height - 30);

        int x = (width - w) / 2;
        int y = (height - h) / 2;

        // Main glass window
        glassPanel(context, x, y, w, h);

        // Header
        roundedRect(
                context, x + 15, y + 14,
                w - 30, 45, 11,
                0xFF241B34
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("VortexLyrics"),
                x + 29, y + 23, LIGHT
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("BETA 0.1.0"),
                x + 29, y + 39, MUTED
        );

        // Sidebar
        int sidebarX = x + 15;
        int sidebarY = y + 70;
        int sidebarW = 145;
        int sidebarH = h - 130;

        roundedRect(
                context, sidebarX, sidebarY,
                sidebarW, sidebarH, 12,
                0xCC211A30
        );

        // Playlist
        roundedRect(
                context,
                sidebarX + 7, sidebarY + 10,
                sidebarW - 14, 34, 8,
                0xFF49305F
        );

        drawPlayIcon(
                context,
                sidebarX + 18,
                sidebarY + 19,
                PURPLE
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("Playlist"),
                sidebarX + 43,
                sidebarY + 22,
                LIGHT
        );

        // Visual
        context.drawTextWithShadow(
                textRenderer,
                Text.literal("◈"),
                sidebarX + 18,
                sidebarY + 59,
                PURPLE
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("Visual"),
                sidebarX + 43,
                sidebarY + 59,
                MUTED
        );

        // Other
        context.drawTextWithShadow(
                textRenderer,
                Text.literal("⚙"),
                sidebarX + 18,
                sidebarY + 91,
                PURPLE
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("Other"),
                sidebarX + 43,
                sidebarY + 91,
                MUTED
        );

        // Main content area
        int contentX = sidebarX + sidebarW + 13;
        int contentY = sidebarY;
        int contentW = w - sidebarW - 43;
        int contentH = sidebarH;

        roundedRect(
                context,
                contentX, contentY,
                contentW, contentH, 12,
                0x99251D34
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("Welcome to VortexLyrics"),
                contentX + 17,
                contentY + 19,
                LIGHT
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("Your music experience starts here."),
                contentX + 17,
                contentY + 39,
                MUTED
        );

        // Bottom player bar
        int barY = y + h - 48;

        roundedRect(
                context,
                x + 15, barY,
                w - 30, 34, 10,
                0xFF30243F
        );

        roundedRect(
                context,
                x + 22, barY + 6,
                22, 22, 7,
                0xFF8052A9
        );

        drawPlayIcon(
                context,
                x + 29,
                barY + 9,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("VORTEXLYRICS PLAYER"),
                x + 55,
                barY + 13,
                LIGHT
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

