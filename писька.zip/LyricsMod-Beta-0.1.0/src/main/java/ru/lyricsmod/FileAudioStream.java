
package ru.lyricsmod;

import net.minecraft.client.sound.AudioStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;

public final class FileAudioStream implements AudioStream {

    private final AudioInputStream stream;
    private final AudioFormat format;
    private boolean closed;
    private boolean firstBufferLogged;

    public FileAudioStream(Path file) throws Exception {
        AudioInputStream original = null;

        log(file, "Открытие файла: " + file);

        try {
            original = AudioSystem.getAudioInputStream(file.toFile());

            AudioFormat sourceFormat = original.getFormat();

            log(file, "Исходный формат: " + sourceFormat);

            AudioFormat pcmFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    sourceFormat.getSampleRate(),
                    16,
                    sourceFormat.getChannels(),
                    sourceFormat.getChannels() * 2,
                    sourceFormat.getSampleRate(),
                    false
            );

            AudioInputStream converted =
                    AudioSystem.getAudioInputStream(pcmFormat, original);

            stream = converted;
            format = pcmFormat;

            log(file, "Поток успешно создан. Формат PCM: " + pcmFormat);

        } catch (Throwable error) {
            if (original != null) {
                try {
                    original.close();
                } catch (Exception ignored) {
                }
            }

            logError(file, "Ошибка создания аудиопотока", error);

            if (error instanceof Exception exception) {
                throw exception;
            }

            if (error instanceof Error fatalError) {
                throw fatalError;
            }

            throw new RuntimeException(error);
        }
    }

    @Override
    public synchronized ByteBuffer getBuffer(int size)
            throws IOException {

        if (closed) {
            throw new IOException("Audio stream is closed");
        }

        try {
            byte[] bytes = new byte[size];
            int total = 0;

            while (total < size) {
                int read = stream.read(
                        bytes,
                        total,
                        size - total
                );

                if (read < 0) {
                    break;
                }

                if (read > 0) {
                    total += read;
                }
            }

            if (!firstBufferLogged) {
                firstBufferLogged = true;
                logFromStream("Первый аудиобуфер получен: " + total + " байт");
            }

            if (total == 0) {
                logFromStream("Аудиопоток вернул 0 байт (возможно, конец файла)");
            }

            ByteBuffer buffer = ByteBuffer.allocateDirect(total);
            buffer.put(bytes, 0, total);
            buffer.flip();

            return buffer;

        } catch (IOException error) {
            logFromStreamError("Ошибка чтения аудиопотока", error);
            throw error;
        }
    }

    @Override
    public AudioFormat getFormat() {
        return format;
    }

    @Override
    public synchronized void close() throws IOException {
        if (!closed) {
            closed = true;
            logFromStream("Аудиопоток закрывается");
            stream.close();
        }
    }

    private void logFromStream(String message) {
        // Записываем диагностику рядом с папкой music.
        // Путь сохраняется в поле не нужен: используем отдельный метод ниже.
        System.out.println("[VortexLyrics] " + message);
    }

    private void logFromStreamError(String message, Throwable error) {
        System.err.println("[VortexLyrics] " + message);
        error.printStackTrace();
    }

    private static void log(Path audioFile, String message) {
        writeLog(audioFile, message, null);
    }

    private static void logError(
            Path audioFile,
            String message,
            Throwable error
    ) {
        writeLog(audioFile, message, error);
    }

    private static void writeLog(
            Path audioFile,
            String message,
            Throwable error
    ) {
        try {
            Path musicFolder = audioFile.toAbsolutePath().getParent();
            Path modFolder = musicFolder.getParent();
            Path logFile = modFolder.resolve("vortexlyrics-debug.txt");

            Files.createDirectories(modFolder);

            StringBuilder text = new StringBuilder();
            text.append("[")
                    .append(LocalDateTime.now())
                    .append("] ")
                    .append(message)
                    .append(System.lineSeparator());

            if (error != null) {
                StringWriter writer = new StringWriter();
                error.printStackTrace(new PrintWriter(writer));
                text.append(writer);
            }

            Files.writeString(
                    logFile,
                    text.toString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND
            );

        } catch (Throwable loggingError) {
            System.err.println("[VortexLyrics] Не удалось записать debug-файл");
            loggingError.printStackTrace();
        }
    }
}

