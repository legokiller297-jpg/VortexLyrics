package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;
import java.util.Locale;

/**
 * VortexLyrics interface.
 *
 * Layout is calculated from the current GUI size on every render/click.
 * The content viewport is clipped and independently scrollable; the mini-player
 * always occupies its own reserved area at the bottom of the panel.
 */
public class LyricsScreen extends Screen {

    // Purple translation of the reference's dark, layered green palette.
    private static final int WHITE = 0xFFF4EFFA;
    private static final int TEXT = 0xFFE1D7EC;
    private static final int MUTED = 0xFFAA9DB8;
    private static final int ACCENT = 0xFFB98AE8;
    private static final int ACCENT_BRIGHT = 0xFFD7B5F5;
    private static final int ACCENT_DARK = 0xFF7545A6;
    private static final int PANEL = 0xFF100B19;
    private static final int SIDEBAR = 0xFF151020;
    private static final int CARD = 0xFF21182D;
    private static final int CARD_ALT = 0xFF291D38;
    private static final int CARD_HOVER = 0xFF352449;
    private static final int CARD_SELECTED = 0xFF402B57;
    private static final int TRACK = 0xFF382B49;
    private static final int GREEN = 0xFF82DDB0;
    private static final int GRAY = 0xFF9991A3;

    private static final String[] TABS = {"Playlist", "Visual", "Text", "Other"};
    private static final String[] ICONS = {"♫", "◈", "T", "i"};

    private static final int ROW_HEIGHT = 34;
    private static final int ROW_GAP = 5;
    private static final int SCROLLBAR_W = 5;

    private static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private List<MusicLibrary.Track> tracks = List.of();
    private int selectedTab;
    private int selectedTrack = -1;

    private int playlistScroll;
    private double settingsScroll;
    private int draggingSlider = -1;
    private boolean draggingScrollbar;
    private double scrollbarGrabOffset;

    private int panelX, panelY, panelW, panelH, sidebarW;
    private int bodyX, bodyY, bodyW, bodyBottom;
    private int playerX, playerY, playerW, playerH;
    private int viewportX, viewportY, viewportW, viewportH;
    private int scrollContentHeight;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
        // Do not calculate layout here: Screen dimensions may not be initialized yet.
        tracks = MusicLibrary.scan();
        if (!tracks.isEmpty()) selectedTrack = 0;
    }

    private void calculateLayout() {
        // Keep a usable layout even on small GUI scales.
        panelW = Math.max(1, Math.min(760, width - 20));
        panelH = Math.max(1, Math.min(500, height - 20));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        sidebarW = Math.min(154, Math.max(82, panelW / 4));
        if (panelW < 390) sidebarW = Math.max(68, panelW / 5);

        bodyX = panelX + sidebarW + 18;
        bodyY = panelY + 67;
        bodyW = Math.max(1, panelX + panelW - 18 - bodyX);

        playerH = 46;
        playerX = panelX + 12;
        playerY = panelY + panelH - playerH - 10;
        playerW = Math.max(1, panelW - 24);

        viewportX = bodyX;
        viewportY = bodyY;
        viewportW = Math.max(1, bodyW - SCROLLBAR_W - 8);
        viewportH = Math.max(1, playerY - 11 - viewportY);
        bodyBottom = viewportY + viewportH;

        scrollContentHeight = getContentHeight();
        clampScroll();
    }

    private int getContentHeight() {
        return switch (selectedTab) {
            case 0 -> tracks.isEmpty() ? 166 : 70 + tracks.size() * (ROW_HEIGHT + ROW_GAP);
            case 1 -> 260;
            case 2 -> 276;
            case 3 -> 244;
            default -> 1;
        };
    }

    private int maxScroll() {
        return Math.max(0, scrollContentHeight - viewportH);
    }

    private double currentScroll() {
        return selectedTab == 0 ? playlistScroll : settingsScroll;
    }

    private void setCurrentScroll(double value) {
        value = Math.max(0, Math.min(maxScroll(), value));
        if (selectedTab == 0) playlistScroll = (int) Math.round(value);
        else settingsScroll = value;
    }

    private void clampScroll() {
        setCurrentScroll(currentScroll());
    }

    private int sx(int y) {
        return (int) Math.round(y - currentScroll());
    }

    private void fill(DrawContext ctx, int x, int y, int w, int h, int color) {
        if (w > 0 && h > 0) ctx.fill(x, y, x + w, y + h, color);
    }

    private void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) {
            fill(ctx, x, y, w, h, color);
            return;
        }
        fill(ctx, x + r, y, w - 2 * r, h, color);
        fill(ctx, x, y + r, w, h - 2 * r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - d * d)));
            fill(ctx, x + inset, y + i, w - inset * 2, 1, color);
            fill(ctx, x + inset, y + h - 1 - i, w - inset * 2, 1, color);
        }
    }

    private void roundedBorder(DrawContext ctx, int x, int y, int w, int h,
                               int radius, int border, int background) {
        rounded(ctx, x, y, w, h, radius, border);
        rounded(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, radius - 1), background);
    }

    private int withOpacity(int color, int percent) {
        int a = (color >>> 24) & 255;
        int alpha = a * Math.max(0, Math.min(100, percent)) / 100;
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private void text(DrawContext ctx, String value, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, value, x, y, color);
    }

    private String trim(String value, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (textRenderer.getWidth(value) <= maxWidth) return value;
        String suffix = "...";
        if (textRenderer.getWidth(suffix) > maxWidth) return "";
        while (!value.isEmpty() && textRenderer.getWidth(value + suffix) > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value + suffix;
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void card(DrawContext ctx, int x, int y, int w, int h) {
        rounded(ctx, x, y, w, h, 10, CARD);
    }

    private void drawPanel(DrawContext ctx) {
        rounded(ctx, panelX - 1, panelY - 1, panelW + 2, panelH + 2, 19, 0xFF63477D);
        // Alpha is applied only to the panel surface. Child controls remain opaque.
        rounded(ctx, panelX, panelY, panelW, panelH, 18,
                withOpacity(PANEL, LyricsConfig.panelOpacity));
        fill(ctx, panelX + sidebarW + 7, panelY + 15, 1, panelH - 30, 0x553E3150);
    }

    private void drawSidebar(DrawContext ctx, int mx, int my) {
        rounded(ctx, panelX, panelY, sidebarW + 10, panelH, 18, SIDEBAR);
        // Square the sidebar's inner edge so it joins the main panel cleanly.
        fill(ctx, panelX + sidebarW - 5, panelY + 1, 15, panelH - 2, SIDEBAR);

        text(ctx, "VORTEX", panelX + 17, panelY + 20, ACCENT_BRIGHT);
        text(ctx, "LYRICS", panelX + 17, panelY + 34, MUTED);

        int startY = panelY + 67;
        for (int i = 0; i < TABS.length; i++) {
            int y = startY + i * 44;
            boolean selected = selectedTab == i;
            boolean hovered = inside(mx, my, panelX + 9, y, sidebarW - 20, 36);
            int x = panelX + 9;
            int w = sidebarW - 20;

            if (selected) {
                rounded(ctx, x, y, w, 36, 9, CARD_SELECTED);
                rounded(ctx, x, y + 7, 3, 22, 2, ACCENT_BRIGHT);
            } else if (hovered) {
                // A two-pixel visual expansion gives a clear hover response without matrix scaling.
                roundedBorder(ctx, x - 1, y - 1, w + 2, 38, 10, 0xBFFFFFFF, CARD_HOVER);
            } else {
                rounded(ctx, x, y, w, 36, 9, SIDEBAR);
            }

            int iconColor = selected ? ACCENT_BRIGHT : MUTED;
            text(ctx, ICONS[i], x + 10, y + 12, iconColor);
            if (w >= 92) text(ctx, TABS[i], x + 31, y + 12, selected ? WHITE : TEXT);
        }
    }

    private void drawHeader(DrawContext ctx) {
        text(ctx, "VortexLyrics", bodyX, panelY + 18, WHITE);
        text(ctx, "MUSIC EXPERIENCE", bodyX, panelY + 36, MUTED);
        fill(ctx, bodyX, panelY + 56, bodyW, 1, 0x664D3B60);
    }

    private void drawTitle(DrawContext ctx, String title, String subtitle, int y) {
        text(ctx, title, viewportX, y, WHITE);
        text(ctx, trim(subtitle, viewportW), viewportX, y + 18, MUTED);
    }

    private void drawButton(DrawContext ctx, String label, int x, int y, int w, int h,
                            int mx, int my) {
        boolean hovered = inside(mx, my, x, y, w, h);
        if (hovered) {
            roundedBorder(ctx, x - 1, y - 1, w + 2, h + 2, 9, 0xDFFFFFFF, CARD_HOVER);
        } else {
            rounded(ctx, x, y, w, h, 8, CARD_ALT);
        }
        int tx = x + (w - textRenderer.getWidth(label)) / 2;
        text(ctx, label, tx, y + (h - 9) / 2, hovered ? WHITE : ACCENT_BRIGHT);
    }

    private void drawScrollbar(DrawContext ctx, int mx, int my) {
        if (maxScroll() <= 0) return;
        int x = viewportX + viewportW + 3;
        int y = viewportY;
        int h = viewportH;
        rounded(ctx, x, y, 4, h, 2, TRACK);

        int thumbH = Math.max(22, (int) ((double) h * h / scrollContentHeight));
        thumbH = Math.min(h, thumbH);
        int travel = h - thumbH;
        int thumbY = y + (int) Math.round(travel * currentScroll() / maxScroll());
        boolean hovered = inside(mx, my, x - 4, thumbY - 3, 12, thumbH + 6)
                || draggingScrollbar;
        rounded(ctx, x - (hovered ? 1 : 0), thumbY, hovered ? 6 : 4, thumbH, 3,
                hovered ? ACCENT_BRIGHT : ACCENT);
    }

    private void drawLrcBadge(DrawContext ctx, int x, int y, boolean hasLyrics) {
        int bg = hasLyrics ? 0xFF214735 : 0xFF38333F;
        rounded(ctx, x, y, 34, 19, 6, bg);
        text(ctx, "LRC", x + 6, y + 5, hasLyrics ? GREEN : GRAY);
    }

    private void drawPlaylist(DrawContext ctx, int mx, int my) {
        ctx.enableScissor(viewportX, viewportY, viewportX + viewportW, bodyBottom);
        int base = viewportY;
        drawTitle(ctx, "Your Playlist", "Your personal music collection", sx(base));
        text(ctx, tracks.size() + " TRACKS", viewportX, sx(base + 43), MUTED);
        drawButton(ctx, "REFRESH", viewportX + viewportW - 68, sx(base + 34),
                66, 24, mx, my);

        int rowsY = base + 70;
        if (tracks.isEmpty()) {
            card(ctx, viewportX, sx(rowsY), viewportW, 88);
            text(ctx, "Your playlist is empty", viewportX + 13, sx(rowsY + 17), TEXT);
            text(ctx, "Add MP3 or OGG files to:", viewportX + 13, sx(rowsY + 38), MUTED);
            text(ctx, "vortexlyrics/music", viewportX + 13, sx(rowsY + 56), ACCENT_BRIGHT);
            ctx.disableScissor();
            return;
        }

        int first = Math.max(0, playlistScroll / (ROW_HEIGHT + ROW_GAP));
        int count = viewportH / (ROW_HEIGHT + ROW_GAP) + 2;
        for (int i = first; i < Math.min(tracks.size(), first + count); i++) {
            int rowY = rowsY + i * (ROW_HEIGHT + ROW_GAP) - playlistScroll;
            if (rowY + ROW_HEIGHT < viewportY || rowY > bodyBottom) continue;
            boolean selected = selectedTrack == i;
            boolean hovered = inside(mx, my, viewportX, rowY, viewportW, ROW_HEIGHT);
            int bg = selected ? CARD_SELECTED : hovered ? CARD_HOVER : CARD;
            rounded(ctx, viewportX, rowY, viewportW, ROW_HEIGHT, 8, bg);
            if (selected) rounded(ctx, viewportX, rowY + 7, 3, 20, 2, ACCENT_BRIGHT);
            int badgeX = viewportX + viewportW - 43;
            String name = trim(tracks.get(i).title(), badgeX - viewportX - 22);
            text(ctx, name, viewportX + 12, rowY + 12, selected ? WHITE : TEXT);
            drawLrcBadge(ctx, badgeX, rowY + 7, tracks.get(i).hasLyrics());
        }
        ctx.disableScissor();
    }

    private void drawSlider(DrawContext ctx, int x, int y, int w, String title,
                            String valueText, double value, double min, double max, int accent) {
        card(ctx, x, y, w, 66);
        text(ctx, title, x + 13, y + 11, TEXT);
        text(ctx, valueText, x + w - textRenderer.getWidth(valueText) - 13, y + 11, accent);

        int bx = x + 13;
        int by = y + 45;
        int bw = Math.max(1, w - 26);
        rounded(ctx, bx, by, bw, 5, 3, TRACK);
        double p = Math.max(0, Math.min(1, (value - min) / (max - min)));
        int filled = (int) (bw * p);
        if (filled > 0) rounded(ctx, bx, by, filled, 5, 3, accent);
        int knobX = Math.max(bx, Math.min(bx + bw - 8, bx + filled - 4));
        rounded(ctx, knobX - 1, by - 4, 11, 13, 5, 0x55301040);
        rounded(ctx, knobX, by - 4, 9, 13, 5, WHITE);
    }

    private void drawTextSettings(DrawContext ctx) {
        int y = viewportY;
        ctx.enableScissor(viewportX, viewportY, viewportX + viewportW, bodyBottom);
        drawTitle(ctx, "Text Settings", "Customize lyrics displayed in your world", sx(y));
        drawSlider(ctx, viewportX, sx(y + 49), viewportW, "Spawn distance",
                String.format(Locale.ROOT, "%.1f blocks", LyricsConfig.distance),
                LyricsConfig.distance, 3, 30, ACCENT);
        drawSlider(ctx, viewportX, sx(y + 123), viewportW, "Text size",
                String.format(Locale.ROOT, "%.3f", LyricsConfig.textScale),
                LyricsConfig.textScale, 0.02, 0.09, 0xFFE49BE0);
        drawSlider(ctx, viewportX, sx(y + 197), viewportW, "Text width",
                LyricsConfig.textWidth + " px", LyricsConfig.textWidth, 60, 300, 0xFF9AA8F5);
        ctx.disableScissor();
    }

    private void drawVisual(DrawContext ctx) {
        int y = viewportY;
        ctx.enableScissor(viewportX, viewportY, viewportX + viewportW, bodyBottom);
        drawTitle(ctx, "Visual Appearance", "Customize the interface appearance", sx(y));
        drawSlider(ctx, viewportX, sx(y + 49), viewportW, "Panel opacity",
                LyricsConfig.panelOpacity + "%", LyricsConfig.panelOpacity, 10, 90, ACCENT_BRIGHT);

        int py = sx(y + 129);
        card(ctx, viewportX, py, viewportW, 115);
        text(ctx, "COLOR PALETTE", viewportX + 13, py + 12, TEXT);
        int[] colors = {0xFF100B19, 0xFF21182D, 0xFF7545A6, 0xFFD7B5F5};
        String[] names = {"Deep", "Dark", "Accent", "Soft"};
        int sw = Math.max(12, (viewportW - 50) / 4);
        for (int i = 0; i < colors.length; i++) {
            int xx = viewportX + 13 + i * (sw + 6);
            roundedBorder(ctx, xx, py + 40, sw, 23, 6, 0x665F4A70, colors[i]);
            text(ctx, names[i], xx, py + 69, MUTED);
        }
        text(ctx, "Lightweight rendering without blur shaders.",
                viewportX + 13, py + 91, MUTED);
        ctx.disableScissor();
    }

    private void drawOther(DrawContext ctx) {
        int y = viewportY;
        ctx.enableScissor(viewportX, viewportY, viewportX + viewportW, bodyBottom);
        drawTitle(ctx, "About VortexLyrics", "Information about the modification", sx(y));
        int cy = sx(y + 49);
        card(ctx, viewportX, cy, viewportW, 115);
        text(ctx, "VortexLyrics", viewportX + 14, cy + 14, WHITE);
        text(ctx, trim("Minecraft music and world lyrics player.", viewportW - 28),
                viewportX + 14, cy + 37, TEXT);
        text(ctx, "Supported audio: MP3 / OGG", viewportX + 14, cy + 61, MUTED);
        text(ctx, "Lyrics format: LRC", viewportX + 14, cy + 80, MUTED);

        int ly = sx(y + 176);
        card(ctx, viewportX, ly, viewportW, 60);
        text(ctx, "Music library", viewportX + 14, ly + 13, TEXT);
        text(ctx, "Songs found: " + tracks.size(), viewportX + 14, ly + 36, MUTED);
        ctx.disableScissor();
    }

    private void drawPlayerButton(DrawContext ctx, String label, int x, int y, int mx, int my) {
        boolean hovered = inside(mx, my, x - 2, y + 4, 30, 36);
        if (hovered) roundedBorder(ctx, x - 3, y + 3, 32, 38, 9, 0xBFFFFFFF, CARD_HOVER);
        else rounded(ctx, x - 2, y + 4, 30, 36, 8, CARD_ALT);
        text(ctx, label, x + 7, y + 17, hovered ? WHITE : ACCENT_BRIGHT);
    }

    private void drawMiniPlayer(DrawContext ctx, int mx, int my) {
        roundedBorder(ctx, playerX, playerY, playerW, playerH, 11,
                0xFF654780, 0xFF1C1428);

        String name = selectedTrack >= 0 && selectedTrack < tracks.size()
                ? tracks.get(selectedTrack).title() : "No track selected";
        int controlsX = playerX + playerW - 108;
        text(ctx, trim(name, Math.max(20, controlsX - playerX - 25)),
                playerX + 13, playerY + 8, WHITE);
        boolean playing = MUSIC_PLAYER.isPlaying();
        text(ctx, playing ? "NOW PLAYING" : "READY TO PLAY",
                playerX + 13, playerY + 25, playing ? GREEN : MUTED);

        drawPlayerButton(ctx, "<", controlsX, playerY, mx, my);
        drawPlayerButton(ctx, playing ? "||" : ">", controlsX + 34, playerY, mx, my);
        drawPlayerButton(ctx, ">", controlsX + 68, playerY, mx, my);
    }

    private void refreshLibrary() {
        tracks = MusicLibrary.scan();
        if (tracks.isEmpty()) selectedTrack = -1;
        else if (selectedTrack < 0 || selectedTrack >= tracks.size()) selectedTrack = 0;
        calculateLayout();
    }

    private void playSelectedTrack() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) return;
        File file = tracks.get(selectedTrack).audioFile().toFile();
        if (file.equals(MUSIC_PLAYER.getCurrentFile()) && MUSIC_PLAYER.isPlaying()) {
            MUSIC_PLAYER.stop();
        } else {
            MUSIC_PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {
        if (tracks.isEmpty()) return;
        selectedTrack = selectedTrack < 0 ? 0
                : Math.floorMod(selectedTrack + direction, tracks.size());
        playSelectedTrack();
    }

    private void updateSlider(double mouseX, int id) {
        int x = viewportX + 13;
        int w = Math.max(1, viewportW - 26);
        double p = Math.max(0, Math.min(1, (mouseX - x) / (double) w));
        if (id == 0) LyricsConfig.distance = 3 + p * 27;
        else if (id == 1) LyricsConfig.textScale = (float) (0.02 + p * 0.07);
        else if (id == 2) LyricsConfig.textWidth = (int) Math.round(60 + p * 240);
        else if (id == 3) LyricsConfig.panelOpacity = (int) Math.round(10 + p * 80);
    }

    private boolean beginScrollbarDrag(double mx, double my) {
        if (maxScroll() <= 0) return false;
        int x = viewportX + viewportW + 3;
        int h = viewportH;
        int thumbH = Math.max(22, h * h / Math.max(1, scrollContentHeight));
        thumbH = Math.min(h, thumbH);
        int travel = h - thumbH;
        int thumbY = viewportY + (int) Math.round(travel * currentScroll() / maxScroll());
        if (inside(mx, my, x - 5, thumbY - 3, 14, thumbH + 6)) {
            draggingScrollbar = true;
            scrollbarGrabOffset = my - thumbY;
            return true;
        }
        if (inside(mx, my, x - 5, viewportY, 14, viewportH)) {
            double ratio = (my - viewportY - thumbH / 2.0) / Math.max(1, travel);
            setCurrentScroll(ratio * maxScroll());
            draggingScrollbar = true;
            scrollbarGrabOffset = thumbH / 2.0;
            return true;
        }
        return false;
    }

    private void updateScrollbarDrag(double my) {
        int h = viewportH;
        int thumbH = Math.max(22, h * h / Math.max(1, scrollContentHeight));
        thumbH = Math.min(h, thumbH);
        int travel = h - thumbH;
        if (travel <= 0) {
            setCurrentScroll(0);
            return;
        }
        double top = my - scrollbarGrabOffset;
        setCurrentScroll((top - viewportY) / travel * maxScroll());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        calculateLayout();
        drawPanel(ctx);
        drawSidebar(ctx, mouseX, mouseY);
        drawHeader(ctx);

        // All tab content is clipped to the viewport above the dedicated player bar.
        if (selectedTab == 0) drawPlaylist(ctx, mouseX, mouseY);
        else if (selectedTab == 1) drawVisual(ctx);
        else if (selectedTab == 2) drawTextSettings(ctx);
        else drawOther(ctx);

        drawScrollbar(ctx, mouseX, mouseY);
        drawMiniPlayer(ctx, mouseX, mouseY);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        calculateLayout();

        int startY = panelY + 67;
        for (int i = 0; i < TABS.length; i++) {
            if (inside(mouseX, mouseY, panelX + 9, startY + i * 44, sidebarW - 20, 36)) {
                selectedTab = i;
                draggingSlider = -1;
                draggingScrollbar = false;
                calculateLayout();
                return true;
            }
        }

        if (beginScrollbarDrag(mouseX, mouseY)) return true;

        int base = viewportY;
        if (selectedTab == 0) {
            int refreshX = viewportX + viewportW - 68;
            if (inside(mouseX, mouseY, refreshX, base + 34 - playlistScroll, 66, 24)) {
                refreshLibrary();
                return true;
            }
            if (inside(mouseX, mouseY, viewportX, viewportY, viewportW, viewportH)) {
                int rowStart = base + 70;
                int contentY = (int) mouseY + playlistScroll;
                int index = (contentY - rowStart) / (ROW_HEIGHT + ROW_GAP);
                int rowY = rowStart + index * (ROW_HEIGHT + ROW_GAP) - playlistScroll;
                if (index >= 0 && index < tracks.size()
                        && inside(mouseX, mouseY, viewportX, rowY, viewportW, ROW_HEIGHT)) {
                    selectedTrack = index;
                }
                return true;
            }
        } else if (selectedTab == 2 || selectedTab == 1) {
            int[] offsets = selectedTab == 2 ? new int[]{49, 123, 197} : new int[]{49};
            for (int i = 0; i < offsets.length; i++) {
                int sy = base + offsets[i] - (int) currentScroll();
                if (inside(mouseX, mouseY, viewportX, sy + 37, viewportW, 17)) {
                    draggingSlider = selectedTab == 2 ? i : 3;
                    updateSlider(mouseX, draggingSlider);
                    return true;
                }
            }
        }

        int controlsX = playerX + playerW - 108;
        if (inside(mouseX, mouseY, controlsX - 2, playerY + 4, 30, 36)) {
            changeTrack(-1);
            return true;
        }
        if (inside(mouseX, mouseY, controlsX + 32, playerY + 4, 30, 36)) {
            playSelectedTrack();
            return true;
        }
        if (inside(mouseX, mouseY, controlsX + 66, playerY + 4, 30, 36)) {
            changeTrack(1);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button,
                               double deltaX, double deltaY) {
        if (button == 0 && draggingSlider >= 0) {
            updateSlider(mouseX, draggingSlider);
            return true;
        }
        if (button == 0 && draggingScrollbar) {
            updateScrollbarDrag(mouseY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && (draggingSlider >= 0 || draggingScrollbar)) {
            boolean changedConfig = draggingSlider >= 0;
            draggingSlider = -1;
            draggingScrollbar = false;
            if (changedConfig) LyricsConfig.save();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        calculateLayout();
        if (inside(mouseX, mouseY, viewportX, viewportY,
                viewportW + SCROLLBAR_W + 8, viewportH)) {
            setCurrentScroll(currentScroll() - amount * 24);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public void resize(net.minecraft.client.MinecraftClient client, int width, int height) {
        super.resize(client, width, height);
        calculateLayout();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
