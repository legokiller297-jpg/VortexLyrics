
package ru.lyricsmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.File;
import java.util.List;

public class LyricsScreen extends Screen {

    private static final int WHITE = 0xFFF5EDFF;
    private static final int LIGHT = 0xFFEAD9FF;
    private static final int MUTED = 0xFFBBA9D0;
    private static final int PURPLE = 0xFF9864C7;
    private static final int BACKGROUND = 0xF014101F;
    private static final int PANEL = 0xFF251D32;

    private static final MusicPlayer MUSIC_PLAYER = new MusicPlayer();

    private List<MusicLibrary.Track> tracks = List.of();

    private int selectedTab = 0;
    private int selectedTrack = -1;
    private int playlistScroll = 0;
    private int draggingSlider = -1;

    public LyricsScreen() {
        super(Text.literal("VortexLyrics"));
        refreshLibrary();
    }

    private void refreshLibrary() {
        tracks = MusicLibrary.scan();

        if (tracks.isEmpty()) {
            selectedTrack = -1;
        } else if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            selectedTrack = 0;
        }
    }

    private void playSelectedTrack() {
        if (selectedTrack < 0 || selectedTrack >= tracks.size()) {
            return;
        }

        File file = tracks.get(selectedTrack).audioFile().toFile();

        if (file.equals(MUSIC_PLAYER.getCurrentFile())
                && MUSIC_PLAYER.isPlaying()) {
            MUSIC_PLAYER.stop();
        } else {
            MUSIC_PLAYER.play(file);
        }
    }

    private void changeTrack(int direction) {
        if (tracks.isEmpty()) {
            return;
        }

        if (selectedTrack < 0) {
            selectedTrack = 0;
        } else {
            selectedTrack = Math.floorMod(
                    selectedTrack + direction,
                    tracks.size()
            );
        }

        playSelectedTrack();
    }

    private void drawPanel(
            DrawContext context,
            int x,
            int y,
            int w,
            int h,
            int color
    ) {
        context.fill(x, y, x + w, y + h, color);
    }

    private void drawText(
            DrawContext context,
            String text,
            int x,
            int y,
            int color
    ) {
        context.drawTextWithShadow(
                textRenderer,
                text,
                x,
                y,
                color
        );
    }

    private int contentX() {
        return width / 2 + 10;
    }

    private int contentY() {
        return height / 2 - 75;
    }

    private int contentWidth() {
        return Math.max(100, width / 2 - 35);
    }

    private void drawSlider(
            DrawContext context,
            int x,
            int y,
            int w,
            String title,
            String valueText,
            double value,
            double min,
            double max
    ) {
        drawText(context, title, x, y, LIGHT);
        drawText(context, valueText, x, y + 13, MUTED);

        int barX = x;
        int barY = y + 34;
        int barWidth = Math.max(40, w);

        context.fill(
                barX,
                barY,
                barX + barWidth,
                barY + 5,
                0xFF49375F
        );

        double progress = (value - min) / (max - min);
        progress = Math.max(0, Math.min(1, progress));

        int filled = (int) (barWidth * progress);

        context.fill(
                barX,
                barY,
                barX + filled,
                barY + 5,
                PURPLE
        );

        context.fill(
                barX + filled - 4,
                barY - 4,
                barX + filled + 5,
                barY + 10,
                WHITE
        );
    }

    private void drawSettings(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawText(context, "Lyrics Settings", x, y, WHITE);

        drawSlider(
                context, x, y + 30, w,
                "Spawn distance",
                String.format(java.util.Locale.ROOT, "%.1f blocks",
                        LyricsConfig.distance),
                LyricsConfig.distance, 3, 30
        );

        drawSlider(
                context, x, y + 95, w,
                "Text size",
                String.format(java.util.Locale.ROOT, "%.3f",
                        LyricsConfig.textScale),
                LyricsConfig.textScale, 0.02, 0.09
        );

        drawSlider(
                context, x, y + 160, w,
                "Text width",
                LyricsConfig.textWidth + " px",
                LyricsConfig.textWidth, 60, 300
        );

        drawText(
                context,
                "Words wrap automatically without splitting.",
                x,
                y + 220,
                MUTED
        );
    }

    private void drawPlaylist(DrawContext context) {
        int x = contentX();
        int y = contentY();
        int w = contentWidth();

        drawText(
                context,
                "Playlist (" + tracks.size() + ")",
                x,
                y,
                WHITE
        );

        drawText(
                context,
                "Refresh",
                x + w - 45,
                y,
                PURPLE
        );

        if (tracks.isEmpty()) {
            drawText(
                    context,
                    "No songs found.",
                    x,
                    y + 30,
                    MUTED
            );

            drawText(
                    context,
                    "Add MP3 or OGG files to vortexlyrics/music",
                    x,
                    y + 45,
                    MUTED
            );

            return;
        }

        int visible = Math.max(1, (height - 150) / 22);

        for (int i = playlistScroll;
             i < Math.min(tracks.size(), playlistScroll + visible);
             i++) {

            int rowY = y + 28 + (i - playlistScroll) * 22;

            int color = i == selectedTrack
                    ? 0xFF49305F
                    : PANEL;

            drawPanel(context, x, rowY, w, 19, color);

            String title = tracks.get(i).title();

            if (textRenderer.getWidth(title) > w - 15) {
                while (!title.isEmpty()
                        && textRenderer.getWidth(title + "...") > w - 15) {
                    title = title.substring(0, title.length() - 1);
                }
                title += "...";
            }

            drawText(context, title, x + 5, rowY + 5, LIGHT);
        }
    }

    private void drawOther(DrawContext context) {
        int x = contentX();
        int y = contentY();

        drawText(context, "About VortexLyrics", x, y, WHITE);
        drawText(context, "Minecraft music and world lyrics player.", x, y + 30, LIGHT);
        drawText(context, "Supported audio: MP3 / OGG", x, y + 50, MUTED);
        drawText(context, "Lyrics format: LRC", x, y + 70, MUTED);
        drawText(context, "Songs found: " + tracks.size(), x, y + 90, MUTED);
    }

    @Override
    public void render(
            DrawContext context,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderBackground(context);

        int panelW = Math.min(520, width - 24);
        int panelH = Math.min(340, height - 24);

        int panelX = (width - panelW) / 2;
        int panelY = (height - panelH) / 2;

        drawPanel(
                context,
                panelX,
                panelY,
                panelW,
                panelH,
                BACKGROUND
        );

        drawText(
                context,
                "VortexLyrics",
                panelX + 15,
                panelY + 15,
                WHITE
        );

        drawText(
                context,
                "MUSIC EXPERIENCE",
                panelX + 15,
                panelY + 29,
                MUTED
        );

        int tabX = panelX + 15;
        int tabY = panelY + 60;

        String[] tabs = {"Music", "Other", "Settings"};

        for (int i = 0; i < tabs.length; i++) {
            int y = tabY + i * 40;

            drawPanel(
                    context,
                    tabX,
                    y,
                    105,
                    30,
                    selectedTab == i ? 0xFF68458E : PANEL
            );

            drawText(
                    context,
                    tabs[i],
                    tabX + 10,
                    y + 10,
                    LIGHT
            );
        }

        if (selectedTab == 0) {
            drawPlaylist(context);
        } else if (selectedTab == 1) {
            drawOther(context);
        } else {
            drawSettings(context);
        }

        int bottomY = panelY + panelH - 35;

        drawPanel(
                context,
                panelX + 15,
                bottomY,
                panelW - 30,
                23,
                PANEL
        );

        String trackName = selectedTrack >= 0
                && selectedTrack < tracks.size()
                ? tracks.get(selectedTrack).title()
                : "No track selected";

        drawText(
                context,
                trackName,
                panelX + 22,
                bottomY + 7,
                LIGHT
        );

        drawText(
                context,
                "<",
                panelX + panelW - 100,
                bottomY + 7,
                WHITE
        );

        drawText(
                context,
                MUSIC_PLAYER.isPlaying() ? "STOP" : "PLAY",
                panelX + panelW - 77,
                bottomY + 7,
                PURPLE
        );

        drawText(
                context,
                ">",
                panelX + panelW - 29,
                bottomY + 7,
                WHITE
        );

        super.render(context, mouseX, mouseY, delta);
    }

    private void updateSlider(
            double mouseX,
            int x,
            int w,
            int id
    ) {
        double progress = Math.max(
                0,
                Math.min(1, (mouseX - x) / (double) w)
        );

        if (id == 0) {
            LyricsConfig.distance = 3 + progress * 27;
        } else if (id == 1) {
            LyricsConfig.textScale =
                    (float) (0.02 + progress * 0.07);
        } else if (id == 2) {
            LyricsConfig.textWidth =
                    (int) Math.round(60 + progress * 240);
        }
    }

    private void updateDraggedSlider(double mouseX) {
        int x = contentX();
        int w = contentWidth();

        updateSlider(mouseX, x, w, draggingSlider);
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        int panelW = Math.min(520, width - 24);
        int panelH = Math.min(340, height - 24);
        int panelX = (width - panelW) / 2;
        int panelY = (height - panelH) / 2;

        int tabX = panelX + 15;
        int tabY = panelY + 60;

        for (int i = 0; i < 3; i++) {
            int y = tabY + i * 40;

            if (mouseX >= tabX && mouseX <= tabX + 105
                    && mouseY >= y && mouseY <= y + 30) {
                selectedTab = i;
                return true;
            }
        }

        if (selectedTab == 2) {
            int x = contentX();
            int y = contentY();
            int w = contentWidth();

            for (int i = 0; i < 3; i++) {
                int barY = y + 30 + i * 65 + 34;

                if (mouseX >= x && mouseX <= x + w
                        && mouseY >= barY - 7
                        && mouseY <= barY + 12) {
                    draggingSlider = i;
                    updateDraggedSlider(mouseX);
                    LyricsConfig.save();
                    return true;
                }
            }
        }

        if (selectedTab == 0) {
            int x = contentX();
            int y = contentY();
            int w = contentWidth();

            if (mouseY >= y - 3 && mouseY <= y + 17
                    && mouseX >= x + w - 50) {
                refreshLibrary();
                return true;
            }

            int visible = Math.max(1, (height - 150) / 22);

            for (int i = playlistScroll;
                 i < Math.min(tracks.size(), playlistScroll + visible);
                 i++) {

                int rowY = y + 28 + (i - playlistScroll) * 22;

                if (mouseX >= x && mouseX <= x + w
                        && mouseY >= rowY && mouseY <= rowY + 19) {
                    selectedTrack = i;
                    return true;
                }
            }
        }

        int bottomY = panelY + panelH - 35;

        if (mouseY >= bottomY && mouseY <= bottomY + 23) {
            if (mouseX >= panelX + panelW - 105
                    && mouseX < panelX + panelW - 78) {
                changeTrack(-1);
                return true;
            }

            if (mouseX >= panelX + panelW - 80
                    && mouseX < panelX + panelW - 30) {
                playSelectedTrack();
                return true;
            }

            if (mouseX >= panelX + panelW - 35) {
                changeTrack(1);
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double deltaX,
            double deltaY
    ) {
        if (draggingSlider >= 0 && button == 0) {
            updateDraggedSlider(mouseX);
            return true;
        }

        return super.mouseDragged(
                mouseX, mouseY, button, deltaX, deltaY
        );
    }

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (draggingSlider >= 0) {
            draggingSlider = -1;
            LyricsConfig.save();
            return true;
        }

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double amount
    ) {
        if (selectedTab == 0) {
            int visible = Math.max(1, (height - 150) / 22);
            int maxScroll = Math.max(0, tracks.size() - visible);

            playlistScroll -= (int) Math.signum(amount);
            playlistScroll = Math.max(
                    0,
                    Math.min(maxScroll, playlistScroll)
            );

            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
