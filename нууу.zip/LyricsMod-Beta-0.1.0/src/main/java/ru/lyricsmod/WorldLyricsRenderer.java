
package ru.lyricsmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WorldLyricsRenderer {

    private static final Pattern TIMESTAMP =
            Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");

    private static final List<LyricLine> LINES = new ArrayList<>();

    private static final double MAX_SIDE_OFFSET = 3.0;
    private static final double MIN_HEIGHT = -1.5;
    private static final double MAX_HEIGHT = 2.5;

    private static final long FADE_IN_MS = 200L;
    private static final long FADE_OUT_MS = 300L;

    private static Path loadedFile;
    private static int currentLine = -1;
    private static Vec3d lineWorldPosition = null;

    private WorldLyricsRenderer() {
    }

    public static void register() {
        WorldRenderEvents.LAST.register(WorldLyricsRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null || client.world == null
                || client.textRenderer == null) {
            return;
        }

        File audioFile = MusicPlayer.getActiveFile();

        if (audioFile == null) {
            clear();
            return;
        }

        updateLyrics(audioFile);

        if (LINES.isEmpty()) {
            return;
        }

        long position = MusicPlayer.getActivePlaybackPositionMs();
        int index = findCurrentLine(position);

        if (index < 0) {
            currentLine = -1;
            lineWorldPosition = null;
            return;
        }

        LyricLine line = LINES.get(index);

        if (line.text().isBlank()) {
            currentLine = index;
            lineWorldPosition = null;
            return;
        }

        long endTime = index + 1 < LINES.size()
                ? LINES.get(index + 1).time()
                : Long.MAX_VALUE;

        if (index != currentLine) {
            currentLine = index;
            lineWorldPosition = calculateWorldPosition(context);
        }

        if (lineWorldPosition == null) {
            return;
        }

        float alpha = calculateAlpha(
                position - line.time(),
                endTime - position
        );

        if (alpha > 0.01f) {
            renderText(context, line.text(), alpha);
        }
    }

    private static float calculateAlpha(long elapsed, long remaining) {
        float fadeIn = Math.min(
                1.0f,
                Math.max(0.0f, elapsed / (float) FADE_IN_MS)
        );

        float fadeOut = remaining < FADE_OUT_MS
                ? Math.max(0.0f, remaining / (float) FADE_OUT_MS)
                : 1.0f;

        return Math.min(fadeIn, fadeOut);
    }

    private static Vec3d calculateWorldPosition(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();

        Vec3d playerPos = client.player.getLerpedPos(context.tickDelta());
        Vec3d look = client.player.getRotationVec(context.tickDelta()).normalize();

        ThreadLocalRandom random = ThreadLocalRandom.current();

        double distance = LyricsConfig.distance
                + random.nextDouble(-1.5, 1.5);

        distance = Math.max(3.0, Math.min(30.0, distance));

        float yaw = client.player.getYaw() * ((float) Math.PI / 180.0f);

        Vec3d right = new Vec3d(
                Math.cos(yaw), 0.0, Math.sin(yaw)
        ).normalize();

        double side = random.nextDouble(
                -MAX_SIDE_OFFSET, MAX_SIDE_OFFSET
        );

        double height = random.nextDouble(
                MIN_HEIGHT, MAX_HEIGHT
        );

        return playerPos
                .add(0, client.player.getStandingEyeHeight(), 0)
                .add(look.multiply(distance))
                .add(right.multiply(side))
                .add(0, height, 0);
    }

    private static void updateLyrics(File audioFile) {
        Path audioPath = audioFile.toPath().toAbsolutePath();

        if (audioPath.equals(loadedFile)) {
            return;
        }

        loadedFile = audioPath;
        currentLine = -1;
        lineWorldPosition = null;
        LINES.clear();

        for (MusicLibrary.Track track : MusicLibrary.scan()) {
            if (track.audioFile().toAbsolutePath().equals(audioPath)) {
                if (track.lyricsFile() != null) {
                    loadLrc(track.lyricsFile());
                }
                return;
            }
        }
    }

    private static void loadLrc(Path file) {
        try {
            List<String> source = Files.readAllLines(
                    file, StandardCharsets.UTF_8
            );

            for (String sourceLine : source) {
                Matcher matcher = TIMESTAMP.matcher(sourceLine);
                List<Long> timestamps = new ArrayList<>();

                while (matcher.find()) {
                    long minutes = Long.parseLong(matcher.group(1));
                    long seconds = Long.parseLong(matcher.group(2));

                    String fraction = matcher.group(3);
                    long millis = fraction == null ? 0L
                            : Long.parseLong((fraction + "00").substring(0, 3));

                    timestamps.add(minutes * 60_000L
                            + seconds * 1_000L + millis);
                }

                if (timestamps.isEmpty()) {
                    continue;
                }

                String text = TIMESTAMP.matcher(sourceLine)
                        .replaceAll("").trim();

                for (long timestamp : timestamps) {
                    LINES.add(new LyricLine(timestamp, text));
                }
            }

            LINES.sort(Comparator.comparingLong(LyricLine::time));

            System.out.println("[VortexLyrics] Loaded "
                    + LINES.size() + " lyric events.");

        } catch (Exception exception) {
            System.err.println("[VortexLyrics] Failed to load LRC: " + file);
            exception.printStackTrace();
        }
    }

    private static int findCurrentLine(long position) {
        int result = -1;

        for (int i = 0; i < LINES.size(); i++) {
            if (LINES.get(i).time() <= position) {
                result = i;
            } else {
                break;
            }
        }

        return result;
    }

    private static void renderText(
            WorldRenderContext context,
            String text,
            float alpha
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrices = context.matrixStack();

        if (matrices == null || context.consumers() == null) {
            return;
        }

        Vec3d relativePos = lineWorldPosition.subtract(
                context.camera().getPos()
        );

        matrices.push();
        matrices.translate(relativePos.x, relativePos.y, relativePos.z);
        matrices.multiply(context.camera().getRotation());

        float scale = LyricsConfig.textScale;

        matrices.scale(-scale, -scale, scale);

        TextRenderer renderer = client.textRenderer;

        List<OrderedText> wrapped = renderer.wrapLines(
                Text.literal(text),
                LyricsConfig.textWidth
        );

        int totalHeight = wrapped.size() * 10;
        int startY = -totalHeight / 2;

        int a = Math.max(0, Math.min(255, (int) (255 * alpha)));
        int white = (a << 24) | 0x00FFFFFF;

        for (int i = 0; i < wrapped.size(); i++) {
            OrderedText row = wrapped.get(i);

            float x = -renderer.getWidth(row) / 2.0f;
            float y = startY + i * 10;

            renderer.draw(
                    row,
                    x,
                    y,
                    white,
                    false,
                    matrices.peek().getPositionMatrix(),
                    context.consumers(),
                    TextRenderer.TextLayerType.NORMAL,
                    0,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE
            );
        }

        matrices.pop();
    }

    private static void clear() {
        loadedFile = null;
        currentLine = -1;
        lineWorldPosition = null;
        LINES.clear();
    }

    private record LyricLine(long time, String text) {
    }
}

