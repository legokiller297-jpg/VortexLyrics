
package ru.lyricsmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class LyricsConfig {

    private static final Path FILE = FabricLoader.getInstance()
            .getConfigDir().resolve("vortexlyrics.properties");

    public static double distance = 16.0;
    public static float textScale = 0.045f;
    public static int textWidth = 180;

    private LyricsConfig() {
    }

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }

        Properties properties = new Properties();

        try (InputStream input = Files.newInputStream(FILE)) {
            properties.load(input);

            distance = clamp(
                    Double.parseDouble(properties.getProperty("distance", "16")),
                    3.0, 30.0
            );

            textScale = (float) clamp(
                    Double.parseDouble(properties.getProperty("textScale", "0.045")),
                    0.02, 0.09
            );

            textWidth = (int) clamp(
                    Integer.parseInt(properties.getProperty("textWidth", "180")),
                    60, 300
            );

        } catch (Exception exception) {
            System.err.println("[VortexLyrics] Config loading failed.");
            exception.printStackTrace();
        }
    }

    public static void save() {
        Properties properties = new Properties();

        properties.setProperty("distance", String.valueOf(distance));
        properties.setProperty("textScale", String.valueOf(textScale));
        properties.setProperty("textWidth", String.valueOf(textWidth));

        try {
            Files.createDirectories(FILE.getParent());

            try (OutputStream output = Files.newOutputStream(FILE)) {
                properties.store(output, "VortexLyrics settings");
            }
        } catch (IOException exception) {
            System.err.println("[VortexLyrics] Config saving failed.");
            exception.printStackTrace();
        }
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
