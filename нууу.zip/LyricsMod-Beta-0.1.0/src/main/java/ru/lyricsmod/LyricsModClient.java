
package ru.lyricsmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LyricsModClient implements ClientModInitializer {

    private KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {

        LyricsConfig.load();

        openMenuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.lyricsmod.open_menu",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_B,
                        "category.lyricsmod"
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new LyricsScreen());
                }
            }
        });

        WorldLyricsRenderer.register();

        System.out.println(
                "[VortexLyrics] World Lyrics renderer registered!"
        );
    }
}

