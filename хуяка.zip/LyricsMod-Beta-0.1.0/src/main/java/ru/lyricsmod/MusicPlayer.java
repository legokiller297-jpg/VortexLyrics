
package ru.lyricsmod;

import net.minecraft.client.MinecraftClient;

import java.io.File;

public final class MusicPlayer {

    private static MusicPlayer activePlayer;

    private File currentFile;
    private FileMusicSound currentSound;

    private long playbackStartNanos;
    private long pausedNanos;
    private long pauseStartedNanos;

    private boolean wasPaused;

    private static final long START_GRACE_NANOS = 750_000_000L;

    public void play(File file) {
        if (file == null || !file.isFile()) {
            System.err.println("[VortexLyrics] Audio file not found.");
            return;
        }

        stop();

        MinecraftClient client = MinecraftClient.getInstance();

        currentFile = file;
        currentSound = new FileMusicSound(file);

        playbackStartNanos = System.nanoTime();
        pausedNanos = 0L;
        pauseStartedNanos = 0L;
        wasPaused = client.isPaused();

        if (wasPaused) {
            pauseStartedNanos = playbackStartNanos;
        }

        activePlayer = this;

        client.getSoundManager().play(currentSound);
    }

    public void stop() {
        MinecraftClient client = MinecraftClient.getInstance();

        if (currentSound != null) {
            client.getSoundManager().stop(currentSound);
        }

        currentSound = null;
        currentFile = null;

        playbackStartNanos = 0L;
        pausedNanos = 0L;
        pauseStartedNanos = 0L;
        wasPaused = false;

        if (activePlayer == this) {
            activePlayer = null;
        }
    }

    public boolean isPlaying() {
        if (currentSound == null) {
            return false;
        }

        return MinecraftClient.getInstance()
                .getSoundManager()
                .isPlaying(currentSound);
    }

    public File getCurrentFile() {
        return currentFile;
    }

    public long getPlaybackPositionMs() {
        if (currentFile == null || playbackStartNanos == 0L) {
            return 0L;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.nanoTime();
        boolean paused = client.isPaused();

        if (paused && !wasPaused) {
            pauseStartedNanos = now;
            wasPaused = true;
        }

        if (!paused && wasPaused) {
            if (pauseStartedNanos != 0L) {
                pausedNanos += now - pauseStartedNanos;
            }

            pauseStartedNanos = 0L;
            wasPaused = false;
        }

        long elapsed;

        if (wasPaused && pauseStartedNanos != 0L) {
            elapsed = pauseStartedNanos
                    - playbackStartNanos
                    - pausedNanos;
        } else {
            elapsed = now
                    - playbackStartNanos
                    - pausedNanos;
        }

        return Math.max(0L, elapsed / 1_000_000L);
    }

    public boolean hasFinished() {
        if (currentSound == null || currentFile == null) {
            return false;
        }

        if (MinecraftClient.getInstance().isPaused()) {
            return false;
        }

        if (System.nanoTime() - playbackStartNanos
                < START_GRACE_NANOS) {
            return false;
        }

        return !isPlaying();
    }

    public static File getActiveFile() {
        return activePlayer == null
                ? null
                : activePlayer.getCurrentFile();
    }

    public static long getActivePlaybackPositionMs() {
        return activePlayer == null
                ? 0L
                : activePlayer.getPlaybackPositionMs();
    }

    public static boolean isActivePlaying() {
        return activePlayer != null
                && activePlayer.isPlaying();
    }

    public static boolean isActivePaused() {
        return activePlayer != null
                && MinecraftClient.getInstance().isPaused();
    }

    public static boolean hasActiveFinished() {
        return activePlayer != null
                && activePlayer.hasFinished();
    }

    public static void stopActive() {
        if (activePlayer != null) {
            activePlayer.stop();
        }
    }
}

